import menu as mn

mn.menu()