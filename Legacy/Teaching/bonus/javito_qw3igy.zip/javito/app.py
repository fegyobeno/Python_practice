from colored import fg, attr
import os
import platform
import random
import msvcrt
from termcolor import colored
def clear_screen():
    system = platform.system()
    if system == "Windows":
        os.system('cls')  # Windows
    else:
        os.system('clear')  # Linux/MacOS

clear_screen()


class Feladat:

    def __init__(self, felszoveg, valaszok):
        self.feladat=felszoveg
        self.valaszok=valaszok.copy()
    
felDb=0
def load():
    result=[]
    try:
        with open("feladatok.txt","r", encoding='utf-8') as file:
            index=0
            valaszok=[]
            for line in file:
                if (index==0):
                    a=line.strip().split(" ", maxsplit=1)
                    index+=1
                else:
                    valaszok.append(line.strip()[1:].split("|"))
                    index+=1
                if index==5:
                    result.append(Feladat(a[1], dict(zip(["A","B","C","D"], valaszok))))
                    valaszok=[]
                    index=0
    
    except FileNotFoundError as e:
        print(f"Hiba: A fájl nem található. ({e})")
    except IndexError:
        print("Hiba: Az index kívül esik a lista tartományán.")
    except Exception as e:
        print(f"Hiba történt: {e}")
    
    global felDb
    felDb=len(result)
    return result
            
def save(feladat):
    global felDb
    try:
        with open("feladatok.txt","a", encoding='utf-8') as file:
            file.write("\n"+str(felDb+1)+", "+feladat.feladat+"\n")
            db=0
            for key, value in feladat.valaszok.items():
                db+=1
                if db==4:
                    file.write("*"+value[0]+"|"+value[1])
                else:
                    file.write("*"+value[0]+"|"+value[1]+"\n")
    
    except FileNotFoundError as e:
        print(f"Hiba: A fájl nem található. ({e})")
    except IndexError:
        print("Hiba: Az index kívül esik a lista tartományán.")
    except Exception as e:
        print(f"Hiba történt: {e}")   


def printFeladat(feladat, val=None):
    if not (val is None):
       
        print(f"{colored("Feladat: ","white","on_red" )} {feladat.feladat}")
        for key, value in feladat.valaszok.items():
            if (key in val):
                if value[1]=="True":
                    print(f"{fg('green')}{key}: {value[0]}{attr('reset')}")
                else:
                    print(f"{fg('red')}{key}: {value[0]}{attr('reset')}")
            else:
                if value[1]=="True":
                    print(f"{colored(f"{key}: {value[0]}", "white", "on_green")}")
                else:
                    print(f"{key}: {value[0]}")
    else:
        print(f"{colored("Feladat: ","white","on_red" )} {feladat.feladat}")
        print("A : ", feladat.valaszok.get("A")[0])
        print("B : ", feladat.valaszok.get("B")[0])
        print("C : ", feladat.valaszok.get("C")[0])
        print("D : ", feladat.valaszok.get("D")[0])

#print(feladatok[0].valaszok)

def feladatkiertekeles(feladat, valasz):
    clear_screen()
    printFeladat(feladat, valasz)
    for key, value in feladat.valaszok.items():
        if value[1]=="True":
            if not (key in valasz):
                return False
            else:
                 valasz.remove(key)
    return len(valasz) == 0
    

def jatek():
    feladatok=load()

    jovalaszok=0
    
    random.shuffle(feladatok)
    for fel in feladatok:
        clear_screen()
        printFeladat(fel)
        valasz=input("Valasz: ")

        if (feladatkiertekeles(fel, valasz.split(" "))):
            jovalaszok+=1
         
        print("Következő feladat: (Y)")
        msvcrt.getch().decode("utf-8")
    
    a= jovalaszok/len(feladatok)*100
    print(f"Vege a jateknak: Ön {colored({round(a,2)}, "white", "on_green")} %-ra teljesitette a kvizt!")


def mainPrint():
    clear_screen()
    print(f"{fg('red')}Üdvözlünk a játékban. Válassz egy menüpontot!{attr('reset')}")
    print(f"1. A játék indítása")
    print(f"2. Új kérdés hozzáadása a játékhoz")
    print(f"3. Játék leírása")
    print(f"4. Kilépés")



def main():
    mainPrint()

    while (True):
        try:
            number =int(input ("A menu sorszama:"))
            
            if (number <1) and (number>4):
                raise
            else:
                break
        except:
             print(f"{fg('red')}A megadott menusorszam nem megfelelo, adj meg egy ujat{attr('reset')}")
    
    if number==1:
        
        jatek()
        print()
        print(f"{colored("A menube való vissztéréshez nyomjon meg egy tetszőlges billentyűt!","white", "on_green" )}")
        msvcrt.getch().decode("utf-8")
        main()


    elif number==2:
        valaszok=[]
        print("Először adja meg a feladat szövegé!")
        szoveg=input("Feladat szövege:")
        print("Adja meg a negy darab válaszlehetőséget újsorból, a végén jelezve a helyességét. ( 'Valasz|True' )")
        for i in range(4):
            v=input(f"Valasz {i+1} : ")
            valaszok.append(v.split("|"))
        save(Feladat(szoveg, dict(zip(["A","B","C","D"], valaszok)) ))
        print()
        print(f"{colored("A menube való vissztéréshez nyomjon meg egy tetszőlges billentyűt!","white", "on_green" )}")
        msvcrt.getch().decode("utf-8")
        main()

    elif number==3:
        clear_screen()
        print("A játék során kvízkérdésekre kell válaszolnia, a következő szabályok szerint:")
        print("- egy kérdésnél több helyes megoldás is lehet;")
        print("- ha nem ad meg minden jó megoldást, akkor a válasz helytelennek számolódik;")
        print("- ha rossz választ is jónak jelöl, a válasz helytelennek számolodik;")
        print("- a válaszoknak csak a sorszámát (A, B, C D) kell megadni, szóközzel elválasztva.")
        print("- a helyes válaszok megadási sorrendje nem számít;")
        print("- a válasz megadása után megjelenik e kérdésnél, h mi volt a helyes válasz, és melyik nem")
        print("- a következő kérdés betöltéséhez nyomjon meg majd egy tetszőleges gombot (Y)")
        print()
        print("Az adatok beolvasás menüpontnál kérdéseket menthet el.")
        print("Kérdések mentésénél kövesse az utasításokat!!")
        print()
        print("- A játék végén megjelenik az ÖN teljesítménye.")
        print()
        print(f"{colored("A menube való vissztéréshez nyomjon meg egy tetszőlges billentyűt!","white","on_green")}")
        msvcrt.getch().decode("utf-8")
        main()
    else:
        print("Köszönjük, hogy velünk játszott!")

feladatok=load()
main()