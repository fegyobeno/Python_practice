from fastapi import APIRouter, HTTPException
from typing import List
from .modellek import Kurzus, Valasz
from .fajl_kezeles import KurzusFajlKezelo

utvonal = APIRouter()

fajl_kezelo = KurzusFajlKezelo()


@utvonal.get("/kurzusok", response_model=List[Kurzus])
async def get_osszes_kurzus():
    return fajl_kezelo.kurzusok_olvasas()


@utvonal.post("/kurzusok", response_model=Valasz)
async def uj_kurzus(kurzus: Kurzus):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    if kurzus.id in [k['id'] for k in kurzusok]:
        raise HTTPException(status_code=400, detail="Ez a kurzus id már foglalt")
    kurzusok.append(kurzus.model_dump())
    fajl_kezelo.kurzusok_iras(kurzusok)
    return {"uzenet": "Sikeres felvétel."}


@utvonal.get("/kurzusok/filter", response_model=List[Kurzus])
async def get_kurzusok_filter(nap_idopont: str = None, oktato_email: str = None, tipus: str = None,
                              evfolyam: int = None, helyszin: str = None, max_letszam: int = None):
    filters = {
        "nap_idopont": nap_idopont,
        "oktato|email": oktato_email,
        "tipus": tipus,
        "evfolyam": evfolyam,
        "helyszin": helyszin,
        "max_letszam": max_letszam
    }

    applied_filter = [(name, value) for name, value in filters.items() if value is not None]

    if len(applied_filter) != 1:
        raise HTTPException(status_code=400, detail="Pontosan egy filtert kell megadni.")

    kurzusok = fajl_kezelo.kurzusok_olvasas()
    filtered_kurzusok = kurzusok

    for i in range(len(applied_filter)):

        filter_name, filter_value = applied_filter[i]

        for k in kurzusok:
            data = k
            for key in filter_name.split("|"):
                data = data[key]
            if data != filter_value:
                filtered_kurzusok.remove(k)

    return kurzusok


@utvonal.get("/kurzusok/filters", response_model=List[Kurzus])
async def get_kurzusok_filters(nap_idopont: str = None, oktato_email: str = None, tipus: str = None,
                               evfolyam: int = None, helyszin: str = None, max_letszam: int = None):
    filters = {
        "nap_idopont": nap_idopont,
        "oktato|email": oktato_email,
        "tipus": tipus,
        "evfolyam": evfolyam,
        "helyszin": helyszin,
        "max_letszam": max_letszam
    }

    applied_filter = [(name, value) for name, value in filters.items() if value is not None]

    if len(applied_filter) != 2:
        raise HTTPException(status_code=400, detail="Pontosan két filtert kell megadni.")

    kurzusok = fajl_kezelo.kurzusok_olvasas()

    for i in range(len(applied_filter)):

        filter_name, filter_value = applied_filter[i]

        for k in kurzusok:
            data = k
            for key in filter_name.split("|"):
                data = data[key]
            if data != filter_value:
                kurzusok.remove(k)

    return kurzusok


@utvonal.put("/kurzusok/{kurzus_id}", response_model=Kurzus)
async def update_kurzus(kurzus_id: int, kurzus: Kurzus):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    for k in kurzusok:
        if k['id'] == kurzus_id:
            k.update(kurzus.model_dump())
            fajl_kezelo.kurzusok_iras(kurzusok)
            return k
    raise HTTPException(status_code=404, detail="Nem található a kurzus.")


@utvonal.get("/kurzusok/hallgatok/{hallgato_id}", response_model=List[Kurzus])
async def get_hallgato_kurzusai(hallgato_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    hallgato_kurzusai = []
    for k in kurzusok:
        for h in k['hallgatok']:
            if h['id'] == hallgato_id:
                hallgato_kurzusai.append(k)
    if len(hallgato_kurzusai) == 0:
        raise HTTPException(status_code=404, detail="Hallgató nem található.")
    return hallgato_kurzusai


@utvonal.delete("/kurzusok/{kurzus_id}")
async def delete_kurzus(kurzus_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    for k in kurzusok:
        if k['id'] == kurzus_id:
            kurzusok.remove(k)
            fajl_kezelo.kurzusok_iras(kurzusok)
            return
    raise HTTPException(status_code=404, detail="Nem található a kurzus.")


@utvonal.get("/kurzusok/{kurzus_id}/hallgatok/{hallgato_id}", response_model=Valasz)
async def get_hallgato_kurzuson(kurzus_id: int, hallgato_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    for k in kurzusok:
        if k['id'] == kurzus_id:
            for h in k['hallgatok']:
                if h['id'] == hallgato_id:
                    return {"uzenet": "Igen"}
            return {"uzenet": "Nem"}
    raise HTTPException(status_code=404, detail="Nem található a kurzus.")
