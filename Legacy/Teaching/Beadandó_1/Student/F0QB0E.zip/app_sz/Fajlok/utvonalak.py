from fastapi import APIRouter, HTTPException
from typing import List
from .modellek import Kurzus, Valasz
from .fajl_kezeles import KurzusFajlKezelo


utvonal = APIRouter()

fajl_kezelo = KurzusFajlKezelo()

@utvonal.get("/kurzusok", response_model=List[Kurzus])
async def get_osszes_kurzus():
    kurzusok_dict = fajl_kezelo.kurzusok_olvasas()
    kurzusok = [Kurzus(**kurzus) for kurzus in kurzusok_dict]
    return kurzusok


@utvonal.post("/kurzusok", response_model=Valasz)
async def uj_kurzus(kurzus: Kurzus):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    if any(k["id"] == kurzus.id for k in kurzusok):
        raise HTTPException(status_code=400, detail="Ez a kurzus id már foglalt")
    
    fajl_kezelo.kurzusok_iras(kurzusok + [kurzus.model_dump()])
    return Valasz(uzenet="Sikeres felvétel.")


@utvonal.get("/kurzusok/filter", response_model=List[Kurzus])
async def get_kurzusok_filter(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    filters = {
        "nap_idopont": nap_idopont,
        "oktato.email": oktato_email,
        "tipus": tipus,
        "evfolyam": evfolyam,
        "helyszin": helyszin,
        "max_letszam": max_letszam
    }

    aktiv_filterek = {key: value for key, value in filters.items() if value is not None}
    if len(aktiv_filterek) != 1:
        raise HTTPException(
            status_code=400,
            detail="Csak pontosan egy filtert adj meg!"
        )
    
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    filter_key, filter_value = aktiv_filterek.popitem()
    filtered_kurzusok = [
        kurzus for kurzus in kurzusok
        if (
            kurzus.get(filter_key) == filter_value if '.' not in filter_key else
            kurzus.get(filter_key.split('.')[0]).get(filter_key.split('.')[1]) == filter_value
        )
    ]
    return filtered_kurzusok


@utvonal.get("/kurzusok/filters", response_model=List[Kurzus])
async def get_kurzusok_filters(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    filters = {
        "nap_idopont": nap_idopont,
        "oktato.email": oktato_email,
        "tipus": tipus,
        "evfolyam": evfolyam,
        "helyszin": helyszin,
        "max_letszam": max_letszam
    }

    aktiv_filterek = {key: value for key, value in filters.items() if value is not None}
    if len(aktiv_filterek) != 2:
        raise HTTPException(
            status_code=400,
            detail="Csak pontosan két filtert adj meg!"
        )
    
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    filtered_kurzusok = [
        kurzus for kurzus in kurzusok
        if all(
                kurzus.get(key) == value if '.' not in key else
                kurzus.get(key.split('.')[0]).get(key.split('.')[1]) == value
                for key, value in aktiv_filterek.items()
            )
    ]
    return filtered_kurzusok


@utvonal.put("/kurzusok/{kurzus_id}", response_model=Kurzus)
async def update_kurzus(kurzus_id: int, kurzus: Kurzus):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    kurzus_index = next((i for i, k in enumerate(kurzusok) if k["id"] == kurzus_id), None)
    
    if kurzus_index is None:
        raise HTTPException(status_code=404, detail="A megadott kurzus nem található")
    
    kurzusok[kurzus_index] = kurzus.model_dump()
    fajl_kezelo.kurzusok_iras(kurzusok)

    return kurzus


@utvonal.get("/kurzusok/hallgatok/{hallgato_id}", response_model=List[Kurzus])
async def get_hallgato_kurzusai(hallgato_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()

    hallgato_kurzusai = [
        Kurzus(**kurzus) for kurzus in kurzusok
        if kurzus.get("hallgatok") and any(hallgato["id"] == hallgato_id for hallgato in kurzus["hallgatok"])
    ]

    if not hallgato_kurzusai:
        raise HTTPException(status_code=404, detail="A megadott hallgatóhoz nem találhatók kurzusok")

    return hallgato_kurzusai


@utvonal.delete("/kurzusok/{kurzus_id}")
async def delete_kurzus(kurzus_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    kurzus_index = next((index for index, kurzus in enumerate(kurzusok) if kurzus.get("id") == kurzus_id), None)
    if not kurzus_index:
        raise HTTPException(status_code=404, detail="A megadott kurzus nem található")

    deleted_kurzus = kurzusok.pop(kurzus_index)
    fajl_kezelo.kurzusok_iras(kurzusok)
    return Valasz(uzenet=f"Kurzus {deleted_kurzus['nev']} (ID: {kurzus_id}) sikeresen törölve.")


@utvonal.get("/kurzusok/{kurzus_id}/hallgatok/{hallgato_id}", response_model=Valasz)
async def get_hallgato_kurzuson(kurzus_id: int, hallgato_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    kurzus = next((k for k in kurzusok if k.get("id") == kurzus_id), None)
    
    if not kurzus:
        raise HTTPException(status_code=404, detail="A megadott kurzus nem található")
    
    enrolled = any(hallgato.get("id") == hallgato_id for hallgato in kurzus.get("hallgatok", []))
    return Valasz(uzenet="Igen" if enrolled else "Nem")
