from fastapi import APIRouter, HTTPException
from typing import List
from .modellek import Kurzus, Valasz
from .fajl_kezeles import KurzusFajlKezelo


utvonal = APIRouter()

fajl_kezelo = KurzusFajlKezelo()

@utvonal.get("/kurzusok", response_model=List[Kurzus])
async def get_osszes_kurzus():
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    return kurzusok

@utvonal.post("/kurzusok", response_model=Valasz)
async def uj_kurzus(kurzus: Kurzus):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    for existing_kurzus in kurzusok:
        if existing_kurzus["id"] == kurzus.id:
            raise HTTPException(status_code=400, detail="Ez a kurzus id már foglalt")
    kurzusok.append(kurzus.dict())
    fajl_kezelo.kurzusok_iras(kurzusok)
    
    return Valasz(uzenet="Sikeres felvétel.")

@utvonal.get("/kurzusok/filter", response_model=List[Kurzus])
async def get_kurzusok_filter(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    filtered_kurzusok = []

    for kurzus in kurzusok:
        if nap_idopont and kurzus["nap_idopont"] == nap_idopont:
            filtered_kurzusok.append(kurzus)
        elif oktato_email and kurzus["oktato"]["email"] == oktato_email:
            filtered_kurzusok.append(kurzus)
        elif tipus and kurzus["tipus"] == tipus:
            filtered_kurzusok.append(kurzus)
        elif evfolyam and kurzus["evfolyam"] == int(evfolyam):
            filtered_kurzusok.append(kurzus)
        elif helyszin and kurzus["helyszin"] == helyszin:
            filtered_kurzusok.append(kurzus)
        elif max_letszam and kurzus["max_letszam"] == int(max_letszam):
            filtered_kurzusok.append(kurzus)

    if not filtered_kurzusok:
        raise HTTPException(status_code=404, detail="Nincs a megadott szűrőnek megfelelő kurzus")

    return filtered_kurzusok

@utvonal.get("/kurzusok/filters", response_model=List[Kurzus])
async def get_kurzusok_filters(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    filtered_kurzusok = []

    filters = {
        "nap_idopont": nap_idopont,
        "oktato_email": oktato_email,
        "tipus": tipus,
        "evfolyam": evfolyam,
        "helyszin": helyszin,
        "max_letszam": max_letszam
    }

    active_filters = {k: v for k, v in filters.items() if v is not None}

    if len(active_filters) != 2:
        raise HTTPException(status_code=400, detail="Pontosan két szűrőt kell megadni")

    for kurzus in kurzusok:
        match = all(
            (kurzus[key] == int(value) if key in ["evfolyam", "max_letszam"] else kurzus[key] == value)
            if key != "oktato_email" else kurzus["oktato"]["email"] == value
            for key, value in active_filters.items()
        )
        if match:
            filtered_kurzusok.append(kurzus)

    if not filtered_kurzusok:
        raise HTTPException(status_code=404, detail="Nincs a megadott szűrőknek megfelelő kurzus")

    return filtered_kurzusok
    
@utvonal.put("/kurzusok/{kurzus_id}", response_model=Kurzus)
async def update_kurzus(kurzus_id: int, kurzus: Kurzus):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    for index, existing_kurzus in enumerate(kurzusok):
        if existing_kurzus["id"] == kurzus_id:
            kurzusok[index] = kurzus.dict()
            fajl_kezelo.kurzusok_iras(kurzusok)
            return kurzus

    raise HTTPException(status_code=404, detail="A megadott azonosítójú kurzus nem található")

@utvonal.get("/kurzusok/hallgatok/{hallgato_id}", response_model=List[Kurzus])
async def get_hallgato_kurzusai(hallgato_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    hallgato_kurzusai = [kurzus for kurzus in kurzusok if any(hallgato["id"] == hallgato_id for hallgato in kurzus["hallgatok"])]

    if not hallgato_kurzusai:
        raise HTTPException(status_code=404, detail="A megadott azonosítójú hallgató nem található kurzusokon")

    return hallgato_kurzusai

@utvonal.delete("/kurzusok/{kurzus_id}")
async def delete_kurzus(kurzus_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    for index, existing_kurzus in enumerate(kurzusok):
        if existing_kurzus["id"] == kurzus_id:
            del kurzusok[index]
            fajl_kezelo.kurzusok_iras(kurzusok)
            return {"message": "Kurzus sikeresen törölve"}

    raise HTTPException(status_code=404, detail="A megadott azonosítójú kurzus nem található")

@utvonal.get("/kurzusok/{kurzus_id}/hallgatok/{hallgato_id}", response_model=Valasz)
async def get_hallgato_kurzuson(kurzus_id: int, hallgato_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    for kurzus in kurzusok:
        if kurzus["id"] == kurzus_id:
            for hallgato in kurzus["hallgatok"]:
                if hallgato["id"] == hallgato_id:
                    return Valasz(uzenet="Igen")
            return Valasz(uzenet="Nem")
    raise HTTPException(status_code=404, detail="A megadott azonosítójú kurzus nem található")
