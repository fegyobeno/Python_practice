from fastapi import APIRouter, HTTPException
from typing import List
from .modellek import Kurzus, Valasz
from .fajl_kezeles import KurzusFajlKezelo


utvonal = APIRouter()

fajl_kezelo = KurzusFajlKezelo()

@utvonal.get("/kurzusok", response_model=List[Kurzus])
async def get_osszes_kurzus():
    return fajl_kezelo.kurzusok_olvasas()

@utvonal.post("/kurzusok", response_model=Valasz)
async def uj_kurzus(kurzus: Kurzus):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    for k in kurzusok:
        if k["id"] == kurzus.id:
            raise HTTPException(status_code=404, detail="Ez a kurzus id már foglalt")
    kurzus = kurzus.model_dump()
    kurzusok.append(kurzus)
    fajl_kezelo.kurzusok_iras(kurzusok)
    return Valasz(uzenet="Sikeres felvétel")

@utvonal.get("/kurzusok/filter", response_model=List[Kurzus])
async def get_kurzusok_filter(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    
    if(len(list(filter(lambda fltr: fltr != None, [nap_idopont, oktato_email, tipus, evfolyam, helyszin, max_letszam]))) != 1):
        raise HTTPException(status_code=404, detail="Pontosan 1 filtert kell beállítanod")
    
    megfelelo_kurzusok = []
    for k in kurzusok:
        if nap_idopont and k["nap_idopont"] != nap_idopont:
            continue
        if oktato_email and k["oktato"]["email"] != oktato_email:
            continue
        if tipus and k["tipus"] != tipus:
            continue
        if evfolyam and str(k["evfolyam"]) != evfolyam:
            continue
        if helyszin and k["helyszin"] != helyszin:
            continue
        if max_letszam and str(k["max_letszam"]) != max_letszam:
            continue
        megfelelo_kurzusok.append(k)
    # Nem tudom itt hibának számít-e, ha üres, hiszen pl.: ha feltölt egy html list elemet, akkor csak szimplán nem rakna bele semmit, amit én megfelelőnek találnák
    return megfelelo_kurzusok

@utvonal.get("/kurzusok/filters", response_model=List[Kurzus])
async def get_kurzusok_filters(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    
    if(len(list(filter(lambda fltr: fltr != None, [nap_idopont, oktato_email, tipus, evfolyam, helyszin, max_letszam]))) != 2):
        raise HTTPException(status_code=404, detail="Pontosan 2 filtert kell beállítanod")
    
    megfelelo_kurzusok = []
    for k in kurzusok:
        if nap_idopont and k["nap_idopont"] != nap_idopont:
            continue
        if oktato_email and k["oktato"]["email"] != oktato_email:
            continue
        if tipus and k["tipus"] != tipus:
            continue
        if evfolyam and str(k["evfolyam"]) != evfolyam:
            continue
        if helyszin and k["helyszin"] != helyszin:
            continue
        if max_letszam and str(k["max_letszam"]) != max_letszam:
            continue
        megfelelo_kurzusok.append(k)
    # Nem tudom itt hibának számít-e, ha üres, hiszen pl.: ha feltölt egy html list elemet, akkor csak szimplán nem rakna bele semmit, amit én megfelelőnek találnák
    return megfelelo_kurzusok
    
@utvonal.put("/kurzusok/{kurzus_id}", response_model=Kurzus)
async def update_kurzus(kurzus_id: int, kurzus: Kurzus):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    for k in kurzusok:
        if(k["id"] != kurzus_id):
            continue
        kurzus = kurzus.model_dump()
        k["nev"] = kurzus["nev"]
        k["tipus"] = kurzus["tipus"]
        k["evfolyam"] = kurzus["evfolyam"]
        k["nap_idopont"] = kurzus["nap_idopont"]
        k["helyszin"] = kurzus["helyszin"]
        k["oktato"] = kurzus["oktato"]
        k["hallgatok"] = kurzus["hallgatok"]
        k["max_letszam"] = kurzus["max_letszam"]

        fajl_kezelo.kurzusok_iras(kurzusok)
        return k

    raise HTTPException(status_code=404, detail="Nincs ilyen id-jű kurzus")

@utvonal.get("/kurzusok/hallgatok/{hallgato_id}", response_model=List[Kurzus])
async def get_hallgato_kurzusai(hallgato_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    # Üres lista szerintem toábbra sem hiba
    return list(filter(lambda k: hallgato_id in [h["id"] for h in k["hallgatok"]], kurzusok))

@utvonal.delete("/kurzusok/{kurzus_id}")
async def delete_kurzus(kurzus_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    uj_kurzusok = list(filter(lambda k: k["id"] != kurzus_id, kurzusok))
    if(len(kurzusok) == len(uj_kurzusok)):
        raise HTTPException(status_code=404, detail="Nincs ilyen id-jű kurzus")
    fajl_kezelo.kurzusok_iras(uj_kurzusok)
    return Valasz(uzenet="Kurzus sikeresen törölve")

@utvonal.get("/kurzusok/{kurzus_id}/hallgatok/{hallgato_id}", response_model=Valasz)
async def get_hallgato_kurzuson(kurzus_id: int, hallgato_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    kurzusok = list(filter(lambda k: k["id"] == kurzus_id, kurzusok))
    if len(kurzusok) == 0:
        raise HTTPException(status_code=404, detail="Nincs ilyen id-jű kurzus")
    kurzus = kurzusok[0]
    hallgatok = kurzus["hallgatok"]
    if not hallgatok:
        return Valasz(uzenet="Nem")
    for h in hallgatok:
        if h["id"] == hallgato_id:
            return Valasz(uzenet="Igen")
    return Valasz(uzenet="Nem")