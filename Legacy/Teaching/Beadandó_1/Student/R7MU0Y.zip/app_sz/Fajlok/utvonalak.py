from fastapi import APIRouter, HTTPException
from typing import List
from .modellek import Kurzus, Valasz
from .fajl_kezeles import KurzusFajlKezelo


utvonal = APIRouter()
fajl_kezelo = KurzusFajlKezelo()


@utvonal.get("/kurzusok", response_model=List[Kurzus])
async def get_osszes_kurzus():
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()
        return kurzusok
    except Exception as e:
        raise HTTPException(status_code=500, detail="Nem sikerült betölteni a kurzusokat")


@utvonal.post("/kurzusok", response_model=Valasz)
async def uj_kurzus(kurzus: Kurzus):
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()

        for megl_kurzus in kurzusok:
            if megl_kurzus["id"] == kurzus.id:
                raise HTTPException(status_code=400, detail="Ez a kurzus id már foglalt")

        kurzusok.append(kurzus.dict())
        
        fajl_kezelo.kurzusok_iras(kurzusok)

        return {"uzenet": "Sikeres felvétel."}
    except Exception as e:
        raise HTTPException(status_code=500, detail="Nem sikerült a kurzust hozzáadni")

@utvonal.get("/kurzusok/filter", response_model=List[Kurzus])
async def get_kurzusok_filter(
    nap_idopont: str = None, 
    oktato_email: str = None, 
    tipus: str = None, 
    evfolyam: int = None, 
    helyszin: str = None, 
    max_letszam: int = None
):
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()
        
        filters = {
            "nap_idopont": nap_idopont,
            "oktato_email": oktato_email,
            "tipus": tipus,
            "evfolyam": evfolyam,
            "helyszin": helyszin,
            "max_letszam": max_letszam
        }
        
        active_filters = {key: value for key, value in filters.items() if value is not None}
        
        if len(active_filters) != 1:
            raise HTTPException(
                status_code=400,
                detail="Pontosan egy szűrőt kell megadni."
            )
        
        filter_field, filter_value = list(active_filters.items())[0]
        
        filtered_kurzusok = [
            kurzus for kurzus in kurzusok 
            if filter_field in kurzus and str(kurzus[filter_field]) == str(filter_value)
        ]
        
        if not filtered_kurzusok:
            raise HTTPException(
                status_code=404,
                detail="Nem található kurzus a megadott szűrő feltétel alapján."
            )
        
        return filtered_kurzusok
    
    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(status_code=500, detail="Hiba történt a kurzusok szűrése közben")

#@utvonal.get("/kurzusok/filters", response_model=List[Kurzus])
#async def get_kurzusok_filters()

@utvonal.put("/kurzusok/{kurzus_id}", response_model=Valasz)
async def update_kurzus(kurzus_id: int, frissitett_kurzus: Kurzus):
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()

        for i, kurzus in enumerate(kurzusok):
            if kurzus["id"] == kurzus_id:

                kurzusok[i] = frissitett_kurzus.dict()
                
                fajl_kezelo.kurzusok_iras(kurzusok)
                
                return {"uzenet": "A kurzus sikeresen frissítve lett."}
        
        raise HTTPException(status_code=404, detail="A megadott kurzus nem található")
    
    except Exception as e:
        raise HTTPException(status_code=500, detail="Hiba történt a kurzus frissítése közben")

@utvonal.get("/kurzusok/hallgatok/{hallgato_id}", response_model=List[Kurzus])
async def get_hallgato_kurzusai(hallgato_id: int):
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()
        
        hallgato_kurzusai = [
            kurzus for kurzus in kurzusok 
            if any(hallgato["id"] == hallgato_id for hallgato in kurzus["hallgatok"])
        ]
        
        if not hallgato_kurzusai:
            raise HTTPException(status_code=404, detail="A hallgató nem található, vagy nincs kurzusra beiratkozva.")
        
        return hallgato_kurzusai
    
    except HTTPException as e:
        raise e
    except Exception as e:
        print(f"Hiba történt a lekérdezés során: {e}")
        raise HTTPException(status_code=500, detail="Hiba történt a hallgató kurzusainak lekérdezése során")


@utvonal.delete("/kurzusok/{kurzus_id}", response_model=Valasz)
async def delete_kurzus(kurzus_id: int):
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()
        
        index = next((i for i, kurzus in enumerate(kurzusok) if kurzus["id"] == kurzus_id), None)#indext ad vissza
        
        if index is None:
            raise HTTPException(status_code=404, detail="A kurzus nem található")
        
        del kurzusok[index]
        
        fajl_kezelo.kurzusok_iras(kurzusok)

        return {"uzenet": "Sikeres törlés."}
    
    except Exception as e:
        raise HTTPException(status_code=500, detail="Nem sikerült a kurzus törlése")


@utvonal.get("/kurzusok/{kurzus_id}/hallgatok/{hallgato_id}", response_model=Valasz)
async def get_hallgato_kurzuson(kurzus_id: int, hallgato_id: int):
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()
        
        kurzus = next((k for k in kurzusok if k["id"] == kurzus_id), None)#egész elemet ad viszaz
        
        if kurzus is None:
            raise HTTPException(status_code=404, detail="A kurzus nem található")
        
        if hallgato_id in kurzus.get("hallgatok", []):
            return {"uzenet": "Igen"} 
        else:
            return {"uzenet": "Nem"}  
    
    except Exception as e:
        raise HTTPException(status_code=500, detail="Nem sikerült ellenőrizni a hallgató státuszát")

