from fastapi import APIRouter, HTTPException
from typing import List
from .modellek import Kurzus, Valasz
from .fajl_kezeles import KurzusFajlKezelo

utvonal = APIRouter()

fajl_kezelo = KurzusFajlKezelo()

@utvonal.get("/kurzusok", response_model=List[Kurzus])
async def get_osszes_kurzus():
    try:
        kurzusok_data = fajl_kezelo.kurzusok_olvasas()
        return [Kurzus(**kurzus) for kurzus in kurzusok_data]
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
     
@utvonal.post("/kurzusok", response_model=Valasz)
async def uj_kurzus(kurzus: Kurzus):
    try:
        kurzusok_data = fajl_kezelo.kurzusok_olvasas()
        for k in kurzusok_data:
            if k["id"] == kurzus.id:
                raise HTTPException(
                    status_code=400, 
                    detail="Ez a kurzus id már foglalt."
                )
        
        kurzusok_data.append(kurzus.model_dump())
        fajl_kezelo.kurzusok_iras(kurzusok_data)

        return Valasz(uzenet="Sikeres felvétel.")
    
    except HTTPException as http_exc:
        raise http_exc
    except Exception as e:
        raise HTTPException(status_code=500, detail="Hibaüzenet: " + str(e))

@utvonal.get("/kurzusok/filter", response_model=List[Kurzus])
async def get_kurzusok_filter(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    try:
        kurzusok_data = fajl_kezelo.kurzusok_olvasas()

        filters = [nap_idopont, oktato_email, tipus, evfolyam, helyszin, max_letszam]
        active_filters = [f for f in filters if f is not None]
        if len(active_filters) != 1:
            raise HTTPException(
                status_code=400,
                detail="Egyszerre pontosan egy szűrőt kell megadni."
            )

        if nap_idopont:
            filtered_kurzusok = [kurzus for kurzus in kurzusok_data if kurzus["nap_idopont"] == nap_idopont]
        elif oktato_email:
            filtered_kurzusok = [kurzus for kurzus in kurzusok_data if kurzus["oktato"]["email"] == oktato_email]
        elif tipus:
            filtered_kurzusok = [kurzus for kurzus in kurzusok_data if kurzus["tipus"] == tipus]
        elif evfolyam:
            filtered_kurzusok = [kurzus for kurzus in kurzusok_data if str(kurzus["evfolyam"]) == evfolyam]
        elif helyszin:
            filtered_kurzusok = [kurzus for kurzus in kurzusok_data if kurzus["helyszin"] == helyszin]
        elif max_letszam:
            filtered_kurzusok = [kurzus for kurzus in kurzusok_data if kurzus["max_letszam"] == max_letszam]
        else:
            filtered_kurzusok = []

        if not filtered_kurzusok:
            raise HTTPException(status_code=404, detail="Nincs a szűrőnek megfelelő kurzus.")

        return [Kurzus(**kurzus) for kurzus in filtered_kurzusok]

    except HTTPException as http_exc:
        raise http_exc
    except Exception as e:
        raise HTTPException(status_code=500, detail="Hibaüzenet: " + str(e))

@utvonal.get("/kurzusok/filters", response_model=List[Kurzus])
async def get_kurzusok_filters(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: int = None, helyszin: str = None, max_letszam: int = None):
    try:
        kurzusok_data = fajl_kezelo.kurzusok_olvasas()

        filters = {
            "nap_idopont": nap_idopont,
            "oktato_email": oktato_email,
            "tipus": tipus,
            "evfolyam": evfolyam,
            "helyszin": helyszin,
            "max_letszam": max_letszam
        }
        active_filters = {key: value for key, value in filters.items() if value is not None}
        print(active_filters)
        
        if len(active_filters) != 2:
            raise HTTPException(
                status_code=400,
                detail="Egyszerre pontosan két szűrőt kell megadni."
            )

        filtered_kurzusok = kurzusok_data
        for key, value in active_filters.items():
            if key == "oktato_email":
                filtered_kurzusok = ([kurzus for kurzus in filtered_kurzusok if kurzus["oktato"]["email"] == value])
            else:
                filtered_kurzusok = ([kurzus for kurzus in filtered_kurzusok if str(kurzus[key]) == str(value)])
            print(filtered_kurzusok)

        if not filtered_kurzusok:
            raise HTTPException(status_code=404, detail="Nincs a szűrőknek megfelelő kurzus.")

        return [Kurzus(**kurzus) for kurzus in filtered_kurzusok]

    except HTTPException as http_exc:
        raise http_exc
    except Exception as e:
        raise HTTPException(status_code=500, detail="Hibaüzenet: " + str(e))
    
@utvonal.put("/kurzusok/{kurzus_id}", response_model=Kurzus)
async def update_kurzus(kurzus_id: int, kurzus: Kurzus):
    try:
        kurzusok_data = fajl_kezelo.kurzusok_olvasas()
        for index, existing_kurzus in enumerate(kurzusok_data):
            if existing_kurzus["id"] == kurzus_id:
                kurzusok_data[index] = kurzus.model_dump()
                fajl_kezelo.kurzusok_iras(kurzusok_data)
                return kurzus
               
        raise HTTPException(status_code=404, detail="Kurzus nem található.")
    
    except HTTPException as http_exc:
        raise http_exc
    except Exception as e:
        raise HTTPException(status_code=500, detail="Hibaüzenet: " + str(e))

@utvonal.get("/kurzusok/hallgatok/{hallgato_id}", response_model=List[Kurzus])
async def get_hallgato_kurzusai(hallgato_id: int):
    try:
        kurzusok_data = fajl_kezelo.kurzusok_olvasas()
        hallgato_kurzusai = []

        for kurzus in kurzusok_data:
            if any(hallgato["id"] == hallgato_id for hallgato in kurzus["hallgatok"]):
                hallgato_kurzusai.append(kurzus)
            
        if not hallgato_kurzusai:
            raise HTTPException(status_code=404, detail="A hallgató nem található egyetlen kurzusban sem.")

        return hallgato_kurzusai

    except HTTPException as http_exc:
        raise http_exc
    except Exception as e:
        raise HTTPException(status_code=500, detail="Hibaüzenet: " + str(e))

@utvonal.delete("/kurzusok/{kurzus_id}")
async def delete_kurzus(kurzus_id: int):
    try:
        kurzusok_data = fajl_kezelo.kurzusok_olvasas()
        for index, existing_kurzus in enumerate(kurzusok_data):
            if existing_kurzus["id"] == kurzus_id:
                del kurzusok_data[index]
                fajl_kezelo.kurzusok_iras(kurzusok_data)
                return {"detail": "Kurzus sikeresen törölve."}

        raise HTTPException(status_code=404, detail="Kurzus nem található.")
    
    except HTTPException as http_exc:
        raise http_exc
    except Exception as e:
        raise HTTPException(status_code=500, detail="Hibaüzenet: " + str(e))

@utvonal.get("/kurzusok/{kurzus_id}/hallgatok/{hallgato_id}", response_model=Valasz)
async def get_hallgato_kurzuson(kurzus_id: int, hallgato_id: int):
    try:
        kurzusok_data = fajl_kezelo.kurzusok_olvasas()
        for kurzus in kurzusok_data:
            if kurzus["id"] == kurzus_id:
                if any(hallgato["id"] == hallgato_id for hallgato in kurzus["hallgatok"]):
                    return Valasz(uzenet="Igen")
                else:
                    return Valasz(uzenet="Nem")

        raise HTTPException(status_code=404, detail="Kurzus nem található.")
    
    except HTTPException as http_exc:
        raise http_exc
    except Exception as e:
        raise HTTPException(status_code=500, detail="Hibaüzenet: " + str(e))
