from fastapi import APIRouter, HTTPException
from typing import List, Optional
from .modellek import Kurzus, Valasz
from .fajl_kezeles import KurzusFajlKezelo


utvonal = APIRouter()

fajl_kezelo = KurzusFajlKezelo()

@utvonal.get("/kurzusok", response_model=List[Kurzus])
async def get_osszes_kurzus():
    return fajl_kezelo.kurzusok_olvasas()

@utvonal.post("/kurzusok", response_model=Valasz)
async def uj_kurzus(kurzus: Kurzus):
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()
        if any(k["id"] == kurzus.id for k in kurzusok):
            raise HTTPException(status_code=400, detail="Ez a kurzus id már foglalt")
        kurzusok.append(kurzus.dict())
        fajl_kezelo.kurzusok_iras(kurzusok)
        return Valasz(uzenet="Sikeres felvétel.")
    
    except Exception:
        raise HTTPException(status_code=500, detail="Valami hiba történt a kurzus felvétele során.")
    except HTTPException as http_x:
        raise http_x
    
@utvonal.get("/kurzusok/filter", response_model=List[Kurzus])
async def get_kurzusok_filter(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    try:
        filter_count = sum(x is not None for x in [nap_idopont, oktato_email, tipus, evfolyam, helyszin, max_letszam])
        if filter_count != 1:
            raise HTTPException(status_code=400, detail="Pontosan egy szűrő megadása szükséges.")
        filtered_kurzusok = [
            kurzus for kurzus in fajl_kezelo.kurzusok_olvasas()
            if (nap_idopont is None or kurzus["nap_idopont"] == nap_idopont) and
               (oktato_email is None or kurzus["oktato"]["email"] == oktato_email) and
               (tipus is None or kurzus["tipus"] == tipus) and
               (evfolyam is None or kurzus["evfolyam"] == evfolyam) and
               (helyszin is None or kurzus["helyszin"] == helyszin) and
               (max_letszam is None or kurzus["max_letszam"] == max_letszam)
        ]
        return filtered_kurzusok
    except HTTPException as http_x:
        raise http_x
    except Exception:
        raise HTTPException(status_code=500, detail="Hiba a szűrés során.")

@utvonal.get("/kurzusok/filters", response_model=List[Kurzus])
async def get_kurzusok_filters(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    szurt_kurzusok = [
        kurzus for kurzus in kurzusok 
        if sum([bool(nap_idopont and kurzus['nap_idopont'] == nap_idopont),
                bool(oktato_email and kurzus['oktato']['email'] == oktato_email),
                bool(tipus and kurzus['tipus'] == tipus),
                bool(evfolyam and kurzus['evfolyam'] == evfolyam),
                bool(helyszin and kurzus['helyszin'] == helyszin),
                bool(max_letszam and kurzus['max_letszam'] == max_letszam)]) == 2
    ]
    return szurt_kurzusok

@utvonal.put("/kurzusok/{kurzus_id}", response_model=Kurzus)
async def update_kurzus(kurzus_id: int, kurzus: Kurzus):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    for i, k in enumerate(kurzusok):
        if k['id'] == kurzus_id:
            kurzusok[i] = kurzus.dict()
            fajl_kezelo.kurzusok_iras(kurzusok)
            return kurzus
    raise HTTPException(status_code=404, detail="Kurzus nem található.")

@utvonal.get("/kurzusok/hallgatok/{hallgato_id}", response_model=List[Kurzus])
async def get_hallgato_kurzusai(hallgato_id: int):
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()
        hallgato_kurzusai = [k for k in kurzusok if any(h['id'] == hallgato_id for h in k['hallgatok'])]
        return hallgato_kurzusai
    except HTTPException as http_x:
        raise http_x

@utvonal.delete("/kurzusok/{kurzus_id}")
async def delete_kurzus(kurzus_id: int):
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()
        index = next((i for i, k in enumerate(kurzusok) if k["id"] == kurzus_id), None)
        if index is None:
            raise HTTPException(status_code=404, detail="Kurzus nem található.")
        del kurzusok[index]
        fajl_kezelo.kurzusok_iras(kurzusok)
        return {"uzenet": "Kurzus törölve."}
    except HTTPException as http_x:
        raise http_x

@utvonal.get("/kurzusok/{kurzus_id}/hallgatok/{hallgato_id}", response_model=Valasz)
async def get_hallgato_kurzuson(kurzus_id: int, hallgato_id: int):
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()
        for kurzus in kurzusok:
            if kurzus['id'] == kurzus_id:
                if any(hallgato['id'] == hallgato_id for hallgato in kurzus['hallgatok']):
                    return Valasz(uzenet="Igen")
                return Valasz(uzenet= "Nem" )
    except HTTPException as http_x:
        raise http_x