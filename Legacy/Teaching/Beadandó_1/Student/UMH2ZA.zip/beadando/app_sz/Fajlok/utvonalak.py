##BÁLINT MARTIN ATTILA
##NEPTUN-KÓD: UMH2ZA

from fastapi import APIRouter, HTTPException
from typing import List
from .modellek import Kurzus, Valasz
from .fajl_kezeles import KurzusFajlKezelo

utvonal = APIRouter()

fajl_kezelo = KurzusFajlKezelo()

@utvonal.get("/kurzusok", response_model=List[Kurzus])
async def get_osszes_kurzus():
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    return kurzusok

@utvonal.post("/kurzusok", response_model=Valasz)
async def uj_kurzus(kurzus: Kurzus):
    kurzusok = fajl_kezelo.kurzusok_olvasas()

    kurzus_ids = [kurzus['id'] for kurzus in kurzusok]
    if kurzus.id in kurzus_ids:
        raise HTTPException(status_code=400, detail="Ez a kurzus id már foglalt.")

    kurzusok.append(kurzus.model_dump())
    fajl_kezelo.kurzusok_iras(kurzusok)
    return Valasz(uzenet = "Sikeres felvétel.")

@utvonal.get("/kurzusok/filter", response_model=List[Kurzus])
async def get_kurzusok_filter(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: int = None, helyszin: str = None, max_letszam: int = None):
    kurzusok = fajl_kezelo.kurzusok_olvasas()

    filters = {
        "nap_idopont": nap_idopont,
        "oktato_email": oktato_email,
        "tipus": tipus,
        "evfolyam": evfolyam,
        "helyszin": helyszin,
        "max_letszam": max_letszam
    }

    filters = {k: v for k, v in filters.items() if v is not None}
    if not filters:
        return kurzusok
    elif len(filters) != 1:
        raise HTTPException(status_code=400, detail="Pontosan egy szűrőt kell kiválasztani.")

    [(k, v)] = [(k, v) for k, v in filters.items() if v is not None]
    kurzusok_filtered = [
        kurzus for kurzus in kurzusok
        if kurzus.get(k) == v
    ]

    return kurzusok_filtered

@utvonal.get("/kurzusok/filters", response_model=List[Kurzus])
async def get_kurzusok_filters(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: int = None, helyszin: str = None, max_letszam: int = None):
    kurzusok = fajl_kezelo.kurzusok_olvasas()

    filters = {
        "nap_idopont": nap_idopont,
        "oktato_email": oktato_email,
        "tipus": tipus,
        "evfolyam": evfolyam,
        "helyszin": helyszin,
        "max_letszam": max_letszam
    }

    filters = {k: v for k, v in filters.items() if v is not None}
    if not filters:
        return kurzusok
    elif len(filters) != 2:
        raise HTTPException(status_code=400, detail="Pontosan két szűrőt kell kiválasztani.")

    (f1, v1), (f2, v2) = filters.items()

    kurzusok_filtered = [
        course for course in kurzusok
        if course.get(f1) == v1 and course.get(f2) == v2
    ]

    return kurzusok_filtered
    
@utvonal.put("/kurzusok/{kurzus_id}", response_model=Kurzus)
async def update_kurzus(kurzus_id: int, kurzus: Kurzus):
    kurzusok = fajl_kezelo.kurzusok_olvasas()

    # kurzus_ids = [kurzus['id'] for kurzus in kurzusok]
    # if kurzus_id not in kurzus_ids:
    #     raise HTTPException(status_code=404, detail="Kurzus nem található.")

    if kurzus_id != kurzus.id:
        raise HTTPException(status_code=400, detail="A kurzusazonosító nem módosítható.")

    index = next((i for i, d in enumerate(kurzusok) if d['id'] == kurzus_id), None)

    if index is None:
        raise HTTPException(status_code=404, detail="Kurzus nem található.")

    kurzusok[index] = kurzus.model_dump()
    fajl_kezelo.kurzusok_iras(kurzusok)
    return kurzus

@utvonal.get("/kurzusok/hallgatok/{hallgato_id}", response_model=List[Kurzus])
async def get_hallgato_kurzusai(hallgato_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()

    hallgato_kurzusai = [
        kurzus for kurzus in kurzusok
        if any(d['id'] == hallgato_id for d in kurzus['hallgatok'])
    ]

    if not hallgato_kurzusai:
        raise HTTPException(status_code=404, detail="Hallgató nem található.")

    return hallgato_kurzusai

@utvonal.delete("/kurzusok/{kurzus_id}")
async def delete_kurzus(kurzus_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()

    index = next((i for i, d in enumerate(kurzusok) if d['id'] == kurzus_id), None)

    if index is None:
        raise HTTPException(status_code=404, detail="Kurzus nem található.")

    kurzusok.pop(index)
    fajl_kezelo.kurzusok_iras(kurzusok)

@utvonal.get("/kurzusok/{kurzus_id}/hallgatok/{hallgato_id}", response_model=Valasz)
async def get_hallgato_kurzuson(kurzus_id: int, hallgato_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()

    index = next((i for i, d in enumerate(kurzusok) if d['id'] == kurzus_id), None)

    if index is None:
        raise HTTPException(status_code=404, detail="Kurzus nem található.")

    message = "Igen" if any(d['id'] == hallgato_id for d in kurzusok[index]['hallgatok']) else "Nem"
    return Valasz(uzenet= message)