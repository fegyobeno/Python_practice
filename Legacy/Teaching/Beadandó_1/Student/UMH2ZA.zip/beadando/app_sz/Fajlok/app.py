from fastapi import FastAPI
from .utvonalak import utvonal, get_osszes_kurzus, fajl_kezelo

app = FastAPI()

app.include_router(utvonal, tags=["Kurzusok"])


@app.get("/", tags=["Root"])
async def read_root():
    return {"uzenet": "Üdvözöllek a Szakácsképző Intézmény FastAPI alkalmazásában!"}



