import json
from fastapi import APIRouter, HTTPException
from typing import List
from .modellek import Kurzus, Valasz
from .fajl_kezeles import KurzusFajlKezelo


utvonal = APIRouter()

class KurzusFajlKezelo:
    utvonal = "kurzusok.json"

    def kurzusok_olvasas(self):
        try:
            with open(self.utvonal, "r") as be:
                kurzusok = json.load(be)
        except json.JSONDecodeError:
            return []
        except FileNotFoundError:
            return []
        return kurzusok

    def kurzusok_iras(self, kurzusok):
        with open(self.utvonal, "w") as ki:
            json.dump(kurzusok, ki, indent=4)

fajl_kezelo = KurzusFajlKezelo()

@utvonal.get("/kurzusok", response_model=List[Kurzus])
async def get_osszes_kurzus():
    return fajl_kezelo.kurzusok_olvasas()

@utvonal.post("/kurzusok", response_model=Valasz)
async def uj_kurzus(kurzus: Kurzus):
    try:
        json_adat = fajl_kezelo.kurzusok_olvasas()
        for existing_kurzus in json_adat:
            if existing_kurzus['id'] == kurzus.id:
                raise HTTPException(status_code=400, detail="Ez a kurzus id már foglalt")
        json_adat.append(kurzus.dict())  # Kurzus objektum átalakítása dictionaryvé
        fajl_kezelo.kurzusok_iras(json_adat)
        return Valasz(uzenet="Sikeres felvétel.")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@utvonal.get("/kurzusok/filter", response_model=List[Kurzus])
async def get_kurzusok_filter(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()
        filtered_kurzusok = []

        for kurzus in kurzusok:
            if nap_idopont and kurzus['nap_idopont'] != nap_idopont:
                continue
            if oktato_email and kurzus['oktato_email'] != oktato_email:
                continue
            if tipus and kurzus['tipus'] != tipus:
                continue
            if evfolyam and kurzus['evfolyam'] != evfolyam:
                continue
            if helyszin and kurzus['helyszin'] != helyszin:
                continue
            if max_letszam and kurzus['max_letszam'] != max_letszam:
                continue
            filtered_kurzusok.append(kurzus)

        return filtered_kurzusok

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@utvonal.get("/kurzusok/filters", response_model=List[Kurzus])
async def get_kurzusok_filters(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    try:
        filters = {
            "nap_idopont": nap_idopont,
            "oktato_email": oktato_email,
            "tipus": tipus,
            "evfolyam": evfolyam,
            "helyszin": helyszin,
            "max_letszam": max_letszam
        }

        active_filters = {k: v for k, v in filters.items() if v is not None}
        if len(active_filters) != 2:
            raise HTTPException(status_code=400, detail="Pontosan két szűrőt adj meg!")

        kurzusok = fajl_kezelo.kurzusok_olvasas()
        filtered_kurzusok = []

        for kurzus in kurzusok:
            match = True
            for key, value in active_filters.items():
                if kurzus[key] != value:
                    match = False
                    break
            if match:
                filtered_kurzusok.append(kurzus)

        return filtered_kurzusok

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    
@utvonal.put("/kurzusok/{kurzus_id}", response_model=Kurzus)
async def update_kurzus(kurzus_id: int, kurzus: Kurzus):
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()
        for index, existing_kurzus in enumerate(kurzusok):
            if existing_kurzus['id'] == kurzus_id:
                kurzusok[index] = kurzus.dict()  # Kurzus objektum átalakítása dictionaryvé
                fajl_kezelo.kurzusok_iras(kurzusok)
                return kurzus
        raise HTTPException(status_code=404, detail="A kurzus nem található")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@utvonal.get("/kurzusok/hallgatok/{hallgato_id}", response_model=List[Kurzus])
async def get_hallgato_kurzusai(hallgato_id: int):
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()
        hallgato_kurzusai = []

        for kurzus in kurzusok:
            if hallgato_id in kurzus.get('hallgatok', []):
                hallgato_kurzusai.append(kurzus)

        if not hallgato_kurzusai:
            raise HTTPException(status_code=404, detail="A hallgató nem található")

        return hallgato_kurzusai

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@utvonal.delete("/kurzusok/{kurzus_id}", response_model=Valasz)
async def delete_kurzus(kurzus_id: int):
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()
        for index, existing_kurzus in enumerate(kurzusok):
            if existing_kurzus['id'] == kurzus_id:
                del kurzusok[index]
                fajl_kezelo.kurzusok_iras(kurzusok)
                return Valasz(uzenet="Kurzus sikeresen törölve.")
        raise HTTPException(status_code=404, detail="A kurzus nem található")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@utvonal.get("/kurzusok/{kurzus_id}/hallgatok/{hallgato_id}", response_model=Valasz)
async def get_hallgato_kurzuson(kurzus_id: int, hallgato_id: int):
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()
        for kurzus in kurzusok:
            if kurzus['id'] == kurzus_id:
                if hallgato_id in kurzus.get('hallgatok', []):
                    return Valasz(uzenet="Igen")
                else:
                    return Valasz(uzenet="Nem")
        raise HTTPException(status_code=404, detail="A kurzus nem található")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
