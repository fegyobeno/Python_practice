from fastapi import APIRouter, HTTPException
from typing import List
from .modellek import Kurzus, Valasz
from .fajl_kezeles import KurzusFajlKezelo
import json

utvonal = APIRouter()

fajl_kezelo = KurzusFajlKezelo()

@utvonal.get("/kurzusok", response_model=List[Kurzus])
async def get_osszes_kurzus():
    fajlkezelo = KurzusFajlKezelo()
    kurzusok = fajlkezelo.kurzusok_olvasas()
    return kurzusok

@utvonal.post("/kurzusok", response_model=Valasz)
async def uj_kurzus(kurzus: Kurzus):
    fajlkezelo = KurzusFajlKezelo()
    kurzusok = fajlkezelo.kurzusok_olvasas()
    for k in range(len(kurzusok)):
        if kurzusok[k]['id'] == kurzus.id:
            raise HTTPException(status_code=400, detail="Ez a kurzus id már foglalt")
    kurzusok.append(json.loads(json.dumps(kurzus, default=lambda o: o.__dict__)))
    fajlkezelo.kurzusok_iras(kurzusok)
    valasz = {'uzenet' : "Sikeres felvétel."}
    return valasz

@utvonal.get("/kurzusok/filter", response_model=List[Kurzus])
async def get_kurzusok_filter(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    if nap_idopont == None and oktato_email == None and tipus == None and evfolyam == None and helyszin == None and max_letszam == None:
        raise HTTPException(status_code=400, detail="A kötelező a filter az alábbiak közül: nap-időpont, oktató email címe, típus, évfolyam, helyszín és maximális létszám.!")
    
    params = [nap_idopont, oktato_email, tipus, evfolyam, helyszin, max_letszam]
    non_none_count = sum(param is not None for param in params)
    if non_none_count != 1:
        raise HTTPException(status_code=400, detail="Pontosan egy filter szükséges!")
    
    fajlkezelo = KurzusFajlKezelo()
    kurzusok = fajlkezelo.kurzusok_olvasas()
    response = []
    for k in range(len(kurzusok)):
        if nap_idopont is not None and kurzusok[k]["nap_idopont"] == nap_idopont:
            response.append(kurzusok[k])
        if oktato_email is not None and kurzusok[k]["oktato"]["email"] == oktato_email:
            response.append(kurzusok[k])
        if tipus is not None and kurzusok[k]["tipus"] == tipus:
            response.append(kurzusok[k])
        if evfolyam is not None and kurzusok[k]["evfolyam"] == evfolyam:
            response.append(kurzusok[k])
        if helyszin is not None and kurzusok[k]["helyszin"] == helyszin:
            response.append(kurzusok[k])
        if max_letszam is not None and kurzusok[k]["max_letszam"] == max_letszam:
            response.append(kurzusok[k])
    return response

@utvonal.get("/kurzusok/filters", response_model=List[Kurzus])
async def get_kurzusok_filters(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    if nap_idopont == None and oktato_email == None and tipus == None and evfolyam == None and helyszin == None and max_letszam == None:
        raise HTTPException(status_code=400, detail="A kötelező a filter az alábbiak közül: nap-időpont, oktató email címe, típus, évfolyam, helyszín és maximális létszám.!")
    
    params = [nap_idopont, oktato_email, tipus, evfolyam, helyszin, max_letszam]
    non_none_count = sum(param is not None for param in params)
    if non_none_count != 2:
        raise HTTPException(status_code=400, detail="Pontosan kettő filter szükséges!")
    
    fajlkezelo = KurzusFajlKezelo()
    kurzusok = fajlkezelo.kurzusok_olvasas()
    response = []
    for k in range(len(kurzusok)):
        checker = 0
        if nap_idopont is not None and kurzusok[k]["nap_idopont"] == nap_idopont:
            checker += 1
        if oktato_email is not None and kurzusok[k]["oktato"]["email"] == oktato_email:
            checker += 1
        if tipus is not None and kurzusok[k]["tipus"] == tipus:
            checker += 1
        if evfolyam is not None and kurzusok[k]["evfolyam"] == evfolyam:
            checker += 1
        if helyszin is not None and kurzusok[k]["helyszin"] == helyszin:
            checker += 1
        if max_letszam is not None and kurzusok[k]["max_letszam"] == max_letszam:
            checker += 1
        if checker == 2:
            response.append(kurzusok[k])
    
    return response
    
@utvonal.put("/kurzusok/{kurzus_id}", response_model=Kurzus)
async def update_kurzus(kurzus_id: int, kurzus: Kurzus):
    fajlkezelo = KurzusFajlKezelo()
    kurzusok = fajlkezelo.kurzusok_olvasas()
    for k in range(len(kurzusok)):
        if kurzusok[k]['id'] == kurzus_id:
            kurzus_new = json.dumps(kurzus, default=lambda o: o.__dict__)
            kurzusok[k] = json.loads(kurzus_new)
            fajlkezelo.kurzusok_iras(kurzusok)
            return json.loads(kurzus_new)
    raise HTTPException(status_code=404, detail="Ez a kurzus id nem létezik!")

@utvonal.get("/kurzusok/hallgatok/{hallgato_id}", response_model=List[Kurzus])
async def get_hallgato_kurzusai(hallgato_id: int):
    fajlkezelo = KurzusFajlKezelo()
    kurzusok = fajlkezelo.kurzusok_olvasas()
    response = []
    for k in range(len(kurzusok)):
        for h in range(len(kurzusok[k]['hallgatok'])):
            if kurzusok[k]['hallgatok'][h]['id'] == hallgato_id:
                response.append(kurzusok[k])
    if  not response:
        HTTPException(status_code=404, detail="Ez a hallgató nem létezik!")
    return response


@utvonal.delete("/kurzusok/{kurzus_id}")
async def delete_kurzus(kurzus_id: int):
    fajlkezelo = KurzusFajlKezelo()
    kurzusok = fajlkezelo.kurzusok_olvasas()
    for k in range(len(kurzusok)):
        if kurzusok[k]['id'] == kurzus_id:
            kurzusok.pop(k)
            fajlkezelo.kurzusok_iras(kurzusok)
            return
    raise HTTPException(status_code=404, detail="Ez a kurzus id nem létezik!")

@utvonal.get("/kurzusok/{kurzus_id}/hallgatok/{hallgato_id}", response_model=Valasz)
async def get_hallgato_kurzuson(kurzus_id: int, hallgato_id: int):
    fajlkezelo = KurzusFajlKezelo()
    kurzusok = fajlkezelo.kurzusok_olvasas()
    found = False
    for k in range(len(kurzusok)):
        if kurzusok[k]['id'] != kurzus_id:
            continue
        found = True
        for h in range(len(kurzusok[k]['hallgatok'])):
            if kurzusok[k]['hallgatok'][h]['id'] == hallgato_id:
                valasz = {'uzenet' : "Igen"}
                return valasz
    if not found:
        raise HTTPException(status_code=404, detail="Ez a kurzus id nem létezik!")
    valasz = {'uzenet' : "Nem"}
    return valasz
