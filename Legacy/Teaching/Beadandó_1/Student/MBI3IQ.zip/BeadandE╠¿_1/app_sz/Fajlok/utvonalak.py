from fastapi import APIRouter, HTTPException
from typing import List
from .modellek import Kurzus, Valasz
from .fajl_kezeles import KurzusFajlKezelo


utvonal = APIRouter()

fajl_kezelo = KurzusFajlKezelo()

@utvonal.get("/kurzusok", response_model=List[Kurzus])
async def get_osszes_kurzus():
    kurzusok =fajl_kezelo.kurzusok_olvasas()
    if len(kurzusok):
        return kurzusok
    raise HTTPException(status_code=404, detail="Kurzus nem található.")


@utvonal.post("/kurzusok", response_model=Valasz)
async def uj_kurzus(kurzus: Kurzus):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    if len([k for k in kurzusok if k['id'] == kurzus.id]) == 0:
        kurzusok.append(kurzus.dict())
        fajl_kezelo.kurzusok_iras(kurzusok)
        return{'uzenet' : 'Sikeres felvétel.'}
    raise HTTPException(status_code=404, detail='Ez a kurzus id már foglalt!')



@utvonal.get("/kurzusok/filter", response_model=List[Kurzus])
async def get_kurzusok_filter(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    filter_names = ['nap_idopont', 'oktato_email', 'tipus', 'evfolyam', 'helyszin', 'max_letszam']
    filters = [nap_idopont, oktato_email, tipus, evfolyam, helyszin, max_letszam]
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    f = [ i for i in range(0,len(filters)) if  filters[i] is not None]
    if len(f) == 1:
        if filter_names[f[0]] == 'oktato_email':
            kurz = [ k for k in kurzusok if k['oktato']['email'] ==filters[f[0]]]
        else:
            kurz = [ k for k in kurzusok if k[filter_names[f[0]]] ==filters[f[0]]]
        if len(kurz):
            return kurz
        raise HTTPException(status_code=404, detail="Nem található ilyen kurzus!")
    raise HTTPException(status_code=404, detail="Több filter lett megadva!")

@utvonal.get("/kurzusok/filters", response_model=List[Kurzus])
async def get_kurzusok_filters(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    filter_names = ['nap_idopont', 'oktato_email', 'tipus', 'evfolyam', 'helyszin', 'max_letszam']
    filters = [nap_idopont, oktato_email, tipus, evfolyam, helyszin, max_letszam]
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    f = [ i for i in range(0,len(filters)) if  filters[i] is not None]
    if len(f) == 2:
        if filter_names[f[0]] == 'oktato_email' or filter_names[f[1]] == 'oktato_email' :
            try:
                kurz = [ k for k in kurzusok if (k['oktato']['email'] == filters[f[0]] and k[filter_names[f[1]]] ==filters[f[1]])]
            except:
                kurz = [k for k in kurzusok if (k[filter_names[f[0]]] ==filters[f[0]] and k['oktato']['email'] == filters[f[1]])]
        else:
            kurz = [ k for k in kurzusok if k[filter_names[f[0]]] ==filters[f[0]] and k[filter_names[f[1]]] ==filters[f[1]]]
        if len(kurz):
            return kurz
        raise HTTPException(status_code=404, detail="Nem található ilyen kurzus!")
    raise HTTPException(status_code=404, detail="Nem két filter lett megadva!")
    
@utvonal.put("/kurzusok/{kurzus_id}", response_model=Kurzus)
async def update_kurzus(kurzus_id: int, kurzus: Kurzus):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    index = [ i for i in range(0,len(kurzusok)) if kurzusok[i]['id'] == kurzus_id]
    if len(index):
        kurzusok[index[0]] = kurzus.dict()
        fajl_kezelo.kurzusok_iras(kurzusok)
        return kurzus
    raise HTTPException(status_code=404, detail="Nem található kurzus!")


@utvonal.get("/kurzusok/hallgatok/{hallgato_id}", response_model=List[Kurzus])
async def get_hallgato_kurzusai(hallgato_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    eredmeny = [k for k in kurzusok if [h for h in k['hallgatok'] if h['id']==hallgato_id]]
    if len(eredmeny):
        return eredmeny
    raise HTTPException(status_code=404, detail="Nincsenek a hallgatónak kurzusai!")

@utvonal.delete("/kurzusok/{kurzus_id}")
async def delete_kurzus(kurzus_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    index = [ i for i in range(0,len(kurzusok)) if kurzusok[i]['id'] == kurzus_id]
    if len(index):
        kurzusok.pop(index[0])
        fajl_kezelo.kurzusok_iras(kurzusok)
        return {'uzenet' : 'Sikeres törlés'}
    raise HTTPException(status_code=404, detail="Nem található kurzus!")

@utvonal.get("/kurzusok/{kurzus_id}/hallgatok/{hallgato_id}", response_model=Valasz)
async def get_hallgato_kurzuson(kurzus_id: int, hallgato_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    eredmeny = [k for k in kurzusok if k['id'] == kurzus_id and [h for h in k['hallgatok'] if h['id']==hallgato_id]]
    if len(eredmeny):
        return {'uzenet' : 'Igen'}
    return {'uzenet' : 'Nem'}
