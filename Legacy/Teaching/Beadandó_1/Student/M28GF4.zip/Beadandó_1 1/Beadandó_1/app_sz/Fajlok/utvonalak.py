from fastapi import APIRouter, HTTPException
from typing import List
from .modellek import Kurzus, Valasz
from .fajl_kezeles import KurzusFajlKezelo


utvonal = APIRouter()

fajl_kezelo = KurzusFajlKezelo()
fajl_kezelo.utvonal = ("kurzusok.json")

@utvonal.get("/kurzusok", response_model=List[Kurzus])
async def get_osszes_kurzus():
    try:
        data = fajl_kezelo.kurzusok_olvasas()
        return data
    except Exception as e:
        raise HTTPException(status_code=404, detail=str(e))


@utvonal.post("/kurzusok", response_model=Valasz)
async def uj_kurzus(kurzus: Kurzus):
    try:
        data = fajl_kezelo.kurzusok_olvasas()
        if any(i["id"] == kurzus.id for i in data):
            raise HTTPException(status_code=400, detail="Ez a kurzus id már foglalt")
        data.append(kurzus.dict())
        fajl_kezelo.kurzusok_iras(data)
        return Valasz(uzenet="Sikeres felvétel.")
    except Exception as e:
        raise HTTPException(status_code=404, detail=str(e))

@utvonal.get("/kurzusok/filter", response_model=List[Kurzus])
async def get_kurzusok_filter(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    try:
        data = fajl_kezelo.kurzusok_olvasas()

        filters = [
        (nap_idopont, lambda k: k["nap_idopont"] == nap_idopont),
        (oktato_email, lambda k: k["oktato"]["email"] == oktato_email),
        (tipus, lambda k: k["tipus"] == tipus),
        (evfolyam, lambda k: k["evfolyam"] == int(evfolyam)),
        (helyszin, lambda k: k["helyszin"] == helyszin),
        (max_letszam, lambda k: k["max_letszam"] <= max_letszam),
        ]

        active_filters = [func for value, func in filters if value is not None]

        if len(active_filters) != 1:
            raise HTTPException(status_code=400, detail="Pontosan egy szűrőnek kell lennie.")
        
        filter_function = active_filters[0]
        filtered_courses = list(filter(filter_function, data))
        
        return filtered_courses
    except Exception as e:
        raise HTTPException(status_code=404, detail=str(e))


@utvonal.get("/kurzusok/filters", response_model=List[Kurzus])
async def get_kurzusok_filters(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    try:
        data = fajl_kezelo.kurzusok_olvasas()

        filters = [
        (nap_idopont, lambda k: k["nap_idopont"] == nap_idopont),
        (oktato_email, lambda k: k["oktato"]["email"] == oktato_email),
        (tipus, lambda k: k["tipus"] == tipus),
        (evfolyam, lambda k: k["evfolyam"] == int(evfolyam)),
        (helyszin, lambda k: k["helyszin"] == helyszin),
        (max_letszam, lambda k: k["max_letszam"] <= max_letszam),
        ]

        active_filters = [func for value, func in filters if value is not None]

        if len(active_filters) != 2:
            raise HTTPException(status_code=400, detail="Pontosan kettő szűrőnek kell lennie.")
        
        filter_function1 = active_filters[0]
        filter_function2 = active_filters[1]
        filtered_courses = list(filter(filter_function2,filter(filter_function1, data)))
        
        return filtered_courses
    except Exception as e:
        raise HTTPException(status_code=404, detail=str(e))
    
@utvonal.put("/kurzusok/{kurzus_id}", response_model=Kurzus)
async def update_kurzus(kurzus_id: int, kurzus: Kurzus):
    try:
        data = fajl_kezelo.kurzusok_olvasas()
        tempdata = []
        found = False
        for course in data:
            if course["id"] == kurzus_id:
                tempdata.append(kurzus.dict())
                found = True
            else:
                tempdata.append(course)
        if found:
            fajl_kezelo.kurzusok_iras(tempdata)
            return kurzus
        else:
            raise HTTPException(status_code=404, detail="Nem található kurzus ezzel az azonosítóval")
    except Exception as e:
        raise HTTPException(status_code=404, detail=str(e))

@utvonal.get("/kurzusok/hallgatok/{hallgato_id}", response_model=List[Kurzus])
async def get_hallgato_kurzusai(hallgato_id: int):
    try:
        data = fajl_kezelo.kurzusok_olvasas()
        courses = []
        found = False
        for course in data:
            for hallgato in course.get("hallgatok", []):
                if hallgato.get("id") == hallgato_id:
                    courses.append(course)
                    found = True
        if found:        
            return courses
        else:
            raise HTTPException(status_code=404, detail="Nem található hallgató ezzel az azonosítóval")
    except Exception as e:
        raise HTTPException(status_code=404, detail=str(e))

@utvonal.delete("/kurzusok/{kurzus_id}")
async def delete_kurzus(kurzus_id: int):
    try:
        data = fajl_kezelo.kurzusok_olvasas()
        tempdata = []
        found = False
        for course in data:
            if course["id"] == kurzus_id:
                found = True
            else:
                tempdata.append(course)
        if found:
            fajl_kezelo.kurzusok_iras(tempdata)
        else:
            raise HTTPException(status_code=404, detail="Nem található kurzus ezzel az azonosítóval")
    except Exception as e:
        raise HTTPException(status_code=404, detail=str(e))

@utvonal.get("/kurzusok/{kurzus_id}/hallgatok/{hallgato_id}", response_model=Valasz)
async def get_hallgato_kurzuson(kurzus_id: int, hallgato_id: int):
    try:
        data = fajl_kezelo.kurzusok_olvasas()

        for course in data:
            for hallgato in course.get("hallgatok", []):
                if hallgato.get("id") == hallgato_id:
                    return Valasz(uzenet="Igen")
            return Valasz(uzenet="Nem")
        
        raise HTTPException(status_code=404, detail="Course not found")
    except Exception as e:
        raise HTTPException(status_code=404, detail=str(e))
