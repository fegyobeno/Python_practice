from fastapi import APIRouter, HTTPException
from typing import List
from .modellek import Kurzus, Valasz
from .fajl_kezeles import KurzusFajlKezelo


utvonal = APIRouter()

fajl_kezelo = KurzusFajlKezelo()

@utvonal.get("/kurzusok", response_model=List[Kurzus])
async def get_osszes_kurzus():
    try:
        courses = fajl_kezelo.kurzusok_olvasas()
        return courses
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Database file not found")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"An error occured: {e}")

@utvonal.post("/kurzusok", response_model=Valasz)
async def uj_kurzus(kurzus: Kurzus):
    try:
        courses = fajl_kezelo.kurzusok_olvasas()
        if any(course['id'] == kurzus.id for course in courses):
            raise HTTPException(status_code=400, detail="Course id already taken")
        
        courses.append(kurzus.dict())
        fajl_kezelo.kurzusok_iras(courses)
        return Valasz(uzenet="Success")
    
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Database file not found")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"An error occured: {e}")

@utvonal.get("/kurzusok/filter", response_model=List[Kurzus])
async def get_kurzusok_filter(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    try:
        filters = [f for f in [nap_idopont, oktato_email, tipus, evfolyam, helyszin, max_letszam] if f is not None]
        if len(filters) != 1:
            raise HTTPException(status_code=400, detail="Provide only one filter parameter")
        
        courses = fajl_kezelo.kurzusok_olvasas()
        
        if nap_idopont:
            filtered_courses = [course for course in courses if course['nap_idopont'] == nap_idopont]
        elif oktato_email:
            filtered_courses = [course for course in courses if course['oktato']['email'] == oktato_email]
        elif tipus:
            filtered_courses = [course for course in courses if course['tipus'] == tipus]
        elif evfolyam:
            filtered_courses = [course for course in courses if str(course['evfolyam']) == evfolyam]
        elif helyszin:
            filtered_courses = [course for course in courses if course['helyszin'] == helyszin]
        elif max_letszam:
            filtered_courses = [course for course in courses if course['max_letszam'] == max_letszam]
        else:
            filtered_courses = []

        if not filtered_courses:
            raise HTTPException(status_code=404, detail="No course matches filter")
        
        return filtered_courses
    
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Database file not found")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"An error occured: {e}")

@utvonal.get("/kurzusok/filters", response_model=List[Kurzus])
async def get_kurzusok_filters(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    try:
        filters = [(key, val) for key, val in [
            ("nap_idopont", nap_idopont), 
            ("oktato_email", oktato_email), 
            ("tipus", tipus), 
            ("evfolyam", evfolyam), 
            ("helyszin", helyszin), 
            ("max_letszam", max_letszam)
        ] if val is not None]

        if len(filters) != 2:
            raise HTTPException(status_code=400, detail="Provide exactly two filter parameters")

        courses = fajl_kezelo.kurzusok_olvasas()
        filtered_courses = [course for course in courses if all( (course['oktato']['email'] if key == 'oktato_email' else str(course[key])) == val for key, val in filters)]

        if not filtered_courses:
            raise HTTPException(status_code=404, detail="No course matches filters")
        
        return filtered_courses
    
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Database file not found")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"An error occured: {e}")
    
@utvonal.put("/kurzusok/{kurzus_id}", response_model=Kurzus)
async def update_kurzus(kurzus_id: int, kurzus: Kurzus):
    try:
        courses = fajl_kezelo.kurzusok_olvasas()
        for index, course in enumerate(courses):
            if course['id'] == kurzus_id:
                courses[index] = kurzus.dict()
                fajl_kezelo.kurzusok_iras(courses)
                return kurzus
        
        raise HTTPException(status_code=404, detail="Course not found")
    
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Database file not found")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"An error occured: {e}")

@utvonal.get("/kurzusok/hallgatok/{hallgato_id}", response_model=List[Kurzus])
async def get_hallgato_kurzusai(hallgato_id: int):
    try:
        courses = fajl_kezelo.kurzusok_olvasas()
        student_courses = [course for course in courses if any(student['id'] == hallgato_id for student in course['hallgatok'] or [])]

        if not student_courses:
            raise HTTPException(status_code=404, detail="Student not found or student has no courses")
        
        return student_courses
    
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Database file not found")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"An error occured: {e}")

@utvonal.delete("/kurzusok/{kurzus_id}")
async def delete_kurzus(kurzus_id: int):
    try:
        courses = fajl_kezelo.kurzusok_olvasas()
        filtered_courses = [course for course in courses if course['id'] != kurzus_id]

        if len(filtered_courses) == len(courses):
            raise HTTPException(status_code=404, detail="Course not found")
        
        fajl_kezelo.kurzusok_iras(filtered_courses)
        return {"detail":"Success"}
    
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Database file not found")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"An error occured: {e}")

@utvonal.get("/kurzusok/{kurzus_id}/hallgatok/{hallgato_id}", response_model=Valasz)
async def get_hallgato_kurzuson(kurzus_id: int, hallgato_id: int):
    try:
        courses = fajl_kezelo.kurzusok_olvasas()
        course = next((c for c in courses if c['id'] == kurzus_id), None)

        if course is None:
            raise HTTPException(status_code=404, detail="Course not found")
        
        onit = any(student['id'] == hallgato_id for student in course['hallgatok'] or [])
        
        if onit:
            return Valasz(uzenet="Igen")
        else:
            return Valasz(uzenet="Nem")
    
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Database file not found")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"An error occured: {e}")
