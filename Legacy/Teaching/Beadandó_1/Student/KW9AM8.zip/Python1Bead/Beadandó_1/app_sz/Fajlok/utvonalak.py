from fastapi import APIRouter, HTTPException
from typing import List, Optional
from .modellek import Kurzus, Valasz
from .fajl_kezeles import KurzusFajlKezelo

utvonal = APIRouter()
fajl_kezelo = KurzusFajlKezelo()

@utvonal.get("/kurzusok", response_model=List[Kurzus])
async def get_osszes_kurzus():
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    return kurzusok

@utvonal.post("/kurzusok", response_model=Valasz)
async def uj_kurzus(kurzus: Kurzus):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    if any(existing_kurzus['id'] == kurzus.id for existing_kurzus in kurzusok):
        raise HTTPException(status_code=400, detail="Ez a kurzus id már foglalt.")
    kurzusok.append(kurzus.model_dump())
    fajl_kezelo.kurzusok_iras(kurzusok)
    return Valasz(uzenet="Sikeres felvétel.")

@utvonal.get("/kurzusok/filter", response_model=List[Kurzus])
async def get_kurzusok_filter(
    nap_idopont: Optional[str] = None,
    oktato_email: Optional[str] = None,
    tipus: Optional[str] = None,
    evfolyam: Optional[int] = None,
    helyszin: Optional[str] = None,
    max_letszam: Optional[int] = None
):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    filtered_kurzusok = [
        kurzus for kurzus in kurzusok
        if (nap_idopont is None or kurzus["nap_idopont"] == nap_idopont) and
           (oktato_email is None or kurzus["oktato"]["email"] == oktato_email) and
           (tipus is None or kurzus["tipus"] == tipus) and
           (evfolyam is None or kurzus["evfolyam"] == evfolyam) and
           (helyszin is None or kurzus["helyszin"] == helyszin) and
           (max_letszam is None or kurzus["max_letszam"] == max_letszam)
    ]
    if not filtered_kurzusok:
        raise HTTPException(status_code=404, detail="Nincs találat a szűrőfeltételek alapján.")
    return filtered_kurzusok

@utvonal.get("/kurzusok/filters", response_model=List[Kurzus])
async def get_kurzusok_filters(
    nap_idopont: Optional[str] = None,
    oktato_email: Optional[str] = None,
    tipus: Optional[str] = None,
    evfolyam: Optional[int] = None,
    helyszin: Optional[str] = None,
    max_letszam: Optional[int] = None
):
    if sum(1 for param in [nap_idopont, oktato_email, tipus, evfolyam, helyszin, max_letszam] if param is not None) != 2:
        raise HTTPException(status_code=400, detail="Pontosan két szűrőfeltételt kell megadni.")
    
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    filtered_kurzusok = [
        kurzus for kurzus in kurzusok
        if (nap_idopont is None or kurzus["nap_idopont"] == nap_idopont) and
           (oktato_email is None or kurzus["oktato"]["email"] == oktato_email) and
           (tipus is None or kurzus["tipus"] == tipus) and
           (evfolyam is None or kurzus["evfolyam"] == evfolyam) and
           (helyszin is None or kurzus["helyszin"] == helyszin) and
           (max_letszam is None or kurzus["max_letszam"] == max_letszam)
    ]
    if not filtered_kurzusok:
        raise HTTPException(status_code=404, detail="Nincs találat a szűrőfeltételek alapján.")
    return filtered_kurzusok

@utvonal.put("/kurzusok/{kurzus_id}", response_model=Kurzus)
async def update_kurzus(kurzus_id: int, kurzus: Kurzus):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    existing_kurzus = next((k for k in kurzusok if k["id"] == kurzus_id), None)
    if not existing_kurzus:
        raise HTTPException(status_code=404, detail="Kurzus nem található.")
    if kurzus.id != kurzus_id:
        if any(k["id"] == kurzus.id for k in kurzusok):
            raise HTTPException(status_code=400, detail="Ez a kurzus id már foglalt.")
    updated_kurzus = kurzus.model_dump()
    for i, k in enumerate(kurzusok):
        if k["id"] == kurzus_id:
            kurzusok[i] = updated_kurzus
            break
    fajl_kezelo.kurzusok_iras(kurzusok)
    return updated_kurzus


@utvonal.get("/kurzusok/hallgatok/{hallgato_id}", response_model=List[Kurzus])
async def get_hallgato_kurzusai(hallgato_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    hallgato_kurzusai = [
        kurzus for kurzus in kurzusok
        if any(hallgato["id"] == hallgato_id for hallgato in kurzus.get("hallgatok", []))
    ]
    if not hallgato_kurzusai:
        raise HTTPException(status_code=404, detail="Hallgató nem található.")
    return hallgato_kurzusai

@utvonal.delete("/kurzusok/{kurzus_id}", response_model=Valasz)
async def delete_kurzus(kurzus_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    for idx, existing_kurzus in enumerate(kurzusok):
        if existing_kurzus["id"] == kurzus_id:
            del kurzusok[idx]
            fajl_kezelo.kurzusok_iras(kurzusok)
            return Valasz(uzenet="Kurzus sikeresen törölve.")
    raise HTTPException(status_code=404, detail="Kurzus nem található.")

@utvonal.get("/kurzusok/{kurzus_id}/hallgatok/{hallgato_id}", response_model=Valasz)
async def get_hallgato_kurzuson(kurzus_id: int, hallgato_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    for kurzus in kurzusok:
        if kurzus["id"] == kurzus_id:
            if any(hallgato["id"] == hallgato_id for hallgato in kurzus.get("hallgatok", [])):
                return Valasz(uzenet="Igen")
            return Valasz(uzenet="Nem")
    raise HTTPException(status_code=404, detail="Kurzus nem található.")

