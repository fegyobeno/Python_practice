from fastapi import APIRouter, HTTPException
from typing import List
from .modellek import Kurzus, Valasz
from .fajl_kezeles import KurzusFajlKezelo


utvonal = APIRouter()

fajl_kezelo = KurzusFajlKezelo()


@utvonal.get("/kurzusok", response_model=List[Kurzus])
async def get_osszes_kurzus():
    return fajl_kezelo.kurzusok_olvasas()
    # pass


@utvonal.post("/kurzusok", response_model=Valasz)
async def uj_kurzus(kurzus: Kurzus):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    ids = [kurzus["id"] for kurzus in kurzusok]

    if kurzus.id in ids:
        raise HTTPException(status_code=400, detail="Ez a kurzus id már foglalt")

    fajl_kezelo.kurzusok_iras(kurzusok + [kurzus.model_dump()])
    return {"uzenet": "Sikeres felvétel."}
    # pass


@utvonal.get("/kurzusok/filter", response_model=List[Kurzus])
async def get_kurzusok_filter(
    nap_idopont: str = None,
    oktato_email: str = None,
    tipus: str = None,
    evfolyam: str = None,
    helyszin: str = None,
    max_letszam: int = None,
):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    allfilters = [nap_idopont, oktato_email, tipus, evfolyam, helyszin, max_letszam]

    if len([filt for filt in allfilters if filt is not None]) != 1:
        raise HTTPException(status_code=400, detail="Egy filtert kell használni")

    if nap_idopont is not None:
        kurzusok = [
            kurzus for kurzus in kurzusok if kurzus["nap_idopont"] == nap_idopont
        ]

    if oktato_email is not None:
        kurzusok = [
            kurzus for kurzus in kurzusok if kurzus["oktato"]["email"] == oktato_email
        ]

    if tipus is not None:
        kurzusok = [kurzus for kurzus in kurzusok if kurzus["tipus"] == tipus]

    if evfolyam is not None:
        try:
            int(evfolyam)
        except ValueError:
            raise HTTPException(status_code=400, detail="Az évfolyam csak szám lehet")
        kurzusok = [
            kurzus for kurzus in kurzusok if kurzus["evfolyam"] == int(evfolyam)
        ]

    if helyszin is not None:
        kurzusok = [kurzus for kurzus in kurzusok if kurzus["helyszin"] == helyszin]

    if max_letszam is not None:
        kurzusok = [
            kurzus for kurzus in kurzusok if kurzus["max_letszam"] == max_letszam
        ]

    return kurzusok
    # pass


@utvonal.get("/kurzusok/filters", response_model=List[Kurzus])
async def get_kurzusok_filters(
    nap_idopont: str = None,
    oktato_email: str = None,
    tipus: str = None,
    evfolyam: str = None,
    helyszin: str = None,
    max_letszam: int = None,
):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    allfilters = [nap_idopont, oktato_email, tipus, evfolyam, helyszin, max_letszam]

    if len([filt for filt in allfilters if filt is not None]) != 2:
        raise HTTPException(
            status_code=400, detail="Pontosan két filtert kell használni"
        )

    if nap_idopont is not None:
        kurzusok = [
            kurzus for kurzus in kurzusok if kurzus["nap_idopont"] == nap_idopont
        ]

    if oktato_email is not None:
        kurzusok = [
            kurzus for kurzus in kurzusok if kurzus["oktato"]["email"] == oktato_email
        ]

    if tipus is not None:
        kurzusok = [kurzus for kurzus in kurzusok if kurzus["tipus"] == tipus]

    if evfolyam is not None:
        try:
            int(evfolyam)
        except ValueError:
            raise HTTPException(status_code=400, detail="Az évfolyam csak szám lehet")
        kurzusok = [
            kurzus for kurzus in kurzusok if kurzus["evfolyam"] == int(evfolyam)
        ]

    if helyszin is not None:
        kurzusok = [kurzus for kurzus in kurzusok if kurzus["helyszin"] == helyszin]

    if max_letszam is not None:
        kurzusok = [
            kurzus for kurzus in kurzusok if kurzus["max_letszam"] == max_letszam
        ]

    return kurzusok
    # pass


@utvonal.put("/kurzusok/{kurzus_id}", response_model=Kurzus)
async def update_kurzus(kurzus_id: int, kurzus: Kurzus):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    ids = [kurzus["id"] for kurzus in kurzusok]

    if kurzus_id not in ids:
        raise HTTPException(status_code=400, detail="Nincs ilyen id-jű kurzus")

    for k in kurzusok:
        if k["id"] == kurzus_id:
            if kurzus.id != k["id"]:
                raise HTTPException(status_code=400, detail="Az id nem módosítható")
            k.update(kurzus.model_dump())
            break

    fajl_kezelo.kurzusok_iras(kurzusok)
    return kurzus
    # pass


@utvonal.get("/kurzusok/hallgatok/{hallgato_id}", response_model=List[Kurzus])
async def get_hallgato_kurzusai(hallgato_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()

    if not any(
        [
            hallgato_id in [hallgato["id"] for hallgato in kurzus["hallgatok"]]
            for kurzus in kurzusok
        ]
    ):
        raise HTTPException(status_code=400, detail="Nincs ilyen id-jű hallgató")

    hallgato_kurzusai = [
        kurzus
        for kurzus in kurzusok
        if hallgato_id in [hallgato["id"] for hallgato in kurzus["hallgatok"]]
    ]
    return hallgato_kurzusai
    # pass


@utvonal.delete("/kurzusok/{kurzus_id}")
async def delete_kurzus(kurzus_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    ids = [kurzus["id"] for kurzus in kurzusok]

    if kurzus_id not in ids:
        raise HTTPException(status_code=400, detail="Nincs ilyen id-jű kurzus")

    for kurzus in kurzusok:
        if kurzus["id"] == kurzus_id:
            kurzusok.remove(kurzus)
            break

    fajl_kezelo.kurzusok_iras(kurzusok)
    return {"uzenet": "Sikeres törlés"}
    # pass


@utvonal.get("/kurzusok/{kurzus_id}/hallgatok/{hallgato_id}", response_model=Valasz)
async def get_hallgato_kurzuson(kurzus_id: int, hallgato_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    ids = [kurzus["id"] for kurzus in kurzusok]

    if kurzus_id not in ids:
        raise HTTPException(status_code=400, detail="Nincs ilyen id-jű kurzus")

    hallgato_ids = []
    for kurzus in kurzusok:
        for hallgato in kurzus["hallgatok"]:
            hallgato_ids.append(hallgato["id"])

    hallgato_ids = list(set(hallgato_ids))

    if hallgato_id not in hallgato_ids:
        raise HTTPException(status_code=400, detail="Nincs ilyen id-jű hallgató")

    for kurzus in kurzusok:
        if kurzus["id"] == kurzus_id:
            hallgatok = kurzus["hallgatok"]
            for hallgato in hallgatok:
                if hallgato["id"] == hallgato_id:
                    return {"uzenet": "Igen"}
    return {"uzenet": "Nem"}

    # pass
