from fastapi import APIRouter, HTTPException
from typing import List
from .modellek import Kurzus, Valasz
from .fajl_kezeles import KurzusFajlKezelo


utvonal = APIRouter()

fajl_kezelo = KurzusFajlKezelo()

@utvonal.get("/kurzusok", response_model=List[Kurzus])
async def get_osszes_kurzus():
    try:
        return fajl_kezelo.kurzusok_olvasas()
    except:
        return HTTPException(status_code=500, detail=f"Error getting courses")


@utvonal.post("/kurzusok", response_model=Valasz)
async def uj_kurzus(kurzus: Kurzus):
    try:
        newlist = fajl_kezelo.kurzusok_olvasas()
        #print(newlist[0]["id"])
        #print(kurzus.id)
        for k in newlist:
            if(int(k["id"]) == kurzus.id):
                return Valasz(uzenet="Course id occupied")
               #return HTTPException(status_code=501,detail="Course id occupied")
        newlist.append(kurzus.model_dump(mode='json'))
        fajl_kezelo.kurzusok_iras(newlist)
        return Valasz(uzenet="Added successfully")
    except Exception as e:
        return HTTPException(status_code=500, detail=f"Error adding course")

@utvonal.get("/kurzusok/filter", response_model=List[Kurzus])
async def get_kurzusok_filter(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    #print(fajl_kezelo.kurzusok_olvasas()[0]["tipus"])
    #print(tipus)
    #print(nap_idopont)
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()
        fkurzusok = []
        for k in kurzusok:
            #print(type(k["evfolyam"]))
            #print(type(int(evfolyam)))
            if (
                (k["nap_idopont"] == nap_idopont or nap_idopont == None) and
                (k["oktato"]["email"] == oktato_email or oktato_email == None) and
                (k["tipus"] == tipus or tipus == None) and
                (k["evfolyam"] == int(evfolyam) or evfolyam == None) and
                (k["helyszin"] == helyszin or helyszin == None) and
                (k["max_letszam"] == max_letszam or max_letszam == None)
            ):
                fkurzusok.append(k)
        return fkurzusok
    except:
        return HTTPException(status_code=500, detail=f"Error filtering courses")

@utvonal.get("/kurzusok/filters", response_model=List[Kurzus])
async def get_kurzusok_filters(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()
        fkurzusok = []
        for k in kurzusok:
            #print(type(k["evfolyam"]))
            #print(type(int(evfolyam)))
            if (
                (k["nap_idopont"] == nap_idopont or nap_idopont == None) and
                (k["oktato"]["email"] == oktato_email or oktato_email == None) and
                (k["tipus"] == tipus or tipus == None) and
                (k["evfolyam"] == int(evfolyam) or evfolyam == None) and
                (k["helyszin"] == helyszin or helyszin == None) and
                (k["max_letszam"] == max_letszam or max_letszam == None)
            ):
                fkurzusok.append(k)
        return fkurzusok
    except:
        return HTTPException(status_code=500, detail=f"Error filtering courses")
    
@utvonal.put("/kurzusok/{kurzus_id}", response_model=Kurzus)
async def update_kurzus(kurzus_id: int, kurzus: Kurzus):
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()
        newkurzusok = []
        for k in kurzusok:
            if int(k["id"] != kurzus_id):
                newkurzusok.append(k)
        newkurzusok.append(kurzus.model_dump(mode="json"))
        fajl_kezelo.kurzusok_iras(newkurzusok)
        return kurzus
    except:
        return HTTPException(status_code=500,detail="Error updating course")

@utvonal.get("/kurzusok/hallgatok/{hallgato_id}", response_model=List[Kurzus])
async def get_hallgato_kurzusai(hallgato_id: int):
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()
        fkurzusok = []
        for k in kurzusok:
            for h in k["hallgatok"]:
                if int(h["id"]) == hallgato_id:
                    fkurzusok.append(k)
        return fkurzusok
    except:
        return HTTPException(status_code=500,detail="Error getting courses")

@utvonal.delete("/kurzusok/{kurzus_id}")
async def delete_kurzus(kurzus_id: int):
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()
        newkurzusok = []
        for k in kurzusok:
            if int(k["id"] != kurzus_id):
                newkurzusok.append(k)
        fajl_kezelo.kurzusok_iras(newkurzusok)
        return Valasz(uzenet="Course successfully deleted!")
    except:
        return HTTPException(status_code=500,detail="Error deleting course")


@utvonal.get("/kurzusok/{kurzus_id}/hallgatok/{hallgato_id}", response_model=Valasz)
async def get_hallgato_kurzuson(kurzus_id: int, hallgato_id: int):
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()
        for k in kurzusok:
            if int(k["id"]) == kurzus_id:
                for h in k["hallgatok"]:
                    if int(h["id"]) == hallgato_id:
                        return Valasz(uzenet="Hallgato a kurzuson!")
        return Valasz(uzenet="Hallgato nincs a kurzuson!")
    except:
        return HTTPException(status_code=500,detail="Error checking student on course")
