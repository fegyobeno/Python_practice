from fastapi import APIRouter, HTTPException
from typing import List
from .modellek import Kurzus, Valasz
from .fajl_kezeles import KurzusFajlKezelo

utvonal = APIRouter()

fajl_kezelo = KurzusFajlKezelo()

@utvonal.get("/kurzusok", response_model=List[Kurzus])
async def get_osszes_kurzus():
    try:
        return fajl_kezelo.kurzusok_olvasas()
    except Exception:
        raise HTTPException(status_code=500, detail="Hiba történt a kurzusok beolvasása során.")

@utvonal.post("/kurzusok", response_model=Valasz)
async def uj_kurzus(kurzus: Kurzus):
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()
        if any(k["id"] == kurzus.id for k in kurzusok):
            raise HTTPException(status_code=400, detail="Ez a kurzus id már foglalt")
        kurzusok.append(kurzus.dict())
        fajl_kezelo.kurzusok_iras(kurzusok)
        return Valasz(uzenet="Sikeres felvétel.")
    except HTTPException as http_exc:
        raise http_exc
    except Exception:
        raise HTTPException(status_code=500, detail="Hiba történt a kurzus felvétele során.")

@utvonal.get("/kurzusok/filter", response_model=List[Kurzus])
async def get_kurzusok_filter(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: int = None, helyszin: str = None, max_letszam: int = None):
    try:
        filter_count = sum(x is not None for x in [nap_idopont, oktato_email, tipus, evfolyam, helyszin, max_letszam])
        if filter_count != 1:
            raise HTTPException(status_code=400, detail="Pontosan egy szűrő megadása szükséges.")
        szurt_kurzusok = [
            kurzus for kurzus in fajl_kezelo.kurzusok_olvasas()
            if (nap_idopont is None or kurzus["nap_idopont"] == nap_idopont) and
               (oktato_email is None or kurzus["oktato"]["email"] == oktato_email) and
               (tipus is None or kurzus["tipus"] == tipus) and
               (evfolyam is None or kurzus["evfolyam"] == evfolyam) and
               (helyszin is None or kurzus["helyszin"] == helyszin) and
               (max_letszam is None or kurzus["max_letszam"] == max_letszam)
        ]
        return szurt_kurzusok
    except HTTPException as http_exc:
        raise http_exc
    except Exception:
        raise HTTPException(status_code=500, detail="Hiba történt a szűrés során.")

@utvonal.get("/kurzusok/filters", response_model=List[Kurzus])
async def get_kurzusok_filters(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: int = None, helyszin: str = None, max_letszam: int = None):
    try:
        if 2 != sum(x is not None for x in [nap_idopont, oktato_email, tipus, evfolyam, helyszin, max_letszam]):
            raise HTTPException(status_code=400, detail="Pontosan két szűrőt kell megadni.")
        kurzusok = fajl_kezelo.kurzusok_olvasas()
        szurt_kurzusok = [
            kurzus for kurzus in kurzusok
            if (nap_idopont is None or kurzus["nap_idopont"] == nap_idopont) and
               (oktato_email is None or kurzus["oktato"]["email"] == oktato_email) and
               (tipus is None or kurzus["tipus"] == tipus) and
               (evfolyam is None or kurzus["evfolyam"] == evfolyam) and
               (helyszin is None or kurzus["helyszin"] == helyszin) and
               (max_letszam is None or kurzus["max_letszam"] == max_letszam)
        ]
        return szurt_kurzusok
    except HTTPException as http_exc:
        raise http_exc
    except Exception:
        raise HTTPException(status_code=500, detail="Hiba történt a szűrés során.")
        
@utvonal.put("/kurzusok/{kurzus_id}", response_model=Kurzus)
async def update_kurzus(kurzus_id: int, kurzus: Kurzus):
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()
        index = next((i for i, k in enumerate(kurzusok) if k["id"] == kurzus_id), None)
        if index is None:
            raise HTTPException(status_code=404, detail="Kurzus nem található.")
        kurzusok[index] = kurzus.dict()
        fajl_kezelo.kurzusok_iras(kurzusok)
        return kurzus
    except HTTPException as http_exc:
        raise http_exc
    except Exception:
        raise HTTPException(status_code=500, detail="Hiba történt a kurzus frissítése során.")

@utvonal.get("/kurzusok/hallgatok/{hallgato_id}", response_model=List[Kurzus])
async def get_hallgato_kurzusai(hallgato_id: int):
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()
        hallgato_kurzusai = [kurzus for kurzus in kurzusok if any(h["id"] == hallgato_id for h in kurzus["hallgatok"])]
        if not hallgato_kurzusai:
            raise HTTPException(status_code=404, detail="Hallgató kurzusai nem találhatóak.")
        return hallgato_kurzusai
    except HTTPException as http_exc:
        raise http_exc
    except Exception:
        raise HTTPException(status_code=500, detail="Hiba történt a hallgató kurzusainak listázása során.")

@utvonal.delete("/kurzusok/{kurzus_id}")
async def delete_kurzus(kurzus_id: int):
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()
        index = next((i for i, k in enumerate(kurzusok) if k["id"] == kurzus_id), None)
        if index is None:
            raise HTTPException(status_code=404, detail="Kurzus nem található.")
        del kurzusok[index]
        fajl_kezelo.kurzusok_iras(kurzusok)
        return {"uzenet": "Kurzus törölve."}
    except HTTPException as http_exc:
        raise http_exc
    except Exception:
        raise HTTPException(status_code=500, detail="Hiba történt a kurzus törlése során.")

@utvonal.get("/kurzusok/{kurzus_id}/hallgatok/{hallgato_id}", response_model=Valasz)
async def get_hallgato_kurzuson(kurzus_id: int, hallgato_id: int):
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()
        kurzus = next((k for k in kurzusok if k["id"] == kurzus_id), None)
        if kurzus is None:
            raise HTTPException(status_code=404, detail="Kurzus nem található.")
        van_hallgato = any(h["id"] == hallgato_id for h in kurzus["hallgatok"])
        return Valasz(uzenet="Igen" if van_hallgato else "Nem")
    except HTTPException as http_exc:
        raise http_exc
    except Exception:
        raise HTTPException(status_code=500, detail="Hiba történt a hallgató keresése során.")
