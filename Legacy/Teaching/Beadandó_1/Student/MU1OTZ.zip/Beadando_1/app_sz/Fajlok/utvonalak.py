from fastapi import APIRouter, HTTPException
from typing import List
from .modellek import Kurzus, Valasz
from .fajl_kezeles import KurzusFajlKezelo


utvonal = APIRouter()

fajl_kezelo = KurzusFajlKezelo()

@utvonal.get("/kurzusok", response_model=List[Kurzus])
async def get_osszes_kurzus():
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    return kurzusok

@utvonal.post("/kurzusok", response_model=Valasz)
async def uj_kurzus(kurzus: Kurzus):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    if kurzus.id in [x['id'] for x in kurzusok]:
        raise HTTPException(status_code= 422, detail="Ez a kurzus id már foglalt")

    kurzusok.append(kurzus.model_dump())
    fajl_kezelo.kurzusok_iras(kurzusok)
    return {"uzenet": "Sikeres felvétel"}

@utvonal.get("/kurzusok/filter", response_model=List[Kurzus])
async def get_kurzusok_filter(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    l = {"nap_idopont": nap_idopont,"oktato_email": oktato_email,"tipus": tipus,"evfolyam": evfolyam, 
    "helyszin": helyszin,"max_letszam": max_letszam}
    filtered = list(filter(lambda x: x[1] != None, l.items()))
    if len(filtered) != 1:
        raise HTTPException(status_code= 422, detail="Nem 1 szűrő lett megadva")
    kurzusok = fajl_kezelo.kurzusok_olvasas()

    if filtered[0][0] == "oktato_email":
        s = filtered[0][0].split("_")
        return filter(lambda x: x[s[0]][s[1]] == filtered[0][1], kurzusok)

    return filter(lambda x: str(x[ filtered[0][0] ]) == str(filtered[0][1]), kurzusok)

@utvonal.get("/kurzusok/filters", response_model=List[Kurzus])
async def get_kurzusok_filters(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    l = {"nap_idopont": nap_idopont,"oktato_email": oktato_email,"tipus": tipus,"evfolyam": evfolyam, 
    "helyszin": helyszin,"max_letszam": max_letszam}
    filtered = list(filter(lambda x: x[1] != None, l.items()))
    if len(filtered) != 2:
        raise HTTPException(status_code= 422, detail="Nem 2 szűrő lett megadva")
    kurzusok = fajl_kezelo.kurzusok_olvasas()

    if filtered[0][0] == "oktato_email":
        s = filtered[0][0].split("_")
        return filter(lambda x: x[s[0]][s[1]] == filtered[0][1] and str(x[filtered[1][0]]) == str(filtered[1][1]), kurzusok)
    
    if filtered[1][0] == "oktato_email":
        s = filtered[1][0].split("_")
        return filter(lambda x: x[s[0]][s[1]] == filtered[1][1] and str(x[filtered[0][0]]) == str(filtered[0][1]), kurzusok)

    return filter(lambda x: str(x[ filtered[0][0] ]) == str(filtered[0][1]) and str(x[ filtered[1][0] ]) == str(filtered[1][1]), kurzusok)
    
@utvonal.put("/kurzusok/{kurzus_id}", response_model=Kurzus)
async def update_kurzus(kurzus_id: int, kurzus: Kurzus):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    if kurzus_id not in [x['id'] for x in kurzusok]:
        raise HTTPException(status_code= 422, detail="Nincs ilyen id-val rendelkező kurzus")
    if kurzus.id in [x['id'] for x in kurzusok] and kurzus_id != kurzus.id:
        raise HTTPException(status_code= 422, detail="Ez a kurzus id már foglalt")

    kurzusoktemp = [x if x['id'] != kurzus_id else kurzus.model_dump() for x in kurzusok]
    fajl_kezelo.kurzusok_iras(kurzusoktemp)
    return kurzus

@utvonal.get("/kurzusok/hallgatok/{hallgato_id}", response_model=List[Kurzus])
async def get_hallgato_kurzusai(hallgato_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    filtered = filter(lambda x: hallgato_id in [y['id'] for y in x['hallgatok']], kurzusok)

    if not filtered:
        raise HTTPException(status_code= 422, detail="Nem vett fel kurzust a hallgato")

    return filtered


@utvonal.delete("/kurzusok/{kurzus_id}")
async def delete_kurzus(kurzus_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    if kurzus_id not in [x['id'] for x in kurzusok]:
        raise HTTPException(status_code= 422, detail="A kurzus nem található")

    kurzusok = [x for x in kurzusok if x['id'] != kurzus_id]
    fajl_kezelo.kurzusok_iras(kurzusok)
    return "Sikeres kurzus törlés"

@utvonal.get("/kurzusok/{kurzus_id}/hallgatok/{hallgato_id}", response_model=Valasz)
async def get_hallgato_kurzuson(kurzus_id: int, hallgato_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    if kurzus_id not in [x['id'] for x in kurzusok]:
        raise HTTPException(status_code= 422, detail="A kurzus nem található")
    kurzus = [x for x in kurzusok if x['id'] == kurzus_id]

    if hallgato_id not in [x['id'] for x in kurzus[0]['hallgatok']]:
        return {"uzenet": "Nem"}
    return {"uzenet": "Igen"}