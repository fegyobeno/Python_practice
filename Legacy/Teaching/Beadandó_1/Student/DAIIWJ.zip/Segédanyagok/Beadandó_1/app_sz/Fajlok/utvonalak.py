from fastapi import APIRouter, HTTPException
from typing import List
from .modellek import Kurzus, Valasz
from .fajl_kezeles import KurzusFajlKezelo

utvonal = APIRouter()

fajl_kezelo = KurzusFajlKezelo()


# fajl_kezeles.py fájl kurzusok_olvasas metódusát kiegészítettem:

#     def kurzusok_olvasas(self):
#         try:
#             with open(self.utvonal, "r") as be:
#                 kurzusok = json.load(be)
#         except FileNotFoundError:
#             return []
#         except json.decoder.JSONDecodeError:      # új sor
#             return []                             # új sor
#         return kurzusok

KURZUS_TIPUS_ELLENORZES = False # Nem voltam biztos benne, hogy ellenőrizni kell -e a kurzus adattagjait

@utvonal.get("/kurzusok", response_model=List[Kurzus])
async def get_osszes_kurzus():
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    return fajl_kezelo.kurzusok_olvasas()

@utvonal.post("/kurzusok", response_model=Valasz)
async def uj_kurzus(kurzus: Kurzus):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    kurzus_idk = list(map(lambda k: k['id'], kurzusok))
    if kurzus.id in kurzus_idk:
        return {'uzenet' : 'Ez a kurzus id már foglalt'}
    else:
        if KURZUS_TIPUS_ELLENORZES and not (kurzus.tipus in ['ea', 'gy'] and kurzus.evfolyam in [1,2,3] and kurzus.max_letszam >= 0):
            return {'uzenet' : 'Nem megfelelő kurzus adatok.'}
        kurzusok.append(kurzus.model_dump())
        fajl_kezelo.kurzusok_iras(kurzusok)
        return {'uzenet' : 'Sikeres felvétel.'}

@utvonal.get("/kurzusok/filter", response_model=List[Kurzus])
async def get_kurzusok_filter(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    megadott_filterek = sum(map(lambda x: 1 if x is not None else 0, [nap_idopont, oktato_email, tipus, evfolyam, helyszin, max_letszam]))
    
    if megadott_filterek != 1:
        raise HTTPException(status_code=422, detail="Pontosan egy szűrőt kell megadni.") 
    
    if nap_idopont is not None:
        return list(filter(lambda k: k['nap_idopont'] == nap_idopont, kurzusok))
    elif oktato_email is not None:
        return list(filter(lambda k: k['oktato']['email'] == oktato_email, kurzusok))
    elif tipus is not None:
        return list(filter(lambda k: k['tipus'] == tipus, kurzusok))
    elif evfolyam is not None:
        return list(filter(lambda k: k['evfolyam'] == evfolyam, kurzusok))
    elif helyszin is not None:
        return list(filter(lambda k: k['helyszin'] == helyszin, kurzusok))
    elif max_letszam is not None:
        return list(filter(lambda k: k['max_letszam'] == max_letszam, kurzusok))
    return []

@utvonal.get("/kurzusok/filters", response_model=List[Kurzus])
async def get_kurzusok_filters(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    megadott_filterek = sum(map(lambda x: 1 if x is not None else 0, [nap_idopont, oktato_email, tipus, evfolyam, helyszin, max_letszam]))
    
    if megadott_filterek != 2:
        raise HTTPException(status_code=422, detail='Pontosan két szűrőt megadni.') 
    
    if nap_idopont is not None:
        kurzusok = list(filter(lambda k: k['nap_idopont'] == nap_idopont, kurzusok))
    if oktato_email is not None:
        kurzusok = list(filter(lambda k: k['oktato']['email'] == oktato_email, kurzusok))
    if tipus is not None:
        kurzusok = list(filter(lambda k: k['tipus'] == tipus, kurzusok))
    if evfolyam is not None:
        kurzusok = list(filter(lambda k: k['evfolyam'] == evfolyam, kurzusok))
    if helyszin is not None:
        kurzusok = list(filter(lambda k: k['helyszin'] == helyszin, kurzusok))
    if max_letszam is not None:
        kurzusok = list(filter(lambda k: k['max_letszam'] == max_letszam, kurzusok))
    return kurzusok
    
@utvonal.put("/kurzusok/{kurzus_id}", response_model=Kurzus)
async def update_kurzus(kurzus_id: int, kurzus: Kurzus):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    kurzus_idk = list(map(lambda k: k['id'], kurzusok))
    if kurzus_id in kurzus_idk:
        if kurzus.id != kurzus_id and kurzus.id in kurzus_idk:
            raise HTTPException(status_code=409, detail="Már létezik kurzus az új id-vel.")
        if KURZUS_TIPUS_ELLENORZES and not (kurzus.tipus in ['ea', 'gy'] and kurzus.evfolyam in [1,2,3] and kurzus.max_letszam >= 0):
            raise HTTPException(status_code=400, detail="Nem megfelelő kurzus adatok.")
        kurzusok = list(filter(lambda k: k['id'] != kurzus_id, kurzusok))
        kurzusok.append(kurzus.model_dump())
        fajl_kezelo.kurzusok_iras(kurzusok)
        return kurzus
    else:
        raise HTTPException(status_code=404, detail="Nincs ilyen kurzus.")

@utvonal.get("/kurzusok/hallgatok/{hallgato_id}", response_model=List[Kurzus])
async def get_hallgato_kurzusai(hallgato_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    return list(filter(lambda k: any(h['id'] == hallgato_id for h in k['hallgatok']), kurzusok))

@utvonal.delete("/kurzusok/{kurzus_id}")
async def delete_kurzus(kurzus_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    kurzus_idk = list(map(lambda k: k['id'], kurzusok))
    if kurzus_id in kurzus_idk:
        kurzusok = list(filter(lambda k: k['id'] != kurzus_id, kurzusok))
        fajl_kezelo.kurzusok_iras(kurzusok)
        return 'Kurzus törölve.'
    else:
        raise HTTPException(status_code=404, detail="Nincs ilyen kurzus.")

@utvonal.get("/kurzusok/{kurzus_id}/hallgatok/{hallgato_id}", response_model=Valasz)
async def get_hallgato_kurzuson(kurzus_id: int, hallgato_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    kurzus_idk = list(map(lambda k: k['id'], kurzusok))
    if kurzus_id in kurzus_idk:
        kurzus = list(filter(lambda k: k['id'] == kurzus_id, kurzusok))[0]
        if any(h['id'] == hallgato_id for h in kurzus['hallgatok']):
            return {'uzenet' : 'Igen'}
        else:
            return {'uzenet' : 'Nem'}
    else:
        raise HTTPException(status_code=404, detail="Nincs ilyen kurzus.")