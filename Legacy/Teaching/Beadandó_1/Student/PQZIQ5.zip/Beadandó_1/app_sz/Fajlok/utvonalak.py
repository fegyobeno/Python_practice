from fastapi import APIRouter, HTTPException
from typing import List
from .modellek import Kurzus, Valasz
from .fajl_kezeles import KurzusFajlKezelo

utvonal = APIRouter()

fajl_kezelo = KurzusFajlKezelo()

@utvonal.get("/kurzusok", response_model=List[Kurzus])
async def get_osszes_kurzus():
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    
    if kurzusok == []:
        raise HTTPException(status_code=404, detail="Nincs egy kurzus sem")

    return kurzusok


@utvonal.post("/kurzusok", response_model=Valasz)
async def uj_kurzus(kurzus: Kurzus):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    
    for k in kurzusok:
        if k['id'] == kurzus.id:
            raise HTTPException(status_code=404, detail="Ez a kurzus id már foglalt")

    kurzusok.append(kurzus.dict())
    fajl_kezelo.kurzusok_iras(kurzusok)
    return {"uzenet": "A felvétel sikeres volt"}
    

@utvonal.get("/kurzusok/filter", response_model=List[Kurzus])
async def get_kurzusok_filter(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    for x in kurzusok:
        if nap_idopont != None:
            if x['nap_idopont'] != nap_idopont:
                kurzusok.remove(x)
        if oktato_email != None:
            if x['oktato_email'] != oktato_email:
                kurzusok.remove(x)
        if tipus != None:
            if x['tipus'] != tipus:
                kurzusok.remove(x)
        if evfolyam != None:
            if x['evfolyam'] != evfolyam:
                kurzusok.remove(x)
        if helyszin != None:
            if x['helyszin'] != helyszin:
                kurzusok.remove(x)
        if max_letszam != None:
            if x['max_letszam'] != max_letszam:
                kurzusok.remove(x)

    if kurzusok == []:
        raise HTTPException(status_code=404, detail="Nincs ilyen kurzus")

    return kurzusok

@utvonal.get("/kurzusok/filters", response_model=List[Kurzus])
async def get_kurzusok_filters(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    db = 0

    if nap_idopont != None:
        db += 1
    if oktato_email != None:
        db += 1
    if tipus != None:
        db += 1
    if evfolyam != None:
        db += 1
    if helyszin != None:
        db += 1
    if max_letszam != None:
        db += 1

    for x in kurzusok:
        if nap_idopont != None:
            if x['nap_idopont'] != nap_idopont:
                kurzusok.remove(x)
        if oktato_email != None:
            if x['oktato_email'] != oktato_email:
                kurzusok.remove(x)
        if tipus != None:
            if x['tipus'] != tipus:
                kurzusok.remove(x)
        if evfolyam != None:
            if x['evfolyam'] != evfolyam:
                kurzusok.remove(x)
        if helyszin != None:
            if x['helyszin'] != helyszin:
                kurzusok.remove(x)
        if max_letszam != None:
            if x['max_letszam'] != max_letszam:
                kurzusok.remove(x)

    if kurzusok == []:
        raise HTTPException(status_code=404, detail="Nincs ilyen kurzus")

    if db != 2:
        raise HTTPException(status_code=404, detail="Nincs elég filter beállítva")

    return kurzusok
    
@utvonal.put("/kurzusok/{kurzus_id}", response_model=Kurzus)
async def update_kurzus(kurzus_id: int, kurzus: Kurzus):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    done = False

    for x in kurzusok:
        if x['id'] == kurzus_id:
            done = True
            kurzusok.remove(x)
            uj_kurzus(kurzus)

    fajl_kezelo.kurzusok_iras(kurzusok)

    if done == False:
        raise HTTPException(status_code=404, detail="Nincs egy ilyen id-val rendelkező kurzus sem")

    return kurzus

@utvonal.get("/kurzusok/hallgatok/{hallgato_id}", response_model=List[Kurzus])
async def get_hallgato_kurzusai(hallgato_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    van = False

    for kurzus in kurzusok:
        hallgatok = kurzus['hallgatok']
        for hallgato in hallgatok:
            if hallgato['id'] == hallgato_id:
                van = True
        if van == False:
            kurzusok.remove(kurzus)
        
    if kurzusok == []:
        raise HTTPException(status_code=404, detail="Nincs egy ilyen id-val rendelkező hallgato sem")
    
    return kurzusok


@utvonal.delete("/kurzusok/{kurzus_id}")
async def delete_kurzus(kurzus_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    done = False

    for x in kurzusok:
        if x['id'] == kurzus_id:
            done = True
            kurzusok.remove(x)
    
    if done == False:
        raise HTTPException(status_code=404, detail="Nincs egy ilyen id-val rendelkező kurzus sem")

    fajl_kezelo.kurzusok_iras(kurzusok)

@utvonal.get("/kurzusok/{kurzus_id}/hallgatok/{hallgato_id}", response_model=Valasz)
async def get_hallgato_kurzuson(kurzus_id: int, hallgato_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    van = False

    if kurzusok == []:
        raise HTTPException(status_code=404, detail="Nincs egy kurzus sem")

    for kurzus in kurzusok:
        if kurzus['id'] == kurzus_id:
            hallgatok = kurzus['hallgatok']
            for hallgato in hallgatok:
                if hallgato['id'] == hallgato_id:
                    van = True

    if van == True:
        return {"uzenet": "Igen"}
    if van == False:
        return {"uzenet": "Nem"}