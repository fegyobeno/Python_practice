from fastapi import Request
import requests
url ="http://127.0.0.1:8000/kurzusok"

headers={
    "Content-Type": "application/json"

}
data = {
    "id": 3,
    "nev": "Matek",  
    "tipus": "Targy",
    "evfolyam": 10,
    "nap_idopont": "Hetfo 10:00",
    "helyszin": "9.terem",
    "oktato": 
    {
        "nev": "Kiss Peter",
        "email": "kisspeter@citrom.hu"
    },
    "hallgatok": 
    [
        {
            "id": 1,
            "nev": "Kiss Janos",
            "email": "kissjanos@citrom.hu"
            },
        {
            "id": 2,
            "nev": "Jakap Peter",
            "email": "jakapetya@citrom.hu"
            }
    ],
    "max_letszam": 10
}

response=requests.post(url, headers=headers, json=data)

print(f"Státuszkód: {response.status_code}")



# Ha a válasz JSON, próbáljuk dekódolni
if response.status_code == 200 and "application/json" in content_type:
    try:
        response_data = response.json()
        print("JSON válasz:", response_data)
    except ValueError as e:
        print(f"Hiba történt a JSON dekódolásakor: {e}")
        print("A válasz nem volt érvényes JSON formátumban.")
else:
    print("A válasz nem JSON formátumú, vagy hiba történt.")
    print("Válasz szövege:", response.text)


