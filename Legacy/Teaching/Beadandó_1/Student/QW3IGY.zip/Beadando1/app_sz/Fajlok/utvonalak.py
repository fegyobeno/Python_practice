from fastapi import APIRouter, HTTPException
from typing import List
from .modellek import Kurzus, Valasz
from .fajl_kezeles import KurzusFajlKezelo
from fastapi.responses import JSONResponse


utvonal = APIRouter()

fajl_kezelo = KurzusFajlKezelo()

@utvonal.get("/kurzusok",response_model=List[Kurzus])
async def get_osszes_kurzus():
    kurz=fajl_kezelo.kurzusok_olvasas()
    if len(kurz)==0:
        raise HTTPException(status_code=205, detail="Nem talalhato adat")
    
    
    return JSONResponse(content=kurz, status_code=201)



@utvonal.post("/kurzusok", response_model=Valasz)
async def uj_kurzus(kurzus: Kurzus):
    try:
        kurz=fajl_kezelo.kurzusok_olvasas()
   
        for k in kurz:
            if (k['id'] == kurzus.id):
                raise HTTPException(status_code=409, detail="Ez a kurzus id már foglalt")
        
        kurz.append(kurzus.dict())
        fajl_kezelo.kurzusok_iras(kurz)
        
       
        valasz=Valasz(uzenet="Sikeres felvétel.")
        return JSONResponse(content=valasz, status_code=200)

    except HTTPException as e:
        raise e 

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e)) 





@utvonal.get("/kurzusok/filter", response_model=List[Kurzus])
async def get_kurzusok_filter(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    try:
        kurz=fajl_kezelo.kurzusok_olvasas()
        kurzreturn=[]
        if (nap_idopont):
            for k in kurz:
                if (nap_idopont==k['nap_idopont']):
                    kurzreturn.append(k)
        if (oktato_email):
            for k in kurz:
                if (oktato_email==k['oktato_email']):
                    kurzreturn.append(k)
        if (tipus):
            for k in kurz:
                if (tipus==k['tipus']):
                    kurzreturn.append(k)
        if (evfolyam):
            for k in kurz:
                if (evfolyam==k['evfolyam']):
                    kurzreturn.append(k)
        if (helyszin):
            for k in kurz:
                if (helyszin==k['helyszin']):
                    kurzreturn.append(k)
        if (max_letszam):
            for k in kurz:
                if (max_letszam==k['max_letszam']):
                    kurzreturn.append(k)
        if len(kurz)==0:
            raise HTTPException(status_code=205, detail="Nem talalhato adat")
        return JSONResponse(content=kurzreturn, status_code=201)

    except HTTPException as e:
        raise e 

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e)) 


    



@utvonal.get("/kurzusok/filters", response_model=List[Kurzus])
async def get_kurzusok_filters(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    param=[]

    if (nap_idopont):
        param.append({"nap_idopont":nap_idopont})
    if (oktato_email):
        param.append({"oktato_email":oktato_email})
    if (tipus):
        param.append({"tipus":tipus})
    if (evfolyam):
        param.append({"evfolyam":evfolyam})
    if (helyszin):
        param.append({"helyszin":helyszin})
    if (max_letszam):
        param.append({"max_letszam":max_letszam})
    
    kurz=fajl_kezelo.kurzusok_olvasas()
    kurzreturn=[]
    for k in kurz:
        b=True
        for kulcs, ertek in param.items():
            if kurz.get(kulcs)!=ertek:
                b=False
        if (b):
            kurzreturn.append(k)
    
    if len(kurz)==0:
        raise HTTPException(status_code=205, detail="Nem talalhato adat")
    return JSONResponse(content=kurzreturn, status_code=201)

            
    
@utvonal.put("/kurzusok/{kurzus_id}", response_model=Kurzus)
async def update_kurzus(kurzus_id: int, kurzus: Kurzus):
    kurz=fajl_kezelo.kurzusok_olvasas()
    kurzusok=[]
    b=False
    for k in kurz:
        if k["id"]==kurzus_id:
            b=True
            kurzusok.append(kurzus.dict())
        else:
            kurzusok.append(k)
    if (b==False):
        raise HTTPException(status_code=205, detail="Nem talalhato adat ilyen id-vel adat")
    else:
        fajl_kezelo.kurzusok_iras(kurzusok)

    return JSONResponse(content=kurzus, status_code=201)




@utvonal.get("/kurzusok/hallgatok/{hallgato_id}", response_model=List[Kurzus])
async def get_hallgato_kurzusai(hallgato_id: int):
    kurz=fajl_kezelo.kurzusok_olvasas()
    kurzusok=[]
    for k in kurz:
        for h in k['hallgatok']:
            if h['id']==hallgato_id:
                kurzusok.append(k)
    if (len(kurzusok)==0):
        raise HTTPException(status_code=404, detail="Nincs ilyen hallgato")
    

    return JSONResponse(status_code=200, content=kurzusok)


@utvonal.delete("/kurzusok/{kurzus_id}")
async def delete_kurzus(kurzus_id: int):
    kurz=fajl_kezelo.kurzusok_olvasas()
    kurzusok = [k for k in kurz if k["id"] != kurzus_id]
    if len(kurz)==len(kurzusok):
        raise HTTPException(status_code=404, detail="Item cannot found")
    
    fajl_kezelo.kurzusok_iras(kurzusok)

    # Válasz visszaadása
    return JSONResponse(status_code=200, content={"uzenet": f"A(z) {kurzus_id} azonosítójú kurzus törlésre került."})

@utvonal.get("/kurzusok/{kurzus_id}/hallgatok/{hallgato_id}", response_model=Valasz)
async def get_hallgato_kurzuson(kurzus_id: int, hallgato_id: int):
    kurz=fajl_kezelo.kurzusok_olvasas()
    res=False
    if (type(kurzus_id)!=int) or (type(hallgato_id)!=int):
        raise HTTPException(status_code=400, detail="Nem megfeleloek az adatok") 

    for k in kurz:
        if k['id']==kurzus_id:
            for h in k['hallgatok']:
                if h['id']==hallgato_id:
                    res=True
    if (res):
        v=valasz(uzenet="Igen")
    else:
        v=valasz(uzenet="Nem")
    return JSONResponse(content=v, status_code=200)


