from fastapi import APIRouter, HTTPException
from typing import List
from .modellek import Kurzus, Valasz
from .fajl_kezeles import KurzusFajlKezelo
from functools import wraps

utvonal = APIRouter()

fajl_kezelo = KurzusFajlKezelo()

def handle_exceptions(func):
    @wraps(func)
    async def wrapper(*args, **kwargs):
        try:
            return await func(*args, **kwargs)
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))
    return wrapper

def get_kurzusok():
    kurzusok_data = fajl_kezelo.kurzusok_olvasas()
    return [Kurzus(**kurzus) for kurzus in kurzusok_data]

def hallgatok_update_check(uj_kurzus : Kurzus):
    osszes_hallgato = []
    for kurzus in [Kurzus(**k) for k in fajl_kezelo.kurzusok_olvasas()]:
        for hallgato in kurzus.hallgatok:
            if hallgato not in osszes_hallgato:
                osszes_hallgato.append(hallgato)

    for uj_kurzus_hallgato in uj_kurzus.hallgatok:
        for hallgato in osszes_hallgato:
            if uj_kurzus_hallgato.id == hallgato.id and uj_kurzus_hallgato != hallgato:
                return False
    return True

@utvonal.get("/kurzusok", response_model=List[Kurzus])
@handle_exceptions
async def get_osszes_kurzus():
    return get_kurzusok()

@utvonal.post("/kurzusok", response_model=Valasz)
@handle_exceptions
async def uj_kurzus(kurzus: Kurzus):
    kurzusok_data = fajl_kezelo.kurzusok_olvasas()
        
    for existing_kurzus in kurzusok_data:
        k = Kurzus(**existing_kurzus)
        if k.id == kurzus.id:
            raise HTTPException(status_code=400, detail="id is already taken")

    if not hallgatok_update_check(kurzus):
        raise HTTPException(status_code=400, detail="students do not match with other courses")

    kurzusok_data.append(kurzus.dict())
    fajl_kezelo.kurzusok_iras(kurzusok_data)

    return Valasz(uzenet="Sikeres felvétel.")


def get_property_from_index(index, kurzus : Kurzus):
    if index == 0:
        return kurzus.nap_idopont
    elif index == 1:
        return kurzus.oktato.email
    elif index == 2:
        return kurzus.tipus
    elif index == 3:
        return kurzus.evfolyam
    elif index == 4:
        return kurzus.helyszin
    elif index == 5:
        return kurzus.max_letszam

@utvonal.get("/kurzusok/filter", response_model=List[Kurzus])
@handle_exceptions
async def get_kurzusok_filter(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    # Évfolyam paraméterben str, de Kurzus osztályban int?
    filters = [nap_idopont, oktato_email, tipus, int(evfolyam), helyszin, max_letszam]
    active_filters = [f for f in filters if f is not None]

    if len(active_filters) != 1:
        raise HTTPException(status_code=400, detail="exactly one filter must be provided")

    kurzusok = get_kurzusok()
    filtered_kurzusok = []

    for kurzus in kurzusok:
        ok = True
        for i in range(len(filters)):
            if filters[i] is not None and get_property_from_index(i, kurzus) != filters[i]:
                ok = False
                break
                
        if ok:
            filtered_kurzusok.append(kurzus)
            
    return filtered_kurzusok

@utvonal.get("/kurzusok/filters", response_model=List[Kurzus])
@handle_exceptions
async def get_kurzusok_filters(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    # Itt már int az évfolyam
    filters = [nap_idopont, oktato_email, tipus, evfolyam, helyszin, max_letszam]
    active_filters = [f for f in filters if f is not None]

    if len(active_filters) != 2:
        raise HTTPException(status_code=400, detail="exactly two filter must be provided")
    
    kurzusok = get_kurzusok()
    filtered_kurzusok = []

    for kurzus in kurzusok:
        ok = True

        for i in range(len(filters)):
            if filters[i] is not None and get_property_from_index(i, kurzus) != filters[i]:
                print(filters[i], get_property_from_index(i, kurzus))
                ok = False
                break
                
        if ok:
            filtered_kurzusok.append(kurzus)
        
    return filtered_kurzusok
    
@utvonal.put("/kurzusok/{kurzus_id}", response_model=Kurzus)
@handle_exceptions
async def update_kurzus(kurzus_id: int, kurzus: Kurzus):
    if kurzus_id != kurzus.id:
        raise HTTPException(status_code=400, detail="ids do not match")

    if not hallgatok_update_check(kurzus):
        raise HTTPException(status_code=400, detail="students do not match with other courses")

    kurzusok_data = fajl_kezelo.kurzusok_olvasas()
    
    index = -1
    for i in range(len(kurzusok_data)):
        k = Kurzus(**kurzusok_data[i])
        if k.id == kurzus_id:
            index = i
            break
    
    if -1 == index:
        raise HTTPException(status_code=400, detail="no id found")
    
    kurzusok_data.pop(index)
    kurzusok_data.append(kurzus.dict())
    fajl_kezelo.kurzusok_iras(kurzusok_data)

    return kurzus
    
@utvonal.get("/kurzusok/hallgatok/{hallgato_id}", response_model=List[Kurzus])
@handle_exceptions
async def get_hallgato_kurzusai(hallgato_id: int):
    kurzusok = get_kurzusok()
    hallgato_kurzusai = []

    is_hallgato_id_found = False
    for kurzus in kurzusok:
        hallgato_idk = [hallgato.id for hallgato in kurzus.hallgatok]
        if hallgato_id in hallgato_idk:
            hallgato_kurzusai.append(kurzus)
            is_hallgato_id_found = True

    if not is_hallgato_id_found:
        raise HTTPException(status_code=400, detail="no student found")

    return hallgato_kurzusai

@utvonal.delete("/kurzusok/{kurzus_id}")
@handle_exceptions
async def delete_kurzus(kurzus_id: int):
    kurzusok_data = fajl_kezelo.kurzusok_olvasas()
    index = -1

    for i in range(len(kurzusok_data)):
        k = Kurzus(**kurzusok_data[i])
        if k.id == kurzus_id:
            index = i
            break

    if index == -1:
        raise HTTPException(status_code=400, detail="no id found")

    kurzusok_data.pop(index)
    fajl_kezelo.kurzusok_iras(kurzusok_data)


@utvonal.get("/kurzusok/{kurzus_id}/hallgatok/{hallgato_id}", response_model=Valasz)
@handle_exceptions
async def get_hallgato_kurzuson(kurzus_id: int, hallgato_id: int):
    kurzusok = get_kurzusok()

    kurzus_talalt = False
    hallgato_talalt = False

    for kurzus in kurzusok:
        if kurzus.id == kurzus_id:
            kurzus_talalt = True
            break
    
    for kurzus in kurzusok:
        hallgato_idk = [hallgato.id for hallgato in kurzus.hallgatok]
        if hallgato_id in hallgato_idk:
            hallgato_talalt = True
            break

    if not kurzus_talalt:
        raise HTTPException(status_code=400, detail="no course found")
    
    if not hallgato_talalt:
        raise HTTPException(status_code=400, detail="no student found")
    
    for kurzus in kurzusok:
        if kurzus.id == kurzus_id:
            hallgato_idk = [hallgato.id for hallgato in kurzus.hallgatok]
            if hallgato_id in hallgato_idk:
                return Valasz(uzenet="Igen")
    
    return Valasz(uzenet="Nem")