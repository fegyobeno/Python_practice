from fastapi import APIRouter, HTTPException
from typing import List
from .modellek import Kurzus, Valasz
from .fajl_kezeles import KurzusFajlKezelo


utvonal = APIRouter()

fajl_kezelo = KurzusFajlKezelo()

@utvonal.get("/kurzusok", response_model=List[Kurzus])
async def get_osszes_kurzus():
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    if kurzusok is None:
        raise HTTPException(status_code = 404, detail="Nem találhatóak kurzusok.")
    return kurzusok

@utvonal.post("/kurzusok", response_model=Valasz)
async def uj_kurzus(kurzus: Kurzus):
    kurzusok = fajl_kezelo.kurzusok_olvasas()

    for k in kurzusok:
        if k["id"] == kurzus.id:
            raise HTTPException(status_code=400, detail="Ez a kurzus azonosító már foglalt.")

    kurzusok.append(kurzus.model_dump())
    fajl_kezelo.kurzusok_iras(kurzusok)

    return Valasz(uzenet="Sikeres felvétel.")

@utvonal.get("/kurzusok/filter", response_model=List[Kurzus])
async def get_kurzusok_filter(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    szKurzusok = []

    szurokSzama = sum([nap_idopont is not None, oktato_email is not None, tipus is not None, evfolyam is not None, helyszin is not None, max_letszam is not None])
    if szurokSzama != 1:
        raise HTTPException(status_code=400, detail="Pontosan egy szűrőt kell megadni.")
    
    for kurzus in kurzusok:
        if nap_idopont and kurzus["nap_idopont"] == nap_idopont:
            szKurzusok.append(kurzus)
        elif oktato_email and kurzus["oktato"]["email"] == oktato_email:
            szKurzusok.append(kurzus)
        elif tipus and kurzus["tipus"] == tipus:
            szKurzusok.append(kurzus)
        elif evfolyam and kurzus["evfolyam"] == evfolyam:
            szKurzusok.append(kurzus)
        elif helyszin and kurzus["helyszin"] == helyszin:
            szKurzusok.append(kurzus)
        elif max_letszam and kurzus["max_letszam"] == max_letszam:
            szKurzusok.append(kurzus)

    if not szKurzusok:
        raise HTTPException(status_code=404, detail="Nem létezik ilyen kurzus.")

    return szKurzusok

@utvonal.get("/kurzusok/filters", response_model=List[Kurzus])
async def get_kurzusok_filters(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: int = None, helyszin: str = None, max_letszam: int = None):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    szKurzusok = []

    szurok = {
        "nap_idopont": nap_idopont,
        "oktato_email": oktato_email,
        "tipus": tipus,
        "evfolyam": evfolyam,
        "helyszin": helyszin,
        "max_letszam": max_letszam
    }

    aktivSzurok = {kulcs: ertek for kulcs, ertek in szurok.items() if ertek is not None}

    if len(aktivSzurok) != 2:
        raise HTTPException(status_code=400, detail="Pontosan kettő szűrőt kell megadni.")

    szuro1, szuro2 = list(aktivSzurok.items())
    
    kulcs1, ertek1 = szuro1
    kulcs2, ertek2 = szuro2

    for kurzus in kurzusok:
        if kulcs1 == "nap_idopont" and kurzus["nap_idopont"] == ertek1:
            feltetel1 = True
        elif kulcs1 == "oktato_email" and kurzus["oktato"]["email"] == ertek1:
            feltetel1 = True
        elif kulcs1 == "tipus" and kurzus["tipus"] == ertek1:
            feltetel1 = True
        elif kulcs1 == "evfolyam" and kurzus["evfolyam"] == ertek1:
            feltetel1 = True
        elif kulcs1 == "helyszin" and kurzus["helyszin"] == ertek1:
            feltetel1 = True
        elif kulcs1 == "max_letszam" and kurzus["max_letszam"] == ertek1:
            feltetel1 = True
        else:
            feltetel1 = False

        if kulcs2 == "nap_idopont" and kurzus["nap_idopont"] == ertek2:
            feltetel2 = True
        elif kulcs2 == "oktato_email" and kurzus["oktato"]["email"] == ertek2:
            feltetel2 = True
        elif kulcs2 == "tipus" and kurzus["tipus"] == ertek2:
            feltetel2 = True
        elif kulcs2 == "evfolyam" and kurzus["evfolyam"] == ertek2:
            feltetel2 = True
        elif kulcs2 == "helyszin" and kurzus["helyszin"] == ertek2:
            feltetel2 = True
        elif kulcs2 == "max_letszam" and kurzus["max_letszam"] == ertek2:
            feltetel2 = True
        else:
            feltetel2 = False

        if feltetel1 and feltetel2:
            szKurzusok.append(kurzus)

    if not szKurzusok:
        raise HTTPException(status_code=404, detail=f"Nem létezik ilyen kurzus.")

    return szKurzusok

@utvonal.put("/kurzusok/{kurzus_id}", response_model=Kurzus)
async def update_kurzus(kurzus_id: int, kurzus: Kurzus):
    kurzusok = fajl_kezelo.kurzusok_olvasas()

    idLetezik = False
    index = 0
    for i, k in enumerate(kurzusok):
        if k["id"] == kurzus_id:
            idLetezik = True
            index = i
            break
    
    if not idLetezik:
        raise HTTPException(status_code=404, detail=f"Nem létezik ilyen kurzus.")
    
    kurzusok[index] = kurzus.model_dump()
    
    fajl_kezelo.kurzusok_iras(kurzusok)

    return kurzus

@utvonal.get("/kurzusok/hallgatok/{hallgato_id}", response_model=List[Kurzus])
async def get_hallgato_kurzusai(hallgato_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()

    hKurzusok = []
    hLetezik = False
    for k in kurzusok:
        for hallgato in k["hallgatok"]:
            if hallgato["id"] == hallgato_id:
                hKurzusok.append(k)
                hLetezik = True
                break
    
    if not hLetezik:
        raise HTTPException(status_code=404, detail=f"Nem létezik ilyen hallgató.")

    return hKurzusok



@utvonal.delete("/kurzusok/{kurzus_id}")
async def delete_kurzus(kurzus_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()

    index = 0
    idLetezik = False
    for i, k in enumerate(kurzusok):
        if k["id"] == kurzus_id:
            idLetezik = True
            index = i
            break
    
    if not idLetezik:
        raise HTTPException(status_code=404, detail=f"Nem létezik ilyen kurzus.")
    
    kurzusok.pop(index)

    fajl_kezelo.kurzusok_iras(kurzusok)


@utvonal.get("/kurzusok/{kurzus_id}/hallgatok/{hallgato_id}", response_model=Valasz)
async def get_hallgato_kurzuson(kurzus_id: int, hallgato_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()

    kLetezik = False
    hallgatoTagja = False
    for k in kurzusok:
        if k["id"] == kurzus_id:
            kLetezik = True
            for hallgato in k["hallgatok"]:
                if hallgato["id"] == hallgato_id:
                    hallgatoTagja = True
                    break
            break

    if not kLetezik:
        raise HTTPException(status_code=404, detail=f"Nem létezik ilyen kurzus.")
    
    if hallgatoTagja:
        return Valasz(uzenet="Igen")
    else:
        return Valasz(uzenet="Nem")
    


