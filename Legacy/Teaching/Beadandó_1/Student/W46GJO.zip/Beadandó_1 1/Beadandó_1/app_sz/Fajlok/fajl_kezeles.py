import json
from pathlib import Path

class KurzusFajlKezelo:
    utvonal = Path(__file__).parent.parent.parent / "kurzusok.json"

    def kurzusok_olvasas(self):
        try:
            with open(self.utvonal, "r") as be:
                kurzusok = json.load(be)
        except FileNotFoundError:
            return []
        return kurzusok

    def kurzusok_iras(self, kurzusok):
        with open(self.utvonal, "w") as ki:
            json.dump(kurzusok, ki, indent=4)
