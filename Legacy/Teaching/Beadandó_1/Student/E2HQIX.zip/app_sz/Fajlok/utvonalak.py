from fastapi import APIRouter, HTTPException
from typing import List
from .modellek import Kurzus, Valasz
from .fajl_kezeles import KurzusFajlKezelo


utvonal = APIRouter()

fajl_kezelo = KurzusFajlKezelo()

@utvonal.get("/kurzusok", response_model=List[Kurzus])
async def get_osszes_kurzus(): 
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    if not kurzusok:
        raise HTTPException(status_code=400, detail='Kurzusok json couldn\'t be read!')
    return kurzusok

@utvonal.post("/kurzusok", response_model=Valasz)
async def uj_kurzus(kurzus: Kurzus):
    kurzusok = await get_osszes_kurzus()
    #adunk egy id-t, ha null az érték
    if kurzus.id is None:
        new_id = max([k['id'] for k in kurzusok]) + 1
        kurzus.id = new_id
    if kurzus.id <= 0:
        return Valasz(uzenet='Nem lehet 0 vagy nemnegatív a kurzus ID')
    if kurzus.max_letszam < 0:
        return Valasz(uzenet='Nem lehet negatív a max_letszam')
    
    if kurzus.hallgatok:
        for hallgato in kurzus.hallgatok:
            if hallgato.id is None or hallgato.id <= 0:
                return Valasz(uzenet='Nem lehet 0 vagy nemnegatív a hallgato ID')
        if len(kurzus.hallgatok) > kurzus.max_letszam:
            return Valasz(uzenet='Több hallgató van a kurzusban, mint a megengedett max létszám.')
    for current in kurzusok:
        if current['id']:
            if current.get('id') == kurzus.id:
                return Valasz(uzenet="Ez a kurzus id már foglalt")
    

    kurzusok.append(kurzus.dict())
    fajl_kezelo.kurzusok_iras(kurzusok)
    return Valasz(uzenet="Sikeres felvétel")

@utvonal.get("/kurzusok/filter", response_model=List[Kurzus])
async def get_kurzusok_filter(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    kurzusok = await get_osszes_kurzus()
    params = {
        "nap_idopont": nap_idopont,
        "oktato_email": oktato_email,
        "tipus": tipus,
        "evfolyam": evfolyam,
        "helyszin": helyszin,
        "max_letszam": max_letszam
    }
    filtered = [(key, value) for key, value in params.items() if value is not None]
    if len(filtered) != 1:
        raise HTTPException(status_code=400, detail=f'Nem pontosan egy filter lett megadva. Helyette: {len(filtered)} db van.')

    filter_name = filtered[0][0]
    filter_value = filtered[0][1]

    new_kurzusok = []
    for kurzus in kurzusok:
        if filter_name == 'oktato_email':
            if kurzus.get('oktato').get('email') == filter_value:
                new_kurzusok.append(kurzus)
        else:
            if filter_name not in kurzus:
                raise HTTPException(status_code=404, detail=f'Nincs benne ez a filter paraméter a kurzusban. {filtered}')
            if kurzus.get(filter_name) == filter_value:
                new_kurzusok.append(kurzus)

    return new_kurzusok

@utvonal.get("/kurzusok/filters", response_model=List[Kurzus])
async def get_kurzusok_filters(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    kurzusok = await get_osszes_kurzus()
    params = {
        "nap_idopont": nap_idopont,
        "oktato_email": oktato_email,
        "tipus": tipus,
        "evfolyam": evfolyam,
        "helyszin": helyszin,
        "max_letszam": max_letszam
    }
    filtered = [(key, value) for key, value in params.items() if value is not None]
    if len(filtered) != 2:
        raise HTTPException(status_code=400, detail=f'Nem pontosan két filter lett megadva. Helyette: {len(filtered)} db van.')

    new_kurzusok = []
    
    for kurzus in kurzusok:
        good_filter = True
        for filter_name, filter_value in filtered:
            if filter_name == 'oktato_email':
                if kurzus.get('oktato').get('email') != filter_value:
                    good_filter = False
                    break
            else:
                if filter_name not in kurzus:
                    good_filter = False
                    break
                if kurzus.get(filter_name) != filter_value:
                    good_filter = False
                    break
        if good_filter:
            new_kurzusok.append(kurzus)

    return new_kurzusok
    
@utvonal.put("/kurzusok/{kurzus_id}", response_model=Kurzus)
async def update_kurzus(kurzus_id: int, kurzus: Kurzus):
    kurzusok = await get_osszes_kurzus()
    #adunk egy id-t, ha null az érték
    if kurzus.id is None:
        new_id = max([k['id'] for k in kurzusok]) + 1
        kurzus.id = new_id
    if kurzus.max_letszam < 0:
        raise HTTPException(status_code=400, detail=f'Nem lehet negatív a max_letszam')
    if kurzus.id <= 0:
        raise HTTPException(status_code=400, detail=f'Nem lehet negatív a vagy 0 az új kurzus ID')
    if kurzus.id in [k['id']for k in kurzusok] and kurzus.id != kurzus_id:
        raise HTTPException(status_code=400, detail=f'A kurzusban megadott ID (Nem a kurzus_id) már szerepel a kurzusok között. | ID: {kurzus.id}') 
    for idx, krzs in enumerate(kurzusok):
        if krzs['id'] == kurzus_id:
            if kurzus.hallgatok:
                if len(kurzus.hallgatok) > kurzus.max_letszam:
                    raise HTTPException(status_code=400, detail=f'Több hallgató van a kurzusban, mint a megengedett max létszám.') 
            if kurzus.id is None:
                new_id = max([k['id'] for k in kurzusok]) + 1
                kurzus.id = new_id
            kurzusok[idx] = kurzus.dict()
            fajl_kezelo.kurzusok_iras(kurzusok)
            return kurzusok[idx]
        
    raise HTTPException(status_code=404, detail=f'Keresett ID nincs benne a jelenlegi kurzusok között. ID: {kurzus_id}')

@utvonal.delete("/kurzusok/{kurzus_id}")
async def delete_kurzus(kurzus_id: int):
    kurzusok = await get_osszes_kurzus()

    for idx, krzs in enumerate(kurzusok):
        if krzs['id'] == kurzus_id:
            deleted = kurzusok[idx]
            kurzusok.remove(deleted)
            fajl_kezelo.kurzusok_iras(kurzusok)
            return deleted
        
    raise HTTPException(status_code=404, detail=f'Keresett ID nincs benne a jelenlegi kurzusok között. ID: {kurzus_id}')

@utvonal.get("/kurzusok/hallgatok/{hallgato_id}", response_model=List[Kurzus])
async def get_hallgato_kurzusai(hallgato_id: int):
    kurzusok = await get_osszes_kurzus()
    new_kurzusok = []

    for kurzus in kurzusok:
        if kurzus['hallgatok']:
            for hallgato in kurzus.get('hallgatok'):
                if hallgato['id'] == hallgato_id:
                    new_kurzusok.append(kurzus)

    if not new_kurzusok:
        raise HTTPException(status_code=404, detail=f'Keresett ID nincs benne a hallgatok között: {hallgato_id}')
    return new_kurzusok
    

@utvonal.get("/kurzusok/{kurzus_id}/hallgatok/{hallgato_id}", response_model=Valasz)
async def get_hallgato_kurzuson(kurzus_id: int, hallgato_id: int):
    kurzusok = await get_osszes_kurzus()

    if kurzus_id not in [kurzus['id'] for kurzus in kurzusok]:
        raise HTTPException(status_code=404, detail=f'Keresett ID nincs benne a kurzusok között: {kurzus_id}')

    for kurzus in kurzusok:
        if kurzus_id == kurzus.get('id'):
            if kurzus['hallgatok']:
                for hallgato in kurzus.get('hallgatok'):
                    if hallgato['id'] == hallgato_id:
                        return Valasz(uzenet='Igen')
    return Valasz(uzenet='Nem')
