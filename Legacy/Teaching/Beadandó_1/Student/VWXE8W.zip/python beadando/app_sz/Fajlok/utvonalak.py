from fastapi import APIRouter, HTTPException
from typing import List
from .modellek import Kurzus, Valasz
from .fajl_kezeles import KurzusFajlKezelo


utvonal = APIRouter()

fajl_kezelo = KurzusFajlKezelo()

@utvonal.get("/kurzusok", response_model=List[Kurzus])
async def get_osszes_kurzus():
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    return kurzusok

@utvonal.post("/kurzusok", response_model=Valasz)
async def uj_kurzus(kurzus: Kurzus):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    

    for k in kurzusok:
        if(kurzus.id==k['id']):
            raise HTTPException(status_code=422, detail="Ez a kurzus id már foglalt")
    kurzusok.append(kurzus.model_dump())
    fajl_kezelo.kurzusok_iras(kurzusok)
    return Valasz(uzenet="Sikeres felvétel.")

@utvonal.get("/kurzusok/filter", response_model=List[Kurzus])
async def get_kurzusok_filter(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    params = [nap_idopont, oktato_email, tipus, evfolyam, helyszin, max_letszam]
    fn=0
    for param in params:
        if param is not None:
            fn += 1 
    if(fn>1):
        raise HTTPException(status_code=422, detail="Több mint egy filter lett megadva")
    if fn==0:
        raise HTTPException(status_code=422, detail="Nem lett megadva filter")
    
    filter=[]


    if nap_idopont is not None:
        for k in kurzusok:
            if(k['nap_idopont']==nap_idopont):
                filter.append(k)
    if oktato_email is not None:
        for k in kurzusok:
            if(k['oktato']['email']==oktato_email):
                filter.append(k)
    if tipus is not None:
        for k in kurzusok:
            if(k['tipus']==tipus):
                filter.append(k)
    if evfolyam is not None:
        for k in kurzusok:
            if(str(k['evfolyam'])==evfolyam):
                filter.append(k)
    if helyszin is not None:
        for k in kurzusok:
            if(k['helyszin']==helyszin):
                filter.append(k)
    if max_letszam is not None:
        for k in kurzusok:
            if(k['max_letszam']==max_letszam):
                filter.append(k)
    return filter
    

    
    

@utvonal.get("/kurzusok/filters", response_model=List[Kurzus])
async def get_kurzusok_filters(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    params = [nap_idopont, oktato_email, tipus, evfolyam, helyszin, max_letszam]
    paramsstr = ['nap_idopont', 'oktato_email', 'tipus', 'evfolyam', 'helyszin', 'max_letszam']
    cp = []
    
    for i in range(0,6):
        if params[i] is not None:
            cp.append(i) 
    if(len(cp)!=2):
        raise HTTPException(status_code=422, detail="Nem megfelelő a filterek száma")
    
    filter=[]

    for k in kurzusok:
        if(1 not in cp):
            if(str(k[paramsstr[cp[0]]])==str(params[cp[0]]) and str(k[paramsstr[cp[1]]])==str(params[cp[1]])):
                filter.append(k)
        else:
            nem_oktato_id=None
            if(cp.index(1)==0):
                nem_oktato_id=1
            else:
                nem_oktato_id=0
            if(k['oktato']['email']==oktato_email and str(k[paramsstr[cp[nem_oktato_id]]])==str(params[cp[nem_oktato_id]])):
                filter.append(k)

    return filter


    
@utvonal.put("/kurzusok/{kurzus_id}", response_model=Kurzus)
async def update_kurzus(kurzus_id: int, kurzus: Kurzus):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    f=False
    for i,k in enumerate(kurzusok):
        if(k['id']==kurzus_id):
            f=True
            kurzusok[i]=kurzus.model_dump()
            break
    
    if(f==False):
        raise HTTPException(status_code=422, detail="ID nem található")

    fajl_kezelo.kurzusok_iras(kurzusok)
    return(kurzus)

@utvonal.get("/kurzusok/hallgatok/{hallgato_id}", response_model=List[Kurzus])
async def get_hallgato_kurzusai(hallgato_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    filtered=[]
    for k in kurzusok:
        for h in k['hallgatok']:
            if(h['id']==hallgato_id):
                filtered.append(k)
                break
    if(len(filtered)==0):
        raise HTTPException(status_code=422, detail="Nincs ilyen tanuló")
    return filtered

@utvonal.delete("/kurzusok/{kurzus_id}")
async def delete_kurzus(kurzus_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    f=False
    for i,k in enumerate(kurzusok):
        if(k['id']==kurzus_id):
            f=True
            del kurzusok[i]
            break
    
    if(f==False):
        raise HTTPException(status_code=422, detail="ID nem található")

    fajl_kezelo.kurzusok_iras(kurzusok)

@utvonal.get("/kurzusok/{kurzus_id}/hallgatok/{hallgato_id}", response_model=Valasz)
async def get_hallgato_kurzuson(kurzus_id: int, hallgato_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    filtered=[]
    for k in kurzusok:
        if(k['id']==kurzus_id):
            for h in k['hallgatok']:
                if(h['id']==hallgato_id):
                    return Valasz(uzenet="Igen")
                else:
                    return Valasz(uzenet="Nem")
    raise HTTPException(status_code=422, detail="Nincs ilyen kurzus")
    
