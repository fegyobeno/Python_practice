from fastapi import APIRouter, HTTPException
from typing import List
from .modellek import Kurzus, Valasz
from .fajl_kezeles import KurzusFajlKezelo


utvonal = APIRouter()

fajl_kezelo = KurzusFajlKezelo()

@utvonal.get("/kurzusok", response_model=List[Kurzus])
async def get_osszes_kurzus():
    return fajl_kezelo.kurzusok_olvasas()

@utvonal.post("/kurzusok", response_model=Valasz)
async def uj_kurzus(kurzus: Kurzus):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    
    for existing_kurzus in kurzusok:
        if existing_kurzus["id"] == kurzus.id:
            raise HTTPException(status_code=400, detail="Ez a kurzus id már foglalt")
    
    kurzusok.append(kurzus.dict())
    fajl_kezelo.kurzusok_iras(kurzusok)
    
    return Valasz(uzenet="Sikeres felvétel.")

@utvonal.get("/kurzusok/filter", response_model=List[Kurzus])
async def get_kurzusok_filter(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    
    szurok = {
        "nap_idopont": nap_idopont,
        "oktato_email": oktato_email,
        "tipus": tipus,
        "evfolyam": evfolyam,
        "helyszin": helyszin,
        "max_letszam": max_letszam
    }
    
    aktiv_szurok = {kulcs: ertek for kulcs, ertek in szurok.items() if ertek is not None}
    
    if len(aktiv_szurok) != 1:
        raise HTTPException(status_code=400, detail="Pontosn egy szűrő paramétert kell megadni.")

    szuro_kulcs, szuro_ertek = list(aktiv_szurok.items())[0]

    if szuro_kulcs == "nap_idopont":
        szurt_kurzusok = [kurzus for kurzus in kurzusok if kurzus["nap_idopont"] == szuro_ertek]
    elif szuro_kulcs == "oktato_email":
        szurt_kurzusok = [kurzus for kurzus in kurzusok if kurzus["oktato"]["email"] == szuro_ertek]
    elif szuro_kulcs == "tipus":
        szurt_kurzusok = [kurzus for kurzus in kurzusok if kurzus["tipus"] == szuro_ertek]
    elif szuro_kulcs == "evfolyam":
        szurt_kurzusok = [kurzus for kurzus in kurzusok if kurzus["evfolyam"] == int(szuro_ertek)]
    elif szuro_kulcs == "helyszin":
        szurt_kurzusok = [kurzus for kurzus in kurzusok if kurzus["helyszin"] == szuro_ertek]
    elif szuro_kulcs == "max_letszam":
        szurt_kurzusok = [kurzus for kurzus in kurzusok if kurzus["max_letszam"] == int(szuro_ertek)]
    else:
        szurt_kurzusok = []

    return szurt_kurzusok

@utvonal.get("/kurzusok/filters", response_model=List[Kurzus])
async def get_kurzusok_filters(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    
    szurok = {
        "nap_idopont": nap_idopont,
        "oktato_email": oktato_email,
        "tipus": tipus,
        "evfolyam": evfolyam,
        "helyszin": helyszin,
        "max_letszam": max_letszam
    }
    
    aktiv_szurok = {kulcs: ertek for kulcs, ertek in szurok.items() if ertek is not None}
    
    if len(aktiv_szurok) != 2:
        raise HTTPException(status_code=400, detail="Pontosn kettő szűrő paramétert kell megadni.")

    szuro_kulcs, szuro_ertek = list(aktiv_szurok.items())[0]

    for aktiv in list(aktiv_szurok.items()):
        szuro_kulcs, szuro_ertek = aktiv
        if szuro_kulcs == "nap_idopont":
            szurt_kurzusok = [kurzus for kurzus in kurzusok if kurzus["nap_idopont"] == szuro_ertek]
        elif szuro_kulcs == "oktato_email":
            szurt_kurzusok = [kurzus for kurzus in kurzusok if kurzus["oktato"]["email"] == szuro_ertek]
        elif szuro_kulcs == "tipus":
            szurt_kurzusok = [kurzus for kurzus in kurzusok if kurzus["tipus"] == szuro_ertek]
        elif szuro_kulcs == "evfolyam":
            szurt_kurzusok = [kurzus for kurzus in kurzusok if kurzus["evfolyam"] == int(szuro_ertek)]
        elif szuro_kulcs == "helyszin":
            szurt_kurzusok = [kurzus for kurzus in kurzusok if kurzus["helyszin"] == szuro_ertek]
        elif szuro_kulcs == "max_letszam":
            szurt_kurzusok = [kurzus for kurzus in kurzusok if kurzus["max_letszam"] == int(szuro_ertek)]
        else:
            szurt_kurzusok = []

    return szurt_kurzusok
    
@utvonal.put("/kurzusok/{kurzus_id}", response_model=Kurzus)
async def update_kurzus(kurzus_id: int, kurzus: Kurzus):
    kurzusok = fajl_kezelo.kurzusok_olvasas()

    for index, kurzus in enumerate(kurzusok):
        if kurzus["id"] == kurzus_id:
            kurzusok[index] = kurzus
            fajl_kezelo.kurzusok_iras(kurzusok)
            return kurzus

    raise HTTPException(status_code=404, detail="A megadott kurzus_id-val kurzus nem található.")

@utvonal.get("/kurzusok/hallgatok/{hallgato_id}", response_model=List[Kurzus])
async def get_hallgato_kurzusai(hallgato_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    hallgato_kurzusai = [
        kurzus for kurzus in kurzusok
        if any(hallgato["id"] == hallgato_id for hallgato in kurzus.get("hallgatok", []))
    ]
    
    if not hallgato_kurzusai:
        raise HTTPException(status_code=404, detail="A megadott hallgato_id-val hallgató nem található egy kurzusban sem.")
    
    return hallgato_kurzusai

@utvonal.delete("/kurzusok/{kurzus_id}")
async def delete_kurzus(kurzus_id: int):
    kurzusok        = fajl_kezelo.kurzusok_olvasas()
    kurzus_index    = next((index for index, kurzus in enumerate(kurzusok) if kurzus["id"] == kurzus_id), None)

    if kurzus_index is None:
        raise HTTPException(status_code=404, detail="A megadott kurzus_id-val kurzus nem található.")
    
    del kurzusok[kurzus_index]
    fajl_kezelo.kurzusok_iras(kurzusok)
    return Valasz(uzenet="A kurzus sikeresen törölve.")

@utvonal.get("/kurzusok/{kurzus_id}/hallgatok/{hallgato_id}", response_model=Valasz)
async def get_hallgato_kurzuson(kurzus_id: int, hallgato_id: int):
    kurzusok    = fajl_kezelo.kurzusok_olvasas()
    kurzus      = next((kurzus for kurzus in kurzusok if kurzus["id"] == kurzus_id), None)
    
    if kurzus is None:
        raise HTTPException(status_code=404, detail="A megadott kurzus_id-val kurzus nem található.")
    
    hallgato_jelen_van = any(hallgato["id"] == hallgato_id for hallgato in kurzus.get("hallgatok", []))
    
    if hallgato_jelen_van:
        return Valasz(uzenet="Igen")
    else:
        return Valasz(uzenet="Nem")



"""


    # Beolvassuk a kurzusokat
    kurzusok = fajl_kezelo.kurzusok_olvasas()

    # Szűrjük a kurzusokat a paraméterek alapján
    if nap_idopont:
        kurzusok = [kurzus for kurzus in kurzusok if kurzus["nap_idopont"] == nap_idopont]
    elif oktato_email:
        kurzusok = [kurzus for kurzus in kurzusok if kurzus["oktato"]["email"] == oktato_email]
    elif tipus:
        kurzusok = [kurzus for kurzus in kurzusok if kurzus["tipus"] == tipus]
    elif evfolyam:
        kurzusok = [kurzus for kurzus in kurzusok if kurzus["evfolyam"] == evfolyam]
    elif helyszin:
        kurzusok = [kurzus for kurzus in kurzusok if kurzus["helyszin"] == helyszin]
    elif max_letszam:
        kurzusok = [kurzus for kurzus in kurzusok if kurzus["max_letszam"] == max_letszam]
    else:
        return kurzusok
    # Ha nincs találat, hibaüzenet
    if not kurzusok:
        return Valasz(uzenet="Nincs találat a megadott szűrőkkel.")

    return kurzusok




kurzusok = fajl_kezelo.kurzusok_olvasas()
    

    for k in kurzusok:
        if kurzus.id == k['id']:
            return {"uzenet" : "Ez a kurzus id már foglalt"}
    #print('\n')
    
    for o in kurzus.oktato:
        oktato = {"nev":o[0], "email":o[1]}

    hallgatok = []
    for h in kurzus.hallgatok:
        hallgatok.append({"id":h.id, "nev":h.nev, "email":h.email})

    kurzusok.append({"id":kurzus.id, "nev":kurzus.nev, "tipus":kurzus.tipus, "evfolyam":kurzus.evfolyam, "nap_idopont":kurzus.nap_idopont, "helyszin":kurzus.helyszin, "oktato":oktato, "hallgatok":hallgatok, "max_letszam":kurzus.max_letszam })
    #print(kurzusok)
    #print('\n')
    fajl_kezelo.kurzusok_iras(kurzusok)



kurzusok = fajl_kezelo.kurzusok_olvasas()
    megfelelt = []
    hiba = {
                "detail": [
                    {
                        "loc": [
                          "string",
                          0
                        ],
                        "msg": "nem megfelelő szűrő",
                        "type": "error"
                    }
                ]
            }
    for k in kurzusok:
        if nap_idopont != None and k['nap_idopont']==nap_idopont:
            megfelelt.append(k)
        elif oktato_email != None and k['oktato_email']==oktato_email:
            megfelelt.append(k)
        elif tipus != None and k['tipus']==tipus:
            megfelelt.append(k)
        elif evfolyam != None and k['evfolyam']==evfolyam:
            megfelelt.append(k)
        elif helyszin != None and k['helyszin']==helyszin:
            megfelelt.append(k)
        elif max_letszam != None and k['max_letszam']==max_letszam:
            megfelelt.append(k)
        else:
            return hiba
    #print(megfelelt)
    return megfelelt
"""
