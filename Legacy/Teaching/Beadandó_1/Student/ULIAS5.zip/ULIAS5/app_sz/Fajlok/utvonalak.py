from fastapi import APIRouter, HTTPException
from typing import List
from .modellek import Kurzus, Valasz
from .fajl_kezeles import KurzusFajlKezelo


utvonal = APIRouter()

fajl_kezelo = KurzusFajlKezelo()


########---|1|---########
@utvonal.get("/kurzusok", response_model=List[Kurzus])
async def get_osszes_kurzus():
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    if not kurzusok:
        raise HTTPException(stwatus_code=404, detail="Nem található kurzus.")
    return kurzusok


########---|2|---########
@utvonal.post("/kurzusok", response_model=Valasz)
async def uj_kurzus(kurzus: Kurzus):
    kurzusok = fajl_kezelo.kurzusok_olvasas()

    for k in kurzusok:
        if k["id"] == kurzus.id:
            raise HTTPException(status_code=400, detail="Ez a kurzus id már foglalt")

    kurzusok.append(kurzus.model_dump())
    fajl_kezelo.kurzusok_iras(kurzusok)

    return {"uzenet": "Sikeres felvétel."}


########---|3|---########
@utvonal.get("/kurzusok/filter", response_model=List[Kurzus])
async def get_kurzusok_filter(
    nap_idopont: str = None,
    oktato_email: str = None,
    tipus: str = None,
    evfolyam: str = None,
    helyszin: str = None,
    max_letszam: int = None,
):
    kurzusok = fajl_kezelo.kurzusok_olvasas()

    filters = {
        "nap_idopont": nap_idopont,
        "oktato.email": oktato_email,
        "tipus": tipus,
        "evfolyam": evfolyam,
        "helyszin": helyszin,
        "max_letszam": max_letszam,
    }

    applied_filters = {}
    for key, value in filters.items():
        if value is not None:
            applied_filters[key] = value

    if len(applied_filters) != 1:
        raise HTTPException(status_code=400, detail="Kérem csak egy szűrőt adjon meg.")

    filter_key = list(applied_filters.keys())[0]
    filter_value = list(applied_filters.values())[0]

    def get_nested_attr(obj, attr):
        keys = attr.split(".")
        for key in keys:
            obj = obj.get(key) if isinstance(obj, dict) else None
            if obj is None:
                return None
        return obj

    filtered_kurzusok = []
    for kurzus in kurzusok:
        if get_nested_attr(kurzus, filter_key) == filter_value:
            filtered_kurzusok.append(kurzus)

    if not filtered_kurzusok:
        raise HTTPException(
            status_code=404,
            detail="Nem található a megadott szűrőnek megfelelő kurzus.",
        )

    return filtered_kurzusok


########---|4|---########
@utvonal.get("/kurzusok/filters", response_model=List[Kurzus])
async def get_kurzusok_filters(
    nap_idopont: str = None,
    oktato_email: str = None,
    tipus: str = None,
    evfolyam: str = None,
    helyszin: str = None,
    max_letszam: int = None,
):

    kurzusok = fajl_kezelo.kurzusok_olvasas()

    filters = {
        "nap_idopont": nap_idopont,
        "oktato.email": oktato_email,
        "tipus": tipus,
        "evfolyam": evfolyam,
        "helyszin": helyszin,
        "max_letszam": max_letszam,
    }
    applied_filters = {}
    for key, value in filters.items():
        if value is not None:
            applied_filters[key] = value

    if len(applied_filters) != 2:
        raise HTTPException(status_code=400, detail="Pontosan két szűrőt kell megadni.")

    def filter_function(kurzus):
        for key, value in applied_filters.items():
            keys = key.split(".")
            attr = kurzus
            for k in keys:
                attr = attr.get(k) if isinstance(attr, dict) else getattr(attr, k, None)
            if attr != value:
                return False
        return True

    # Szűrt kurzusok listája
    filtered_kurzusok = []
    for kurzus in kurzusok:
        if filter_function(kurzus):
            filtered_kurzusok.append(kurzus)

    if not filtered_kurzusok:
        raise HTTPException(
            status_code=404,
            detail="Nem található a megadott szűrőknek megfelelő kurzus.",
        )

    return filtered_kurzusok


########---|5|---########
@utvonal.put("/kurzusok/{kurzus_id}", response_model=Kurzus)
async def update_kurzus(kurzus_id: int, kurzus: Kurzus):
    kurzusok = fajl_kezelo.kurzusok_olvasas()

    for index, existing_kurzus in enumerate(kurzusok):
        if existing_kurzus["id"] == kurzus_id:
            kurzusok[index] = kurzus.model_dump()
            fajl_kezelo.kurzusok_iras(kurzusok)
            return kurzus

    raise HTTPException(status_code=404, detail="A megadott kurzus nem található.")


########---|6|---########
@utvonal.get("/kurzusok/hallgatok/{hallgato_id}", response_model=List[Kurzus])
async def get_hallgato_kurzusai(hallgato_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()

    hallgato_kurzusai = []
    for kurzus in kurzusok:
        if "hallgatok" in kurzus:
            for hallgato in kurzus["hallgatok"]:
                if hallgato["id"] == hallgato_id:
                    hallgato_kurzusai.append(kurzus)
                    break

    if not hallgato_kurzusai:
        raise HTTPException(
            status_code=404, detail="Nem található a megadott hallgatóhoz kurzus."
        )

    return hallgato_kurzusai


########---|7|---########
@utvonal.delete("/kurzusok/{kurzus_id}")
async def delete_kurzus(kurzus_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()

    for index, existing_kurzus in enumerate(kurzusok):
        if existing_kurzus["id"] == kurzus_id:
            del kurzusok[index]
            fajl_kezelo.kurzusok_iras(kurzusok)
            return {"message": "Kurzus sikeresen törölve."}

    raise HTTPException(status_code=404, detail="A megadott kurzus nem található.")


########---|8|---########
@utvonal.get("/kurzusok/{kurzus_id}/hallgatok/{hallgato_id}", response_model=Valasz)
async def get_hallgato_kurzuson(kurzus_id: int, hallgato_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()

    for kurzus in kurzusok:
        if kurzus["id"] == kurzus_id:
            if "hallgatok" in kurzus and any(
                hallgato["id"] == hallgato_id for hallgato in kurzus["hallgatok"]
            ):
                return {"uzenet": "Igen"}
            else:
                return {"uzenet": "Nem"}

    raise HTTPException(status_code=404, detail="A megadott kurzus nem található.")
