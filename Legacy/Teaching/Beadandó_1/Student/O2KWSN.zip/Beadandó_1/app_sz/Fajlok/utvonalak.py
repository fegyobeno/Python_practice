from fastapi import APIRouter, HTTPException
from typing import List
from .modellek import Kurzus, Valasz
from .fajl_kezeles import KurzusFajlKezelo


utvonal = APIRouter()

fajl_kezelo = KurzusFajlKezelo()

@utvonal.get("/kurzusok", response_model=List[Kurzus])
async def get_osszes_kurzus():
    return fajl_kezelo.kurzusok_olvasas()

@utvonal.post("/kurzusok", response_model=Valasz)
async def uj_kurzus(kurzus: Kurzus):
    if(kurzus == None):
        raise HTTPException(400, 'kurzus nem lehet üres')
    if(kurzus.id < 1):
        raise HTTPException(400, 'Invalid kurzus id')
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    exists = False
    for e in kurzusok:
        if(e['id'] == kurzus.id):
            return Valasz(uzenet="Ez a kurzus id már foglalt")
    kurzusok.append(kurzus.model_dump())
    fajl_kezelo.kurzusok_iras(kurzusok)
    return Valasz(uzenet="Sikeres felvétel.")

@utvonal.get("/kurzusok/filter", response_model=List[Kurzus])
async def get_kurzusok_filter(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    not_null_count = 0
    for x in locals():
        if x is not None:
            not_null_count += 1
    if(not_null_count != 1):
        raise HTTPException(400, 'Egyszerre csak egy filtert lehet használni!')
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    if(nap_idopont != None):
        kurzusok = [x for x in kurzusok if x['nap_idopont'] == nap_idopont]
    if(oktato_email != None):
        kurzusok = [x for x in kurzusok if x['oktato']['email'] == oktato_email]
    if(tipus != None):
        kurzusok = [x for x in kurzusok if x['tipus'] == tipus]
    if(evfolyam != None):
        kurzusok = [x for x in kurzusok if x['evfolyam'] == evfolyam]
    if(helyszin != None):
        kurzusok = [x for x in kurzusok if x['helyszin'] == helyszin]
    if(max_letszam != None):
        kurzusok = [x for x in kurzusok if x['max_letszam'] == max_letszam]
    return kurzusok

@utvonal.get("/kurzusok/filters", response_model=List[Kurzus])
async def get_kurzusok_filters(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    not_null_count = 0
    for x in locals():
        if x is not None:
            not_null_count += 1
    if(not_null_count != 2):
        raise HTTPException(400, 'Pontosan 2 filtert kell használni!')
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    if(nap_idopont != None):
        kurzusok = [x for x in kurzusok if x['nap_idopont'] == nap_idopont]
    if(oktato_email != None):
        kurzusok = [x for x in kurzusok if x['oktato']['email'] == oktato_email]
    if(tipus != None):
        kurzusok = [x for x in kurzusok if x['tipus'] == tipus]
    if(evfolyam != None):
        kurzusok = [x for x in kurzusok if x['evfolyam'] == evfolyam]
    if(helyszin != None):
        kurzusok = [x for x in kurzusok if x['helyszin'] == helyszin]
    if(max_letszam != None):
        kurzusok = [x for x in kurzusok if x['max_letszam'] == max_letszam]
    return kurzusok
    
@utvonal.put("/kurzusok/{kurzus_id}", response_model=Kurzus)
async def update_kurzus(kurzus_id: int, kurzus: Kurzus):
    if(kurzus_id == None):
        raise HTTPException(400, 'kurzus_id nem lehet üres')
    if(kurzus == None):
        raise HTTPException(400, 'kurzus nem lehet üres')
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    for e in kurzusok:
        if(kurzus_id == e['id']):
            kurzusok.remove(e)
            kurzusok.append(kurzus.model_dump())
            fajl_kezelo.kurzusok_iras(kurzusok)
            return kurzus

@utvonal.get("/kurzusok/hallgatok/{hallgato_id}", response_model=List[Kurzus])
async def get_hallgato_kurzusai(hallgato_id: int):
    if(hallgato_id == None):
        raise HTTPException(400, 'hallgato_id nem lehet üres')
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    exists = False
    hallgato_kurzusok = []
    for e in kurzusok:
        for hallgato in e['hallgatok']:
            if(hallgato['id'] == hallgato_id):
                hallgato_kurzusok.append(e)
                exists = True
    if(exists):
        return hallgato_kurzusok
    else:
        raise HTTPException(400, 'nem létezik hallgató ezzel az ID-val')

@utvonal.delete("/kurzusok/{kurzus_id}")
async def delete_kurzus(kurzus_id: int):
    if(kurzus_id == None):
        raise HTTPException(400, 'kurzus_id nem lehet üres')
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    exists = False
    for e in kurzusok:
        if(e['id'] == kurzus_id):
            exists = True
            kurzusok.remove(e)
            break
    if(exists):
        fajl_kezelo.kurzusok_iras(kurzusok)
    else:
        raise HTTPException(400, 'Kurzus nem létezik.')


@utvonal.get("/kurzusok/{kurzus_id}/hallgatok/{hallgato_id}", response_model=Valasz)
async def get_hallgato_kurzuson(kurzus_id: int, hallgato_id: int):
    if(kurzus_id == None):
        raise HTTPException(400, 'kurzus_id nem lehet üres')
    if(hallgato_id == None):
        raise HTTPException(400, 'hallgato_id nem lehet üres')
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    for e in kurzusok:
        if(kurzus_id != None and e['id'] == kurzus_id):
            for diak in e['hallgatok']:
                if(hallgato_id != None and diak['id'] == hallgato_id):
                    return Valasz(uzenet="Igen")
    return Valasz(uzenet="Nem")

