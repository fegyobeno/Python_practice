from fastapi import APIRouter, HTTPException
from typing import List
from .modellek import Kurzus, Valasz
from .fajl_kezeles import KurzusFajlKezelo
from fastapi.encoders import jsonable_encoder

utvonal = APIRouter()

fajl_kezelo = KurzusFajlKezelo()

@utvonal.get("/kurzusok", response_model=List[Kurzus])
async def get_osszes_kurzus():
    return fajl_kezelo.kurzusok_olvasas()

@utvonal.post("/kurzusok", response_model=Valasz)
async def uj_kurzus(kurzus: Kurzus):
    result = [k for k in fajl_kezelo.kurzusok_olvasas() if k["id"] == kurzus.id]

    if(result != []):
        return Valasz(uzenet="Ez a kurzus id már foglalt")
    
    kurzus_data = jsonable_encoder(kurzus)  # Convert model to JSON-serializable format
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    kurzusok1 = kurzusok + [kurzus_data]
    fajl_kezelo.kurzusok_iras(kurzusok1) 
    return Valasz(uzenet="Sikeres felvétel")

@utvonal.get("/kurzusok/filter", response_model=List[Kurzus])
async def get_kurzusok_filter(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    
    filters = {
      "nap_idopont": nap_idopont,
      "oktató_email": oktato_email,
      "tipus": tipus,
      "evfolyam": evfolyam,
      "helyszin": helyszin,
      "max_letszam": max_letszam
      }

    selected_filters = {k: v for k, v in filters.items() if v != None}

    if len(selected_filters) != 1:
        raise HTTPException(status_code=400, detail="Pontosan egy szűrőt kell megadni.")

    filter_key, filter_value = list(selected_filters.items())[0]
    filtered_kurzusok = [kurzus for kurzus in fajl_kezelo.kurzusok_olvasas() if kurzus[filter_key] == filter_value]

    return filtered_kurzusok
    


@utvonal.get("/kurzusok/filters", response_model=List[Kurzus])
async def get_kurzusok_filters(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    filters = {
      "nap_idopont": nap_idopont,
      "oktató_email": oktato_email,
      "tipus": tipus,
      "evfolyam": evfolyam,
      "helyszin": helyszin,
      "max_letszam": max_letszam
      }

    selected_filters = {k: v for k, v in filters.items() if v != None}

    if len(selected_filters) != 2:
        raise HTTPException(status_code=400, detail="Pontosan két szűrőt kell megadni.")

    filter_key, filter_value = list(selected_filters.items())[0]
    filtered_kurzusok = [kurzus for kurzus in fajl_kezelo.kurzusok_olvasas() if kurzus[filter_key] == filter_value]

    return filtered_kurzusok
    
@utvonal.put("/kurzusok/{kurzus_id}", response_model=Kurzus)
async def update_kurzus(kurzus_id: int, kurzus: Kurzus):
    kurzusok= fajl_kezelo.kurzusok_olvasas()
    l = False
    for k in kurzusok:
        if(k["id"]==kurzus_id):
            kurzusok.remove(k)
            updated_kurzusok = kurzusok + [jsonable_encoder(kurzus)]
            fajl_kezelo.kurzusok_iras(updated_kurzusok)
            l=True
    if(not l):
       raise HTTPException(status_code=400, detail="Nincs kurzus ezzel az id azonosítóval. Ha új kurzust szeretnél létrehozni azt a kurzusoknál tudod megcsinálni.")

    return kurzus

@utvonal.get("/kurzusok/hallgatok/{hallgato_id}", response_model=List[Kurzus])
async def get_hallgato_kurzusai(hallgato_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    #hallgato_kurzusai = any(hallgato_id in x.get('id') for x in kurzus.get('hallgatok') for kurzus in kurzusok)
    result = [k for k in fajl_kezelo.kurzusok_olvasas() for hallgato in k["hallgatok"] if hallgato["id"] == hallgato_id]
    if(result == []):
        raise HTTPException(status_code=400, detail="Nincs az alábbi idvel rendelkező tanuló.")
    return result


@utvonal.delete("/kurzusok/{kurzus_id}")
async def delete_kurzus(kurzus_id: int):
    result = [k for k in fajl_kezelo.kurzusok_olvasas() if k["id"] != kurzus_id]
    if(len(result) == len(fajl_kezelo.kurzusok_olvasas())):
        raise HTTPException(status_code=400, detail="Nincs ilyen idvel rendelkező kurzus.")
    fajl_kezelo.kurzusok_iras(result)


@utvonal.get("/kurzusok/{kurzus_id}/hallgatok/{hallgato_id}", response_model=Valasz)
async def get_hallgato_kurzuson(kurzus_id: int, hallgato_id: int):
    result = [k for k in fajl_kezelo.kurzusok_olvasas() for hallgato in k["hallgatok"] if k["id"] == kurzus_id and hallgato["id"] == hallgato_id ]
    if(len(result)> 0):
        return Valasz(uzenet="Igen")
    else: 
        return Valasz(uzenet="Nem")


#http://127.0.0.1:8000/docs