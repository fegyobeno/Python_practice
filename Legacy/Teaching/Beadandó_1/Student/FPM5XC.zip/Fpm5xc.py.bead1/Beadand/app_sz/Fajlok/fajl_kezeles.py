import json
from .modellek import Kurzus

class KurzusFajlKezelo:
    utvonal = "kurzusok.json"

    def kurzusok_olvasas(self):
        try:
            with open(self.utvonal, "r") as be:
                kurzusok_data = json.load(be)
            # JSON adatok konvertálása Kurzus objektumokká
            kurzusok = [Kurzus(**k) for k in kurzusok_data]
        except FileNotFoundError:
            return []
        except json.JSONDecodeError:
            raise ValueError("Hibás JSON formátum a fájlban.")
        return kurzusok

    def kurzusok_iras(self, kurzusok):
        # Kurzus objektumok konvertálása szótárrá az íráshoz
        kurzusok_data = [k.dict() for k in kurzusok]
        with open(self.utvonal, "w") as ki:
            json.dump(kurzusok_data, ki, indent=4)
