from fastapi import APIRouter, HTTPException
from typing import List
from .modellek import Kurzus, Valasz
from .fajl_kezeles import KurzusFajlKezelo


utvonal = APIRouter()

fajl_kezelo = KurzusFajlKezelo()


@utvonal.get("/kurzusok", response_model=List[Kurzus])
async def get_osszes_kurzus():
    try : 
        return fajl_kezelo.kurzusok_olvasas()
    except:
            return HTTPException(status_code=404, detail=f"Nem található kurzusok")


@utvonal.post("/kurzusok", response_model=Valasz)
async def uj_kurzus(kurzus: Kurzus):
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()
        letezik = False
        for k in kurzusok:
            if k['id'] == kurzus.id:
                letezik = True
        if letezik==False:
            kurzusok.append(kurzus.model_dump(mode='json'))
            fajl_kezelo.kurzusok_iras(kurzusok)
            return  Valasz(uzenet="Sikeres felvétel.")
        else:
            return Valasz(uzenet="Ez a kurzus id már foglalt")
    except:
        return HTTPException(status_code=404, detail=f"Nem található kurzusok")


@utvonal.get("/kurzusok/filter", response_model=List[Kurzus])
async def get_kurzusok_filter(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    try:
       
        szurok = [nap_idopont, oktato_email, tipus, evfolyam, helyszin, max_letszam]
        szurok_szama = 0
        for szuro in szurok:
            if szuro is not None:
                szurok_szama += 1
        if szurok_szama == 1:
            kurzusok = fajl_kezelo.kurzusok_olvasas()
            result = []
            for kurzus in kurzusok:
                if nap_idopont is not None and kurzus['nap_idopont'] != nap_idopont:
                    continue
                if oktato_email is not None and kurzus['oktato_email'] != oktato_email:
                    continue
                if tipus is not None and kurzus['tipus'] != tipus:
                    continue
                if evfolyam is not None and kurzus['evfolyam'] != evfolyam:
                    continue
                if helyszin is not None and kurzus['helyszin'] != helyszin:
                    continue
                if max_letszam is not None and kurzus['max_letszam'] > max_letszam:
                    continue
                result.append(kurzus)
            return result
        else:
            return []
            
    except:
        return HTTPException(status_code=404, detail=f"Nem található kurzusok")

@utvonal.get("/kurzusok/filters", response_model=List[Kurzus])
async def get_kurzusok_filters(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    try:
        
        szurok = [nap_idopont, oktato_email, tipus, evfolyam, helyszin, max_letszam]
        szurok_szama = 0
        for szuro in szurok:
            if szuro is not None:
                szurok_szama += 1
        if szurok_szama == 2:

            kurzusok = fajl_kezelo.kurzusok_olvasas()
            result = []
            for kurzus in kurzusok:
                if nap_idopont is not None and kurzus['nap_idopont'] != nap_idopont:
                    continue
                if oktato_email is not None and kurzus['oktato_email'] != oktato_email:
                    continue
                if tipus is not None and kurzus['tipus'] != tipus:
                    continue
                if evfolyam is not None and kurzus['evfolyam'] != evfolyam:
                    continue
                if helyszin is not None and kurzus['helyszin'] != helyszin:
                    continue
                if max_letszam is not None and kurzus['max_letszam'] > max_letszam:
                    continue
                result.append(kurzus)
            return result
        else:
            return []
    except:
        return HTTPException(status_code=404, detail=f"Nem található kurzusok")
    


@utvonal.put("/kurzusok/{kurzus_id}", response_model=Kurzus)
async def update_kurzus(kurzus_id: int, kurzus: Kurzus):
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()
        for k in kurzusok:
            if k['id'] == kurzus_id:
                k['nev'] = kurzus.nev
                k['tipus'] = kurzus.tipus
                k['evfolyam'] = kurzus.evfolyam
                k['nap_idopont'] = kurzus.nap_idopont
                k['helyszin'] = kurzus.helyszin
                oktato = kurzus.oktato
                k['oktato'] = oktato.model_dump(mode='json')
                hallgatok = kurzus.hallgatok
                if hallgatok is not None:
                    k['hallgatok'] = [h.model_dump(mode='json') for h in hallgatok]
                k['max_letszam'] = kurzus.max_letszam

                fajl_kezelo.kurzusok_iras(kurzusok)
                return kurzus
        return HTTPException(status_code=404, detail=f"Nem található kurzus")
    except:
        return HTTPException(status_code=404, detail=f"Nem található kurzus")


@utvonal.get("/kurzusok/hallgatok/{hallgato_id}", response_model=List[Kurzus])
async def get_hallgato_kurzusai(hallgato_id: int):
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()
        result = []
        for kurzus in kurzusok:
            hallgatok = kurzus['hallgatok']
            if hallgatok is not None:
                for hallgato in hallgatok:
                    if hallgato['id'] == hallgato_id:
                        result.append(kurzus)
        return result
    except:
        return HTTPException(status_code=404, detail=f"Nem található kurzusok")


@utvonal.delete("/kurzusok/{kurzus_id}")
async def delete_kurzus(kurzus_id: int):
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()
        for k in kurzusok:
            if k['id'] == kurzus_id:
                kurzusok.remove(k)
                fajl_kezelo.kurzusok_iras(kurzusok)
                return Valasz(uzenet="Sikeres törlés.")
        return HTTPException(status_code=404, detail=f"Nem található kurzus")
    except:
        return HTTPException(status_code=404, detail=f"Nem található kurzus")


@utvonal.get("/kurzusok/{kurzus_id}/hallgatok/{hallgato_id}", response_model=Valasz)
async def get_hallgato_kurzuson(kurzus_id: int, hallgato_id: int):
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()
        for kurzus in kurzusok:
            if kurzus['id'] == kurzus_id:
                hallgatok = kurzus['hallgatok']
                if hallgatok is not None:
                    for hallgato in hallgatok:
                        if hallgato['id'] == hallgato_id:
                            return Valasz(uzenet="Igen")
        return Valasz(uzenet="Nem")
    except:
        return HTTPException(status_code=404, detail=f"Nem található kurzusok")
