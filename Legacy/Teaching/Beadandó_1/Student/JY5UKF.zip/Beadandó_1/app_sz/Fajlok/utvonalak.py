import typing as t
from fastapi import APIRouter, HTTPException
from .modellek import Kurzus, Valasz
from .fajl_kezeles import KurzusFajlKezelo


router = APIRouter()

file_manager = KurzusFajlKezelo()


@router.get("/kurzusok", response_model=list[Kurzus])
async def get_osszes_kurzus() -> list[Kurzus]:
    return [Kurzus.model_validate(k) for k in file_manager.kurzusok_olvasas()]


@router.post("/kurzusok", response_model=Valasz)
async def uj_kurzus(kurzus: Kurzus) -> Valasz:
    all_kurzus = [Kurzus.model_validate(k) for k in file_manager.kurzusok_olvasas()]

    if any(k.id == kurzus.id for k in all_kurzus):
        raise HTTPException(status_code=400, detail="Ez a kurzus id már foglalt")

    file_manager.kurzusok_iras(file_manager.kurzusok_olvasas() + [kurzus.model_dump()])

    return Valasz(uzenet="Sikeres felvétel.")


@router.get("/kurzusok/filter", response_model=list[Kurzus])
async def get_kurzusok_filter(
    nap_idopont: str | None = None,
    oktato_email: str | None = None,
    tipus: str | None = None,
    evfolyam: int | None = None,
    helyszin: str | None = None,
    max_letszam: int | None = None,
) -> list[Kurzus]:
    kurzusok = [Kurzus.model_validate(k) for k in file_manager.kurzusok_olvasas()]

    query_params: dict[str, t.Any] = {
        "nap_idopont": nap_idopont,
        "oktato_email": oktato_email,
        "tipus": tipus,
        "evfolyam": evfolyam,
        "helyszin": helyszin,
        "max_letszam": max_letszam,
    }

    actual_query_params = {k: v for k, v in query_params.items() if v}

    if len(actual_query_params) != 1:
        raise HTTPException(status_code=400, detail="Pontosan egy szűrőt adjon meg")

    matches = [
        kurzus
        for kurzus in kurzusok
        if all(
            getattr(kurzus, key) == value for key, value in actual_query_params.items()
        )
    ]

    if not matches:
        raise HTTPException(status_code=404, detail="Nincs találat")

    return matches


@router.get("/kurzusok/filters", response_model=list[Kurzus])
async def get_kurzusok_filters(
    nap_idopont: str | None = None,
    oktato_email: str | None = None,
    tipus: str | None = None,
    evfolyam: int | None = None,
    helyszin: str | None = None,
    max_letszam: int | None = None,
) -> list[Kurzus]:
    query_params: dict[str, t.Any] = {
        "nap_idopont": nap_idopont,
        "oktato_email": oktato_email,
        "tipus": tipus,
        "evfolyam": evfolyam,
        "helyszin": helyszin,
        "max_letszam": max_letszam,
    }

    actual_query_params = {k: v for k, v in query_params.items() if v}

    if len(actual_query_params) != 2:
        raise HTTPException(status_code=400, detail="Pontosan két szűrőt adjon meg")

    kurzusok = [Kurzus.model_validate(k) for k in file_manager.kurzusok_olvasas()]

    matches = [
        kurzus
        for kurzus in kurzusok
        if all(
            getattr(kurzus, key) == value for key, value in actual_query_params.items()
        )
    ]

    if not matches:
        raise HTTPException(status_code=404, detail="Nincs találat")

    return matches


@router.put("/kurzusok/{kurzus_id}", response_model=Kurzus)
async def update_kurzus(kurzus_id: int, kurzus: Kurzus) -> Kurzus:
    kurzusok = [Kurzus.model_validate(k) for k in file_manager.kurzusok_olvasas()]

    if not any(k.id == kurzus_id for k in kurzusok):
        raise HTTPException(status_code=404, detail="Nincs ilyen kurzus")

    file_manager.kurzusok_iras(
        [k.model_dump() if k.id != kurzus_id else kurzus.model_dump() for k in kurzusok]
    )

    return kurzus


@router.get("/kurzusok/hallgatok/{hallgato_id}", response_model=list[Kurzus])
async def get_hallgato_kurzusai(hallgato_id: int):
    kurzusok = [Kurzus.model_validate(k) for k in file_manager.kurzusok_olvasas()]

    hallgato_kurzusai = [
        kurzus
        for kurzus in kurzusok
        if kurzus.hallgatok is not None
        and any(h.id == hallgato_id for h in kurzus.hallgatok)
    ]

    if not hallgato_kurzusai:
        raise HTTPException(status_code=404, detail="Nincs találat")

    return hallgato_kurzusai


@router.delete("/kurzusok/{kurzus_id}")
async def delete_kurzus(kurzus_id: int):
    kurzusok = [Kurzus.model_validate(k) for k in file_manager.kurzusok_olvasas()]

    if not any(k.id == kurzus_id for k in kurzusok):
        raise HTTPException(status_code=404, detail="Nincs ilyen kurzus")

    file_manager.kurzusok_iras([k.model_dump() for k in kurzusok if k.id != kurzus_id])


@router.get("/kurzusok/{kurzus_id}/hallgatok/{hallgato_id}", response_model=Valasz)
async def get_hallgato_kurzuson(kurzus_id: int, hallgato_id: int) -> Valasz:
    kurzusok = [Kurzus.model_validate(k) for k in file_manager.kurzusok_olvasas()]

    kurzus = next((k for k in kurzusok if k.id == kurzus_id), None)

    if kurzus is None:
        raise HTTPException(status_code=404, detail="Nincs ilyen kurzus")

    if kurzus.hallgatok is None:
        return Valasz(uzenet="A kurzuson nincsenek hallgatók")

    if any(h.id == hallgato_id for h in kurzus.hallgatok):
        return Valasz(uzenet="Igen")

    return Valasz(uzenet="Nem")
