from pydantic import BaseModel


class Oktato(BaseModel):
    nev: str
    email: str


class Hallgato(BaseModel):
    id: int | None
    nev: str
    email: str


class Kurzus(BaseModel):
    id: int | None
    nev: str
    tipus: str
    evfolyam: int
    nap_idopont: str
    helyszin: str
    oktato: Oktato
    hallgatok: list[Hallgato] | None
    max_letszam: int


class Valasz(BaseModel):
    uzenet: str
