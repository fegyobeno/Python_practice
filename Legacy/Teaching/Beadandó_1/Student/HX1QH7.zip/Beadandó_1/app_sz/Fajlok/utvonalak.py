from fastapi import APIRouter, HTTPException, Query, Path
from typing import List, Optional
from .modellek import Kurzus, Valasz
from .fajl_kezeles import KurzusFajlKezelo

utvonal = APIRouter()
fajl_kezelo = KurzusFajlKezelo()

@utvonal.get("/kurzusok", response_model=List[Kurzus])
async def get_osszes_kurzus():
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()
        return kurzusok
    except Exception as e:
        raise HTTPException(status_code=500, detail="Hiba a kurzusok lekérdezése során")

@utvonal.post("/kurzusok", response_model=Valasz)
async def uj_kurzus(kurzus: Kurzus):
    try:
        kurzusok_data = fajl_kezelo.kurzusok_olvasas()
        kurzusok = [Kurzus.parse_obj(k) for k in kurzusok_data]
        
        if any(k.id == kurzus.id for k in kurzusok):
            raise HTTPException(status_code=400, detail="Ez a kurzus id már foglalt")
        
        kurzusok.append(kurzus)
        
        kurzusok_data = [k.dict() for k in kurzusok]
        fajl_kezelo.kurzusok_iras(kurzusok_data)
        
        return {"uzenet": "Sikeres felvétel"}
    
    except HTTPException as e:
        raise e
    except Exception as e:
        print(f"Kurzus hozzáadási hiba részletei: {e}")
        raise HTTPException(status_code=500, detail="Hiba a kurzus hozzáadásakor")

@utvonal.get("/kurzusok/filter", response_model=List[Kurzus])
async def get_kurzusok_filter(
    nap_idopont: Optional[str] = Query(None),
    oktato_email: Optional[str] = Query(None),
    tipus: Optional[str] = Query(None),
    evfolyam: Optional[int] = Query(None),
    helyszin: Optional[str] = Query(None),
    max_letszam: Optional[int] = Query(None)
):
    try:
        kurzusok_data = fajl_kezelo.kurzusok_olvasas()
        kurzusok = [Kurzus.parse_obj(k) for k in kurzusok_data]
        
        if nap_idopont:
            kurzusok = [k for k in kurzusok if k.nap_idopont == nap_idopont]
        if oktato_email:
            kurzusok = [k for k in kurzusok if k.oktato.email == oktato_email]
        if tipus:
            kurzusok = [k for k in kurzusok if k.tipus == tipus]
        if evfolyam:
            kurzusok = [k for k in kurzusok if k.evfolyam == evfolyam]
        if helyszin:
            kurzusok = [k for k in kurzusok if k.helyszin == helyszin]
        if max_letszam:
            kurzusok = [k for k in kurzusok if k.max_letszam == max_letszam]
        
        if not kurzusok:
            raise HTTPException(status_code=404, detail="Nincs találat a keresett szűrőkkel")
        
        return kurzusok
    
    except Exception as e:
        print(f"Hiba a kurzusok lekérdezésekor: {e}")
        raise HTTPException(status_code=500, detail="Hiba történt a kurzusok lekérdezésekor")

@utvonal.get("/kurzusok/filters", response_model=List[Kurzus])
async def get_kurzusok_filters(
    nap_idopont: Optional[str] = Query(None),
    oktato_email: Optional[str] = Query(None),
    tipus: Optional[str] = Query(None),
    evfolyam: Optional[int] = Query(None),
    helyszin: Optional[str] = Query(None),
    max_letszam: Optional[int] = Query(None)
):
    szurok = [nap_idopont, oktato_email, tipus, evfolyam, helyszin, max_letszam]
    szurok = [szuro for szuro in szurok if szuro is not None]

    if len(szurok) != 2:
        raise HTTPException(status_code=400, detail="Pontosan két szűrőt kell megadni.")

    try:
        kurzusok_data = fajl_kezelo.kurzusok_olvasas()
        kurzusok = [Kurzus.parse_obj(k) for k in kurzusok_data]
        
        if nap_idopont:
            kurzusok = [k for k in kurzusok if k.nap_idopont == nap_idopont]
        if oktato_email:
            kurzusok = [k for k in kurzusok if k.oktato.email == oktato_email]
        if tipus:
            kurzusok = [k for k in kurzusok if k.tipus == tipus]
        if evfolyam:
            kurzusok = [k for k in kurzusok if k.evfolyam == evfolyam]
        if helyszin:
            kurzusok = [k for k in kurzusok if k.helyszin == helyszin]
        if max_letszam:
            kurzusok = [k for k in kurzusok if k.max_letszam == max_letszam]
        
        if not kurzusok:
            raise HTTPException(status_code=404, detail="Nincs találat a keresett szűrőkkel")
        
        return kurzusok
    
    except Exception as e:
        print(f"Hiba a kurzusok lekérdezésekor: {e}")
        raise HTTPException(status_code=500, detail="Hiba történt a kurzusok lekérdezésekor")

@utvonal.put("/kurzusok/{kurzus_id}", response_model=Kurzus)
async def update_kurzus(kurzus_id: int, updated_kurzus: Kurzus):
    try:
        kurzusok_data = fajl_kezelo.kurzusok_olvasas()
        
        kurzus = next((k for k in kurzusok_data if k["id"] == kurzus_id), None)
        
        if not kurzus:
            raise HTTPException(status_code=404, detail="Kurzus nem található")
        
        kurzus["nev"] = updated_kurzus.nev
        kurzus["tipus"] = updated_kurzus.tipus
        kurzus["evfolyam"] = updated_kurzus.evfolyam
        kurzus["nap_idopont"] = updated_kurzus.nap_idopont
        kurzus["helyszin"] = updated_kurzus.helyszin
        kurzus["oktato"] = updated_kurzus.oktato.dict()
        kurzus["max_letszam"] = updated_kurzus.max_letszam
        
        fajl_kezelo.kurzusok_iras(kurzusok_data)
        
        return updated_kurzus
    
    except Exception as e:
        print(f"Hiba a kurzus frissítésekor: {e}")
        raise HTTPException(status_code=500, detail="Hiba történt a kurzus frissítésekor")

@utvonal.get("/kurzusok/hallgatok/{hallgato_id}")
async def get_hallgato_kurzusai(hallgato_id: int):
    try:
        kurzusok_data = fajl_kezelo.kurzusok_olvasas()
        
        hallgato_kurzusok = [
            kurzus for kurzus in kurzusok_data 
            if any(hallgato["id"] == hallgato_id for hallgato in kurzus["hallgatok"])
        ]
        
        if not hallgato_kurzusok:
            raise HTTPException(status_code=404, detail="A hallgatóhoz tartozó kurzusok nem találhatók")
        
        return {"kurzusok": hallgato_kurzusok}
    
    except Exception as e:
        print(f"Hiba a hallgató kurzusainak lekérésekor: {e}")
        raise HTTPException(status_code=500, detail="Hiba történt a hallgató kurzusainak lekérésekor")

@utvonal.delete("/kurzusok/{kurzus_id}")
async def delete_kurzus(kurzus_id: int):
    try:
        kurzusok_data = fajl_kezelo.kurzusok_olvasas()
        
        kurzus = next((k for k in kurzusok_data if k["id"] == kurzus_id), None)
        
        if not kurzus:
            raise HTTPException(status_code=404, detail="Kurzus nem található")
        
        kurzusok_data = [k for k in kurzusok_data if k["id"] != kurzus_id]
        
        fajl_kezelo.kurzusok_iras(kurzusok_data)
        
        return {"detail": "Kurzus sikeresen törölve"}
    
    except Exception as e:
        print(f"Hiba a kurzus törlésekor: {e}")
        raise HTTPException(status_code=500, detail="Hiba történt a kurzus törlésekor")

@utvonal.get("/kurzusok/{kurzus_id}/hallgatok/{hallgato_id}")
async def get_hallgato_kurzuson(kurzus_id: int, hallgato_id: int):
    try:
        kurzusok_data = fajl_kezelo.kurzusok_olvasas()
        
        kurzus = next((kurzus for kurzus in kurzusok_data if kurzus["id"] == kurzus_id), None)
        
        if kurzus is None:
            raise HTTPException(status_code=404, detail="A kurzus nem található")
        
        hallgato_reszere = any(hallgato["id"] == hallgato_id for hallgato in kurzus["hallgatok"])
        
        if hallgato_reszere:
            return {"uzenet": "Igen"}
        else:
            return {"uzenet": "Nem"}

    except Exception as e:
        print(f"Hiba a hallgató kurzuson való ellenőrzésénél: {e}")
        raise HTTPException(status_code=500, detail="Hiba történt a hallgató kurzuson való ellenőrzésekor")
