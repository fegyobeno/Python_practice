"""
Készítette: Zámborszky Balázs
Neptun kód: B0SHMA
"""

from fastapi import APIRouter, HTTPException
from typing import List
from .modellek import Kurzus, Valasz
from .fajl_kezeles import KurzusFajlKezelo


utvonal = APIRouter()
fajl_kezelo = KurzusFajlKezelo()


@utvonal.get("/kurzusok", response_model=List[Kurzus])
async def get_osszes_kurzus():
    return fajl_kezelo.kurzusok_olvasas()


@utvonal.post("/kurzusok", response_model=Valasz)
async def uj_kurzus(kurzus: Kurzus):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    ids = [it["id"] for it in kurzusok]
    
    # Kurzus ID már foglalt
    if kurzus.id in ids:
        return { "uzenet": "Ez a kurzus id már foglalt" }
        
    # Kurzus hozzáadása
    kurzusok.append(kurzus.model_dump())
    fajl_kezelo.kurzusok_iras(kurzusok)
    return { "uzenet": "Sikeres felvétel." }


# Kurzus filter függvény
def kurzus_filter(kurzusok: list[dict[str, object]], **filters: dict[str, str | int]):
    get_value = lambda it, key: it[key] if key in it else (it[key.split("_")[0]][key.split("_")[1]] if key.split("_")[0] in it else None)
    filtered = kurzusok
    for key, value in filters.items():
        filtered = [it for it in filtered if value is None or get_value(it, key) == value]
    return filtered


# Hallgató ID-k listázása a kurzus(ok)on
def hallgatok_lista(kurzusok: list[dict[str, object]] | dict[str, object]):
    hallgatok: set[int] = set()
    for k in (kurzusok if isinstance(kurzusok, list) else [kurzusok]):
        for h in k["hallgatok"]:
            hallgatok.add(h["id"])
    return hallgatok


@utvonal.get("/kurzusok/filter", response_model=List[Kurzus])
async def get_kurzusok_filter(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: int = None, helyszin: str = None, max_letszam: int = None):
    params = [nap_idopont, oktato_email, tipus, evfolyam, helyszin, max_letszam]

    # Filterek száma nem megfelelő
    if params.count(None) != len(params) - 1:
        raise HTTPException(status_code=400, detail="Egyszerre csak egy filter használata engedélyezett, az viszont kötelező")
    
    # Filter alkalmazása
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    return kurzus_filter(kurzusok, nap_idopont=nap_idopont, oktato_email=oktato_email, tipus=tipus, evfolyam=evfolyam, helyszin=helyszin, max_letszam=max_letszam)


@utvonal.get("/kurzusok/filters", response_model=List[Kurzus])
async def get_kurzusok_filters(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: int = None, helyszin: str = None, max_letszam: int = None):
    params = [nap_idopont, oktato_email, tipus, evfolyam, helyszin, max_letszam]

    # Filterek száma nem megfelelő
    if params.count(None) != len(params) - 2:
        raise HTTPException(status_code=400, detail="Egyszerre csak két filter használata engedélyezett, azok viszont kötelezőek")
    
    # Filter alkalmazása
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    return kurzus_filter(kurzusok, nap_idopont=nap_idopont, oktato_email=oktato_email, tipus=tipus, evfolyam=evfolyam, helyszin=helyszin, max_letszam=max_letszam)


@utvonal.put("/kurzusok/{kurzus_id}", response_model=Kurzus)
async def update_kurzus(kurzus_id: int, kurzus: Kurzus):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    old_kurzus = kurzus_filter(kurzusok, id=kurzus_id)

    # Nem létező kurzus ID
    if len(old_kurzus) < 1:
        raise HTTPException(status_code=404, detail="Kurzus nem található")
    old_kurzus = old_kurzus[0]

    # Kurzus adatainak frissítése
    for key, value in kurzus.model_dump().items():
        if key == "id": continue # Kurzus ID frissítés tiltása
        old_kurzus[key] = value
    
    # Kurzus mentése és visszaadása
    fajl_kezelo.kurzusok_iras(kurzusok)
    return old_kurzus


@utvonal.get("/kurzusok/hallgatok/{hallgato_id}", response_model=List[Kurzus])
async def get_hallgato_kurzusai(hallgato_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    
    # Nem található a hallgató
    if hallgato_id not in hallgatok_lista(kurzusok):
        raise HTTPException(status_code=404, detail="Hallgató nem található")
    
    # Hallgató kurzusok listázása
    return list(filter(lambda it: hallgato_id in hallgatok_lista(it), kurzusok))


@utvonal.delete("/kurzusok/{kurzus_id}")
async def delete_kurzus(kurzus_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    old_kurzus = kurzus_filter(kurzusok, id=kurzus_id)

    # Kurzus törlése
    kurzusok = list(filter(lambda it: it["id"] != kurzus_id, kurzusok))
    fajl_kezelo.kurzusok_iras(kurzusok)
    return "Sikeres törlés" if len(old_kurzus) else "Nem található kurzus az adott azonosítóval"


@utvonal.get("/kurzusok/{kurzus_id}/hallgatok/{hallgato_id}", response_model=Valasz)
async def get_hallgato_kurzuson(kurzus_id: int, hallgato_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    kurzus = kurzus_filter(kurzusok, id=kurzus_id)
    
    # Nem található a kurzus
    if len(kurzus) < 1:
        raise HTTPException(status_code=404, detail="Kurzus nem található")
    kurzus = kurzus[0]

    # Nem található a hallgató
    if hallgato_id not in hallgatok_lista(kurzusok):
        raise HTTPException(status_code=404, detail="Hallgató nem található")
    
    # Hallgatók lekérése és válasz
    hallgatok = [ it["id"] for it in kurzus["hallgatok"] ]
    return { "uzenet": "Igen" if hallgato_id in hallgatok else "Nem" }
