from fastapi import APIRouter, HTTPException
from typing import List
from .modellek import Kurzus, Valasz
from .fajl_kezeles import KurzusFajlKezelo


utvonal = APIRouter()

fajl_kezelo = KurzusFajlKezelo()



@utvonal.get("/kurzusok", response_model=List[Kurzus])
async def get_osszes_kurzus():
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()
        if kurzusok:
            return [Kurzus(**k) for k in kurzusok]
        else:
            raise HTTPException(status_code=404, detail="Nincsenek kurzusok az adattárban.")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))



@utvonal.post("/kurzusok", response_model=Valasz)
async def uj_kurzus(kurzus: Kurzus):
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()
        for k in kurzusok:
            if k['id'] == kurzus.id:
                raise HTTPException(status_code=400, detail="Ez a kurzus id már foglalt.")
        
        kurzusok.append(kurzus.dict())
        fajl_kezelo.kurzusok_iras(kurzusok)
        return Valasz(uzenet="Sikeres felvétel.")
    
    except HTTPException as e:
        raise e
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))



@utvonal.get("/kurzusok/filter", response_model=List[Kurzus])
async def get_kurzusok_filter(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: int = None, helyszin: str = None, max_letszam: int = None):
    try:
        params = [nap_idopont, oktato_email, tipus, evfolyam, helyszin, max_letszam]
        params = [p for p in params if not p is None]
        if len(params) > 1:
            raise HTTPException(status_code=400, detail="Csak 1 paramétert lehet megadni")
        
        kurzusok = fajl_kezelo.kurzusok_olvasas()
        filtered_kurzusok = [k for k in kurzusok if
                             (nap_idopont is None or k['nap_idopont'] == nap_idopont) and
                             (oktato_email is None or k['oktato']['email'] == oktato_email) and
                             (tipus is None or k['tipus'] == tipus) and
                             (evfolyam is None or k['evfolyam'] == evfolyam) and
                             (helyszin is None or k['helyszin'] == helyszin) and
                             (max_letszam is None or k['max_letszam'] == max_letszam)]

        if filtered_kurzusok:
            return [Kurzus(**k) for k in filtered_kurzusok]
        else:
            raise HTTPException(status_code=404, detail="Nem találhatók a megadott szűrőknek megfelelő kurzusok.")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))



@utvonal.get("/kurzusok/filters", response_model=List[Kurzus])
async def get_kurzusok_filters(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: int = None, helyszin: str = None, max_letszam: int = None):
    try:
        params = [nap_idopont, oktato_email, tipus, evfolyam, helyszin, max_letszam]
        params = [p for p in params if not p is None]
        if len(params) > 2:
            raise HTTPException(status_code=400, detail="Maximum 2 paramétert lehet megadni")
        kurzusok = fajl_kezelo.kurzusok_olvasas()
        filtered_kurzusok = [k for k in kurzusok if
                             (nap_idopont is None or k['nap_idopont'] == nap_idopont) and
                             (oktato_email is None or k['oktato']['email'] == oktato_email) and
                             (tipus is None or k['tipus'] == tipus) and
                             (evfolyam is None or k['evfolyam'] == evfolyam) and
                             (helyszin is None or k['helyszin'] == helyszin) and
                             (max_letszam is None or k['max_letszam'] == max_letszam)]
        if filtered_kurzusok:
            return [Kurzus(**k) for k in filtered_kurzusok]
        else:
            raise HTTPException(status_code=404, detail="Nem találhatók a megadott szűrőknek megfelelő kurzusok.")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))



@utvonal.put("/kurzusok/{kurzus_id}", response_model=Kurzus)
async def update_kurzus(kurzus_id: int, kurzus: Kurzus):
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()
        for i, k in enumerate(kurzusok):
            if k['id'] == kurzus_id:
                kurzusok[i] = kurzus.dict()
                fajl_kezelo.kurzusok_iras(kurzusok)
                return kurzus
        raise HTTPException(status_code=404, detail="A megadott ID-vel nem található kurzus.")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))



@utvonal.get("/kurzusok/hallgatok/{hallgato_id}", response_model=List[Kurzus])
async def get_hallgato_kurzusai(hallgato_id: int):
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()
        hallgato_kurzusai = [k for k in kurzusok if any(h['id'] == hallgato_id for h in k.get('hallgatok', []))]
        if hallgato_kurzusai:
            return hallgato_kurzusai
        else:
            raise HTTPException(status_code=404, detail="Az adott hallgatóhoz nem találhatók kurzusok.")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))



@utvonal.delete("/kurzusok/{kurzus_id}")
async def delete_kurzus(kurzus_id: int):
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()
        eredetilen = len(kurzusok)
        kurzusok = [k for k in kurzusok if k['id'] != kurzus_id]
        fajl_kezelo.kurzusok_iras(kurzusok)
        if eredetilen == len(kurzusok):
            return {"detail" : "Törlendő kurzus nem található, lehetséges, hogy korábban már törölve lett"}
        return {"detail": "Kurzus sikeresen törölve."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))



@utvonal.get("/kurzusok/{kurzus_id}/hallgatok/{hallgato_id}", response_model=Valasz)
async def get_hallgato_kurzuson(kurzus_id: int, hallgato_id: int):
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()
        for k in kurzusok:
            if k['id'] == kurzus_id:
                if any(h['id'] == hallgato_id for h in k.get('hallgatok', [])):
                    return Valasz(uzenet="Igen")
                else:
                    return Valasz(uzenet="Nem")
        raise HTTPException(status_code=404, detail="A megadott ID-vel nem található kurzus.")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
