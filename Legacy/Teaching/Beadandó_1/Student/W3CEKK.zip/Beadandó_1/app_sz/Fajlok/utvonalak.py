from fastapi import APIRouter, HTTPException
from typing import List
from .modellek import Kurzus, Valasz
from .fajl_kezeles import KurzusFajlKezelo


utvonal = APIRouter()

fajl_kezelo = KurzusFajlKezelo()

@utvonal.get("/kurzusok", response_model=List[Kurzus])
async def get_osszes_kurzus():
    return fajl_kezelo.kurzusok_olvasas()

@utvonal.post("/kurzusok", response_model=Valasz)
async def uj_kurzus(kurzus: Kurzus):

    courses = fajl_kezelo.kurzusok_olvasas()
    
    for existing_kurzus in courses:
        if existing_kurzus.get("id") == kurzus.id:
            return Valasz(uzenet="Ez a kurzus id már foglalt")
    
    courses.append(kurzus.model_dump())
    fajl_kezelo.kurzusok_iras(courses)
    return Valasz(uzenet="Sikeres felvétel.")

#evfolyam must be int
@utvonal.get("/kurzusok/filter", response_model=List[Kurzus])
async def get_kurzusok_filter(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: int = None, helyszin: str = None, max_letszam: int = None):

    courses = fajl_kezelo.kurzusok_olvasas()
   
    filter_condition = {
        "nap_idopont": nap_idopont,
        "oktato_email": oktato_email,
        "tipus": tipus,
        "evfolyam": evfolyam,
        "helyszin": helyszin,
        "max_letszam": max_letszam
    }

    active_filter_condition = {}
    for k, i in filter_condition.items():
        if i is not None:
            if k not in active_filter_condition.keys():
                active_filter_condition[k] = i

    if len(active_filter_condition) != 1:
        raise HTTPException(status_code=404, detail="Pontosan egy szűrőt kell megadni.")
    
    
    search_key, search_value = list(active_filter_condition.items())[0]
    filtered_courses = []
    
    if search_key == "oktato_email":
        for c in courses:
            if c["oktato"]["email"] == search_value:
                filtered_courses.append(c)
    else:
        for c in courses:
            if c[search_key] == search_value:
                filtered_courses.append(c)

    if not filtered_courses:
        raise HTTPException(status_code=404, detail="Nincs találat a megadott szűrő feltételre.")
    
    return filtered_courses
#evfolyam must be int
@utvonal.get("/kurzusok/filters", response_model=List[Kurzus])
async def get_kurzusok_filters(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: int = None, helyszin: str = None, max_letszam: int = None):

    courses = fajl_kezelo.kurzusok_olvasas()
    FILTER_NUMER = 2


    filter_condition = {
        "nap_idopont": nap_idopont,
        "oktato_email": oktato_email,
        "tipus": tipus,
        "evfolyam": evfolyam,
        "helyszin": helyszin,
        "max_letszam": max_letszam
    }
    
    active_filter_condition = {}
    for k, i in filter_condition.items():
        if i is not None:
            if k not in active_filter_condition.keys():
                active_filter_condition[k] = i

    if len(active_filter_condition) != FILTER_NUMER:
        raise HTTPException(status_code=404, detail="Pontosan kettő szűrőt kell megadni.")
    active_filter_condition_list = list(active_filter_condition.items())
    filtered_courses = []

    van = True
    for c in courses:
        van = True
        for f in active_filter_condition_list:
            key = f[0]  
            value = f[1]
            if key == "oktato_email":
                if c["oktato"]["email"] != value:
                    van = False
            else:
                if c[key] != value:
                    van = False
        if van:
            filtered_courses.append(c)

    if not filtered_courses:
        raise HTTPException(status_code=404, detail="Nincs találat a megadott szűrő feltételekre.")
    
    return filtered_courses
    
@utvonal.put("/kurzusok/{kurzus_id}", response_model=Kurzus)
async def update_kurzus(kurzus_id: int, kurzus: Kurzus):

    courses = fajl_kezelo.kurzusok_olvasas()
    modified_courses = []
    course_to_update = None
    for c in courses:
        if c["id"] == kurzus_id:
            course_to_update = c
            course_to_update = kurzus.model_dump()
            modified_courses.append(course_to_update)
        else:
            modified_courses.append(c)
    if course_to_update is None:
        raise HTTPException(status_code=404, detail="Nincs ilyen kurzus ID!")
    
    fajl_kezelo.kurzusok_iras(modified_courses)

    return course_to_update

@utvonal.get("/kurzusok/hallgatok/{hallgato_id}", response_model=List[Kurzus])
async def get_hallgato_kurzusai(hallgato_id: int):

    courses = fajl_kezelo.kurzusok_olvasas()
    student_courses = []
    for course in courses: 
        for student in course["hallgatok"]:  
            if student['id'] == hallgato_id:
                student_courses.append(course)
                break
            
    if not student_courses:
        raise HTTPException(status_code=404, detail="Nincs ilyen diák ID")
    return student_courses 

@utvonal.delete("/kurzusok/{kurzus_id}")
async def delete_kurzus(kurzus_id: int):
    try:
        courses = fajl_kezelo.kurzusok_olvasas()
    except FileNotFoundError:
        raise HTTPException(status_code=500, detail="Kurzus adatfájl nem található!")
    except IOError:
        raise HTTPException(status_code=500, detail="Hiba történt a kurzus adatfájl olvasása közben!")

    modified_courses = []
    is_in = False
    for c in courses:
        if c["id"] == kurzus_id:
            is_in = True
        else:
            modified_courses.append(c)
    if not is_in:
        raise HTTPException(status_code=404, detail="Nincs ilyen kurzus ID!")
    
    try:
        fajl_kezelo.kurzusok_iras(modified_courses)
    except IOError:
        raise HTTPException(status_code=500, detail="Hiba történt a kurzus adatfájl írása közben!")

@utvonal.get("/kurzusok/{kurzus_id}/hallgatok/{hallgato_id}", response_model=Valasz)
async def get_hallgato_kurzuson(kurzus_id: int, hallgato_id: int):
    
    courses = fajl_kezelo.kurzusok_olvasas()
    for c in courses: 
        if c["id"] == kurzus_id:
            for student in c["hallgatok"]:  
                if student['id'] == hallgato_id:
                    return Valasz(uzenet="Igen") 
    return Valasz(uzenet="Nem") 
