from fastapi import APIRouter, HTTPException
from typing import List, Optional
from .modellek import Kurzus, Valasz
from .fajl_kezeles import KurzusFajlKezelo

utvonal = APIRouter()
fajl_kezelo = KurzusFajlKezelo()

@utvonal.get("/kurzusok", response_model=List[Kurzus])
async def get_osszes_kurzus():
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    return kurzusok

@utvonal.post("/kurzusok", response_model=Valasz)
async def uj_kurzus(kurzus: Kurzus):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    if any(k['id'] == kurzus.id for k in kurzusok):
        raise HTTPException(status_code=400, detail="Ez a kurzus id már foglalt.")
    kurzusok.append(kurzus.dict())
    fajl_kezelo.kurzusok_iras(kurzusok)
    return Valasz(uzenet= "Sikeres felvétel" )

@utvonal.get("/kurzusok/filter", response_model=List[Kurzus])
async def get_kurzusok_filter(
    nap_idopont: Optional[str] = None, oktato_email: Optional[str] = None,
    tipus: Optional[str] = None, evfolyam: Optional[int] = None,
    helyszin: Optional[str] = None, max_letszam: Optional[int] = None
):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    szurt_kurzusok = [
        k for k in kurzusok 
        if (nap_idopont is None or k['nap_idopont'] == nap_idopont) and
           (oktato_email is None or k['oktato']['email'] == oktato_email) and
           (tipus is None or k['tipus'] == tipus) and
           (evfolyam is None or k['evfolyam'] == evfolyam) and
           (helyszin is None or k['helyszin'] == helyszin) and
           (max_letszam is None or k['max_letszam'] == max_letszam)
    ]
    return szurt_kurzusok

@utvonal.get("/kurzusok/filters", response_model=List[Kurzus])
async def get_kurzusok_filters(
    nap_idopont: Optional[str] = None, oktato_email: Optional[str] = None,
    tipus: Optional[str] = None, evfolyam: Optional[int] = None,
    helyszin: Optional[str] = None, max_letszam: Optional[int] = None
):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    szurt_kurzusok = [
        k for k in kurzusok 
        if sum([bool(nap_idopont and k['nap_idopont'] == nap_idopont),
                bool(oktato_email and k['oktato']['email'] == oktato_email),
                bool(tipus and k['tipus'] == tipus),
                bool(evfolyam and k['evfolyam'] == evfolyam),
                bool(helyszin and k['helyszin'] == helyszin),
                bool(max_letszam and k['max_letszam'] == max_letszam)]) == 2
    ]
    return szurt_kurzusok

@utvonal.put("/kurzusok/{kurzus_id}", response_model=Kurzus)
async def update_kurzus(kurzus_id: int, kurzus: Kurzus):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    for i, k in enumerate(kurzusok):
        if k['id'] == kurzus_id:
            kurzusok[i] = kurzus.dict()
            fajl_kezelo.kurzusok_iras(kurzusok)
            return kurzus
    raise HTTPException(status_code=404, detail="Kurzus nem található.")

@utvonal.get("/kurzusok/hallgatok/{hallgato_id}", response_model=List[Kurzus])
async def get_hallgato_kurzusai(hallgato_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    hallgato_kurzusai = [k for k in kurzusok if any(h['id'] == hallgato_id for h in k['hallgatok'])]
    return hallgato_kurzusai

@utvonal.delete("/kurzusok/{kurzus_id}", response_model=Valasz)
async def delete_kurzus(kurzus_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    for i, k in enumerate(kurzusok):
        if k['id'] == kurzus_id:
            del kurzusok[i]
            fajl_kezelo.kurzusok_iras(kurzusok)
            return Valasz(uzenet = "Kurzus törölve.")
    raise HTTPException(status_code=404, detail="Kurzus nem található.")

@utvonal.get("/kurzusok/{kurzus_id}/hallgatok/{hallgato_id}", response_model=Valasz)
async def get_hallgato_kurzuson(kurzus_id: int, hallgato_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    for k in kurzusok:
        if k['id'] == kurzus_id:
            if any(h['id'] == hallgato_id for h in k['hallgatok']):
                return Valasz(uzenet="Igen")
            return Valasz(uzenet= "Nem" )
    raise HTTPException(status_code=404, detail="Kurzus nem található.")
