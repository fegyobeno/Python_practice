from fastapi import APIRouter, HTTPException
from typing import List
from .modellek import Kurzus, Valasz
from .fajl_kezeles import KurzusFajlKezelo


utvonal = APIRouter()

fajl_kezelo = KurzusFajlKezelo()

@utvonal.get("/kurzusok", response_model=List[Kurzus])
async def get_osszes_kurzus():
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    return kurzusok

@utvonal.post("/kurzusok", response_model=Valasz)
async def uj_kurzus(kurzus: Kurzus):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    if (any([kurzus.id == k["id"] for k in kurzusok])):
        raise HTTPException(status_code=400, detail="Ez a kurzus id már foglalt")
    kurzusok.append(kurzus.model_dump())
    fajl_kezelo.kurzusok_iras(kurzusok)
    return {"uzenet": "Sikeres felvétel."}

@utvonal.get("/kurzusok/filter", response_model=List[Kurzus])
async def get_kurzusok_filter(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    params = [nap_idopont, oktato_email, tipus, evfolyam, helyszin, max_letszam]
   
    if (len(list(filter(lambda x: x is not None, params))) != 1):
        raise HTTPException(status_code=400, detail="Pontosan egy filtert kell megadni")
    
    if (nap_idopont is not None):
        return list(filter(lambda x: x["nap_idopont"] == nap_idopont, fajl_kezelo.kurzusok_olvasas()))
    
    if (oktato_email is not None):
        return list(filter(lambda x: x["oktato_email"] == oktato_email, fajl_kezelo.kurzusok_olvasas()))
    
    if (tipus is not None):
        return list(filter(lambda x: x["tipus"] == tipus, fajl_kezelo.kurzusok_olvasas()))
    
    if (evfolyam is not None):
        return list(filter(lambda x: str(x["evfolyam"]) == evfolyam, fajl_kezelo.kurzusok_olvasas()))
    
    if (helyszin is not None):
        return list(filter(lambda x: x["helyszin"] == helyszin, fajl_kezelo.kurzusok_olvasas()))
    
    if (max_letszam is not None):
        return list(filter(lambda x: x["max_letszam"] == max_letszam, fajl_kezelo.kurzusok_olvasas()))
    

@utvonal.get("/kurzusok/filters", response_model=List[Kurzus])
async def get_kurzusok_filters(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    params = [nap_idopont, oktato_email, tipus, evfolyam, helyszin, max_letszam]
    
    if (len(list(filter(lambda x: x is not None, params))) != 2):
        raise HTTPException(status_code=400, detail="Pontosan két filtert kell megadni")
    
    filtered_list = fajl_kezelo.kurzusok_olvasas()
    
    if (nap_idopont is not None):
        filtered_list = list(filter(lambda x: x["nap_idopont"] == nap_idopont, filtered_list))
    
    if (oktato_email is not None):
        filtered_list = list(filter(lambda x: x["oktato"]["email"] == oktato_email, filtered_list))
    
    if (tipus is not None):
        filtered_list = list(filter(lambda x: x["tipus"] == tipus, filtered_list))
    
    if (evfolyam is not None):
        filtered_list = list(filter(lambda x: str(x["evfolyam"]) == evfolyam, filtered_list))
    
    if (helyszin is not None):
        filtered_list = list(filter(lambda x: x["helyszin"] == helyszin, filtered_list))
    
    if (max_letszam is not None):
        filtered_list = list(filter(lambda x: x["max_letszam"] == max_letszam, filtered_list))
    
    return filtered_list
    
@utvonal.put("/kurzusok/{kurzus_id}", response_model=Kurzus)
async def update_kurzus(kurzus_id: int, kurzus: Kurzus):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    for k in kurzusok:
        if k["id"] == kurzus_id:
            k["nev"] = kurzus.nev
            k["tipus"] = kurzus.tipus
            k["evfolyam"] = kurzus.evfolyam
            k["nap_idopont"] = kurzus.nap_idopont
            k["helyszin"] = kurzus.helyszin
            k["oktato"]["nev"] = kurzus.oktato.nev
            k["oktato"]["email"] = kurzus.oktato.email
            k["hallgatok"] = kurzus.hallgatok
            k["max_letszam"] = kurzus.max_letszam
            fajl_kezelo.kurzusok_iras(kurzusok)
            return kurzus
    raise HTTPException(status_code=404, detail="Nem található kurzus az adott id-vel")

@utvonal.get("/kurzusok/hallgatok/{hallgato_id}", response_model=List[Kurzus])
async def get_hallgato_kurzusai(hallgato_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    exists = False
    
    for kurzus in kurzusok:
        for hallgato in kurzus["hallgatok"]:
            if hallgato["id"] == hallgato_id:
                exists = True

    if not exists:
        raise HTTPException(status_code=404, detail="Nem található hallgató az adott id-vel")
                
    return list(filter(lambda kurzus: hallgato_id in [h["id"] for h in kurzus["hallgatok"]], kurzusok))


@utvonal.delete("/kurzusok/{kurzus_id}")
async def delete_kurzus(kurzus_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    for k in kurzusok:
        if k["id"] == kurzus_id:
            kurzusok.remove(k)
            fajl_kezelo.kurzusok_iras(kurzusok)
            return {"uzenet": "Sikeres törlés."}
    
    raise HTTPException(status_code=404, detail="Nem található kurzus az adott id-vel")

@utvonal.get("/kurzusok/{kurzus_id}/hallgatok/{hallgato_id}", response_model=Valasz)
async def get_hallgato_kurzuson(kurzus_id: int, hallgato_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    if (not any([hallgato_id in [h["id"] for h in k["hallgatok"]] for k in kurzusok])):
        raise HTTPException(status_code=404, detail="Nem található hallgató az adott id-vel")

    for k in kurzusok:
        if k["id"] == kurzus_id:
            if (hallgato_id in [h["id"] for h in k["hallgatok"]]):
                return {"uzenet": "Igen"}
            return {"uzenet": "Nem"}
    
    raise HTTPException(status_code=404, detail="Nem található kurzus az adott id-vel")
