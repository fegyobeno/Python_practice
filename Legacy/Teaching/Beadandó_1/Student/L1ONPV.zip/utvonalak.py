import json
from fastapi import APIRouter, HTTPException
from typing import List
from pydantic import ValidationError
from .modellek import Kurzus, Valasz
from .fajl_kezeles import KurzusFajlKezelo


utvonal = APIRouter()

fajl_kezelo = KurzusFajlKezelo()


@utvonal.get("/kurzusok", response_model=List[Kurzus])
async def get_osszes_kurzus():
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()
        if not kurzusok:
            raise HTTPException(status_code=404, detail="No courses found.")
        print("Courses fetched:", kurzusok)
        return kurzusok
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Courses file not found.")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Internal error: {str(e)}")
    
    
@utvonal.post("/kurzusok", response_model=str)
async def uj_kurzus(kurzus: Kurzus):
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()

        if not isinstance(kurzusok, list):
            raise ValueError("The data source is not in the expected format (list of courses).")
        
        if any(existing_kurzus["id"] == kurzus.id for existing_kurzus in kurzusok):
            raise HTTPException(status_code=400, detail=f"Ez a kurzus id már foglalt: {kurzus.id}")
        
        kurzusok.append(kurzus.model_dump())
        fajl_kezelo.kurzusok_iras(kurzusok)

        return "Sikeres felvétel."

    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="A kurzusok.json fájl nem található.")
    except json.JSONDecodeError:
        raise HTTPException(status_code=500, detail="Hiba a kurzusok.json fájl formátumában.")
    except ValidationError as ve:
        raise HTTPException(status_code=422, detail=ve.errors())
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Váratlan hiba: {str(e)}")

@utvonal.get("/kurzusok/filter", response_model=List[Kurzus])
async def get_kurzusok_filter(
    nap_idopont: str = None,
    oktato_email: str = None,
    tipus: str = None,
    evfolyam: int = None,
    helyszin: str = None,
    max_letszam: int = None,
):

    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()

        if not isinstance(kurzusok, list):
            raise ValueError("The data source is not in the expected format (list of courses).")

        filters = {
            "nap_idopont": nap_idopont,
            "oktato_email": oktato_email,
            "tipus": tipus,
            "evfolyam": evfolyam,
            "helyszin": helyszin,
            "max_letszam": max_letszam,
        }
        active_filters = {key: value for key, value in filters.items() if value is not None}

        if len(active_filters) != 1:
            raise HTTPException(
                status_code=400,
                detail="Provide exactly one filter. Multiple or no filters are not allowed."
            )

        filter_key, filter_value = list(active_filters.items())[0]

        if filter_key == "oktato_email":
            filtered_kurzusok = [
                kurzus for kurzus in kurzusok if kurzus["oktato"]["email"] == filter_value
            ]
        elif filter_key == "max_letszam":
            filtered_kurzusok = [
                kurzus for kurzus in kurzusok if kurzus["max_letszam"] == filter_value
            ]
        elif filter_key == "evfolyam":
            filtered_kurzusok = [
                kurzus for kurzus in kurzusok if kurzus["evfolyam"] == filter_value
            ]
        else:
            filtered_kurzusok = [
                kurzus for kurzus in kurzusok if str(kurzus[filter_key]) == str(filter_value)
            ]

        if not filtered_kurzusok:
            raise HTTPException(status_code=404, detail="No courses match the given filter.")
        return filtered_kurzusok
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="The courses file was not found.")
    except json.JSONDecodeError:
        raise HTTPException(status_code=500, detail="Error in the JSON file format.")
    except ValidationError as ve:
        raise HTTPException(status_code=422, detail=ve.errors())
    except ValueError as verr:
        raise HTTPException(status_code=500, detail=f"Data error: {str(verr)}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Unexpected error: {str(e)}")


@utvonal.get("/kurzusok/filters", response_model=List[Kurzus])
async def get_kurzusok_filters(
    nap_idopont: str = None,
    oktato_email: str = None,
    tipus: str = None,
    evfolyam: int = None,
    helyszin: str = None,
    max_letszam: int = None
):
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()

        if not isinstance(kurzusok, list):
            raise ValueError("Invalid data format in 'kurzusok.json'.")

        filters = {
            "nap_idopont": nap_idopont,
            "oktato.email": oktato_email,
            "tipus": tipus,
            "evfolyam": evfolyam,
            "helyszin": helyszin,
            "max_letszam": max_letszam,
        }
        active_filters = {key: value for key, value in filters.items() if value is not None}

        if len(active_filters) != 2:
            raise HTTPException(
                status_code=400,
                detail="Exactly two filters must be provided."
            )

        filtered_courses = kurzusok
        for filter_key, filter_value in active_filters.items():
            if filter_key == "oktato.email":
                filtered_courses = [
                    kurzus for kurzus in filtered_courses if kurzus["oktato"]["email"] == filter_value
                ]
            else:
                filtered_courses = [
                    kurzus for kurzus in filtered_courses if str(kurzus[filter_key]) == str(filter_value)
                ]

        if not filtered_courses:
            raise HTTPException(
                status_code=404,
                detail="No courses match the provided filters."
            )

        return filtered_courses
    except ValidationError:
        raise HTTPException(status_code=422, detail="Courses file not found.")
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Courses file not found.")
    except json.JSONDecodeError:
        raise HTTPException(status_code=500, detail="Error parsing 'kurzusok.json'.")
    except KeyError as ke:
        raise HTTPException(status_code=400, detail=f"Invalid filter key: {str(ke)}")
    except ValueError as ve:
        raise HTTPException(status_code=500, detail=f"Data error: {str(ve)}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Unexpected error: {str(e)}")

    
@utvonal.put("/kurzusok/{kurzus_id}", response_model=Kurzus)
async def update_kurzus(kurzus_id: int, kurzus: Kurzus):
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()

        if not isinstance(kurzusok, list):
            raise ValueError("Invalid data format in 'kurzusok.json'.")

        matched_course = next((k for k in kurzusok if k["id"] == kurzus_id), None)

        if matched_course is None:
            raise HTTPException(status_code=404, detail=f"Course with ID {kurzus_id} not found.")

        kurzus_dict = kurzus.model_dump()
        kurzus_dict["id"] = kurzus_id

        updated_courses = [
            kurzus_dict if k["id"] == kurzus_id else k for k in kurzusok
        ]

        fajl_kezelo.kurzusok_iras(updated_courses)

        return kurzus_dict

    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Courses file not found.")
    except json.JSONDecodeError:
        raise HTTPException(status_code=500, detail="Error parsing 'kurzusok.json'.")
    except ValidationError as ve:
        raise HTTPException(
            status_code=422,
            detail=[
                {
                    "loc": ["body", "kurzus"],
                    "msg": str(ve),
                    "type": "validation_error"
                }
            ]
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Unexpected error: {str(e)}")


@utvonal.get("/kurzusok/hallgatok/{hallgato_id}", response_model=List[Kurzus])
async def get_hallgato_kurzusai(hallgato_id: int):
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()

        if not isinstance(kurzusok, list):
            raise ValueError("Invalid data format in 'kurzusok.json'.")

        student_exists = any(
            hallgato["id"] == hallgato_id for kurzus in kurzusok for hallgato in kurzus["hallgatok"]
        )
        
        if not student_exists:
            raise HTTPException(
                status_code=404,
                detail=f"Student with ID {hallgato_id} does not exist in any course."
            )

        hallgato_courses = [
            kurzus for kurzus in kurzusok
            if any(hallgato["id"] == hallgato_id for hallgato in kurzus["hallgatok"])
        ]

        return hallgato_courses

    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Courses file not found.")
    except ValidationError as ve:
        raise HTTPException(
            status_code=422,
            detail=[
                {
                    "loc": ["body", "kurzus"],
                    "msg": str(ve),
                    "type": "validation_error"
                }
            ]
        )
    except json.JSONDecodeError:
        raise HTTPException(status_code=500, detail="Error parsing 'kurzusok.json'.")
    except ValueError as ve:
        raise HTTPException(status_code=500, detail=f"Data error: {str(ve)}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Unexpected error: {str(e)}")


@utvonal.delete("/kurzusok/{kurzus_id}")
async def delete_kurzus(kurzus_id: int):
    try:
        kurzusok = fajl_kezelo.kurzusok_olvasas()

        if not isinstance(kurzusok, list):
            raise ValueError("Invalid data format in 'kurzusok.json'.")

        matching_course = next((kurzus for kurzus in kurzusok if kurzus["id"] == kurzus_id), None)

        if not matching_course:
            raise HTTPException(
                status_code=404,
                detail=f"Course with ID {kurzus_id} not found."
            )

        updated_courses = [kurzus for kurzus in kurzusok if kurzus["id"] != kurzus_id]

        fajl_kezelo.kurzusok_iras(updated_courses)

        return f"A {kurzus_id}. kurzus sikeresen törölve!"

    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="Courses file not found.")
    except ValidationError as ve:
        raise HTTPException(
            status_code=422,
            detail=[
                {
                    "loc": ["body", "kurzus"],
                    "msg": str(ve),
                    "type": "validation_error"
                }
            ]
        )
    except json.JSONDecodeError:
        raise HTTPException(status_code=500, detail="Error parsing 'kurzusok.json'.")
    except ValueError as ve:
        raise HTTPException(status_code=500, detail=f"Data error: {str(ve)}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Unexpected error: {str(e)}")


@utvonal.get("/kurzusok/{kurzus_id}/hallgatok/{hallgato_id}", response_model=Valasz)
async def get_hallgato_kurzuson(kurzus_id: int, hallgato_id: int):
    pass