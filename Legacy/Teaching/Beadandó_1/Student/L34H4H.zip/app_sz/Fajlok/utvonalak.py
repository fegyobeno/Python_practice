from fastapi import APIRouter, HTTPException
from typing import List
from .modellek import Kurzus, Valasz
from .fajl_kezeles import KurzusFajlKezelo


utvonal = APIRouter()

fajl_kezelo = KurzusFajlKezelo()

'''
Definiáltuk azt a FastAPI útvonalat, amely a /kurzusok URL-re érkező GET kérésre válaszol. 
A get_osszes_kurzus aszinkron függvény visszaadott értéke egy Kurzus objektumokból álló lista lesz, 
amelyet a FastAPI automatikusan validál és konvertál a megadott Pydantic modell alapján.  
A pass kulcsszó helyébe írd meg azt a kódot, amellyel a JSON fájlban tárolt összes kurzust megkapjuk. 
Alkalmazd a KurzusFajlKezel osztály kurzusok_olvasas metódusát. (1 pont)
'''
@utvonal.get("/kurzusok", response_model=List[Kurzus])
async def get_osszes_kurzus():
    return fajl_kezelo.kurzusok_olvasas()

'''
Definiáltuk azt a FastAPI útvonalat, amely a /kurzusok URL-re érkező POST kérésre válaszol. 
Sikeres művelet esetén a válasz a "Sikeres felvétel." üzenet legyen. 
Az uj_kurzus aszinkron függvényben a pass kulcsszó helyett írd meg azt a kódot, 
amellyel egy új kurzust veszünk fel az adattárunkba. 
Alkalmazd a KurzusFajlKezel osztály metódusait. 
Ha az új kurzus id-je már foglalt, akkor az "Ez a kurzus id már foglalt" üzenet jelenjen meg. 
Teszteld, hogy sikeres-e az új kurzus felvétele. (2 pont)
'''
@utvonal.post("/kurzusok", response_model=Valasz)
async def uj_kurzus(kurzus: Kurzus):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    for k in kurzusok:
        if k["id"] == kurzus.id:
            raise HTTPException(status_code=409, detail="Ez a kurzus id már foglalt")
    kurzus = kurzus.model_dump()
    kurzusok.append(kurzus)
    fajl_kezelo.kurzusok_iras(kurzusok)
    return Valasz(uzenet="Sikeres felvétel")

'''
A /kurzusok/filter URL-re érkező GET kérésre a get_kurzusok_filter aszinkron függvény törzsének megírásakor biztosítsd, 
hogy a pontosan egy kiválasztott szűrőnek megfelelő kurzusok listája megjelenjen. 
Szűrők a következők lehetnek: nap-időpont, oktató email címe, típus, évfolyam, helyszín és maximális létszám.  
Kezeld a felmerülő hibákat! (2 pont)
'''
@utvonal.get("/kurzusok/filter", response_model=List[Kurzus])
async def get_kurzusok_filter(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    szurt_kurzusok = []

    if(len(list(filter(lambda fltr: fltr != None, [nap_idopont, oktato_email, tipus, evfolyam, helyszin, max_letszam]))) != 1):
        raise HTTPException(status_code=422, detail="Pontosan 1 filtert várunk!")

    for kurzus in kurzusok:
        if nap_idopont and kurzus["nap_idopont"] == nap_idopont:
            szurt_kurzusok.append(kurzus)
        elif oktato_email and kurzus["oktato_email"] == oktato_email:
            szurt_kurzusok.append(kurzus)
        elif tipus and kurzus["tipus"] == tipus:
            szurt_kurzusok.append(kurzus)
        elif evfolyam and kurzus["evfolyam"] == evfolyam:
            szurt_kurzusok.append(kurzus)
        elif helyszin and kurzus["helyszin"] == helyszin:
            szurt_kurzusok.append(kurzus)
        elif max_letszam and kurzus["max_letszam"] == max_letszam:
            szurt_kurzusok.append(kurzus)

    if not szurt_kurzusok:
        raise HTTPException(status_code=404, detail="Nincs ilyen kurzus")

    return szurt_kurzusok


'''
A /kurzusok/filters URL-re érkező GET kérésre a get_kurzusok_filters aszinkron függvény törzsének megírásakor biztosítsd, 
hogy pontosan két kiválasztott szűrőnek megfelelő kurzusok listája megjelenjen. 
Szűrők a következők lehetnek: nap-időpont, oktató email címe, típus, évfolyam, helyszín és maximális létszám.  
Kezeld a felmerülő hibákat! (3 pont)
'''
@utvonal.get("/kurzusok/filters", response_model=List[Kurzus])
async def get_kurzusok_filters(nap_idopont: str = None, oktato_email: str = None, tipus: str = None, evfolyam: str = None, helyszin: str = None, max_letszam: int = None):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    szurt_kurzusok = []

    filters = [nap_idopont, oktato_email, tipus, evfolyam, helyszin, max_letszam]
    if len(list(filter(lambda fltr: fltr is not None, filters))) != 2:
        raise HTTPException(status_code=422, detail="Pontosan 2 filtert várunk!")

    for kurzus in kurzusok:
        if nap_idopont and kurzus["nap_idopont"] != nap_idopont:
            continue
        if oktato_email and kurzus["oktato_email"] != oktato_email:
            continue
        if tipus and kurzus["tipus"] != tipus:
            continue
        if evfolyam and str(kurzus["evfolyam"]) != evfolyam:
            continue
        if helyszin and kurzus["helyszin"] != helyszin:
            continue
        if max_letszam and str(kurzus["max_letszam"]) != max_letszam:
            continue
        szurt_kurzusok.append(kurzus)

    if not szurt_kurzusok:
        raise HTTPException(status_code=404, detail="Nincs ilyen kurzus")

    return szurt_kurzusok

'''
A /kurzusok/{kurzus_id} URL-re érkező PUT kérésre az update_kurzus aszinkron függvény megírásával oldd meg, 
hogy a beolvasott kurzus_id által meghatározott kurzus tartalmának frissítése a megadott adatokkal történjen meg.  
Kezeld a felmerülő hibákat! (2 pont)
'''    
@utvonal.put("/kurzusok/{kurzus_id}", response_model=Kurzus)
async def update_kurzus(kurzus_id: int, kurzus: Kurzus):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    for index, k in enumerate(kurzusok):
        if k["id"] == kurzus_id:
            kurzusok[index] = kurzus.model_dump()
            fajl_kezelo.kurzusok_iras(kurzusok)
            return kurzus
    raise HTTPException(status_code=404, detail="Kurzus nem található")

'''
Egy kiválasztott hallgató összes kurzusának listázását a /kurzusok/hallgatok/{hallgato_id} URL-re érkező GET kérésre 
a get_hallgato_kurzusai aszinkron függvény megírásával oldd meg. 
Kezeld a felmerülő hibákat! (2 pont)
'''
@utvonal.get("/kurzusok/hallgatok/{hallgato_id}", response_model=List[Kurzus])
async def get_hallgato_kurzusai(hallgato_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    hallgato_kurzusai = list(filter(lambda kurzus: hallgato_id in [hallgato["id"] for hallgato in kurzus["hallgatok"]], kurzusok))

    if not hallgato_kurzusai:
        raise HTTPException(status_code=404, detail="A hallgatónak nincsenek kurzusai")

    return hallgato_kurzusai

'''
Egy kiválasztott kurzus törlését az adattárból a /kurzusok/{kurzus_id} URL-re érkező DELETE kérés esetén 
delete_kurzus aszinkron függvény megírásával oldd meg. 
Kezeld a felmerülő hibákat! (1 pont)
'''
@utvonal.delete("/kurzusok/{kurzus_id}")
async def delete_kurzus(kurzus_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    for index, k in enumerate(kurzusok):
        if k["id"] == kurzus_id:
            del kurzusok[index]
            fajl_kezelo.kurzusok_iras(kurzusok)
            return {"detail": "Kurzus törölve"}
    raise HTTPException(status_code=404, detail="Kurzus nem található")

'''
A /kurzusok/{kurzus_id}/hallgatok/{hallgato_id} URL-re érkező GET kérés esetén a megírandó 
get_hallgato_kurzuson aszinkron függvény döntse el, hogy egy kiválasztott hallgató rajta van-e a kiválasztott kurzuson. 
Válaszként az "Igen" ill. a "Nem" üzenetet add meg. 
Kezeld a felmerülő hibákat! (2 pont)
'''
@utvonal.get("/kurzusok/{kurzus_id}/hallgatok/{hallgato_id}", response_model=Valasz)
async def get_hallgato_kurzuson(kurzus_id: int, hallgato_id: int):
    kurzusok = fajl_kezelo.kurzusok_olvasas()
    for kurzus in kurzusok:
        if kurzus["id"] == kurzus_id:
            for hallgato in kurzus["hallgatok"]:
                if hallgato["id"] == hallgato_id:
                    return Valasz(uzenet="Igen")
            return Valasz(uzenet="Nem")
    raise HTTPException(status_code=404, detail="Kurzus nem található")
